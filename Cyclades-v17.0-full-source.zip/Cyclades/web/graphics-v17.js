// v17 artwork and usability. Rules continue to run through the existing engine.
const ART17='assets/v17/';
// Route every generated action through the same explanatory disabled control.
btn=function(label,code,ok=true,primary=false){return actionButton(label,code,ok,primary)};
APP.pieceScale??=1;APP.graphicsQuality??='auto';
const OWL_FACTION17=FACTIONS.length;
FACTIONS.push({name:'Owl',color:'#681c3b'});
setupConfig.difficulty[OWL_FACTION17]??='medium';
const factionBefore17=factionAsset;
factionAsset=function(pid,kind){return G.players[pid]?.faction===OWL_FACTION17?ART17+(kind==='owner'?'owl.svg':kind==='warrior'?'warrior-owl.svg':'fleet-owl.svg'):factionBefore17(pid,kind)};
const setupBefore17=setupHTML;
setupHTML=function(){return setupBefore17().replaceAll(`assets/v15/factions/${OWL_FACTION17}.webp`,ART17+'owl.svg')};
// Older saved setup orders predate the owl. Append new choices without replacing seats.
const rosterBefore17=setupRoster;
setupRoster=function(){if(setupConfig.order)setupConfig.order=[...new Set([...setupConfig.order,...FACTIONS.map((_,i)=>i)])];return rosterBefore17().map(p=>({...p,difficulty:p.difficulty||'medium'}))};
const chooseFactionBefore17=chooseSetupFaction;
chooseSetupFaction=function(seat,faction){setupConfig.order=[...new Set([...(setupConfig.order||FACTIONS.map((_,i)=>i)),...FACTIONS.map((_,i)=>i)])];return chooseFactionBefore17(seat,faction)};
function buildingAsset17(t){return ART17+'building-'+t+(t==='U'?'.png':'.svg')}
const paintedBefore17=paintedImage;
paintedImage=function(name,...args){const html=paintedBefore17(name,...args);return name.startsWith('building-')?html.replace(/href="[^"]+"/,`href="${buildingAsset17(name.at(-1))}"`):html};
const buildingsBefore17=tileBuildingsV14;
tileBuildingsV14=function(z){const filled=(z.bldgs?.length||0)+(z.metros?.length||0),church=z.churchSite?`<image class="map-church" href="${buildingAsset17('C')}" x="${z.churchSite.x-12}" y="${z.churchSite.y-17}" width="24" height="30" pointer-events="none"><title>Church · grants a Priestess when claimed</title></image>`:'';return church+(z.buildingSites||[]).slice(filled).map(site=>`<image class="empty-building-site" href="${ART17}building-site.svg" x="${site.x-9}" y="${site.y-9}" width="18" height="16" opacity=".78" pointer-events="none"/>`).join('')+buildingsBefore17(z)};
// New shops already shuffle permitted decks in startConfiguredGame. Keep refill,
// discard and saved-deck order intact; never reshuffle from a render or resume.
const startBefore17=startConfiguredGame;
startConfiguredGame=function(){mapLabelsHidden17=false;document.body.classList.remove('hide-map-labels');startBefore17()};
let mapLabelsHidden17=false;
function toggleMapLabels17(){mapLabelsHidden17=!mapLabelsHidden17;document.body.classList.toggle('hide-map-labels',mapLabelsHidden17);const b=document.getElementById('map-label-toggle');if(b){b.setAttribute('aria-pressed',String(mapLabelsHidden17));b.textContent=mapLabelsHidden17?'Show names':'Hide names'}}
function showMapReadability17(){showAppPanel('map-readability');$('app-panel-title').textContent='Map view';$('app-panel-content').innerHTML=optionRange('pieceScale','Piece size',.8,1.35,.05)+`<p>Large pieces shrink where needed to keep buildings and offerings visible.</p><button id="map-label-toggle" class="btn utility-action" aria-pressed="${mapLabelsHidden17}" onclick="toggleMapLabels17()">${mapLabelsHidden17?'Show names':'Hide names'}</button><small>Names can be hidden for this session. Fleet and offering counts remain visible.</small>`}
const preferenceBefore17=updatePreference;
updatePreference=function(key,value){preferenceBefore17(key,value);if(key==='pieceScale'){APP.pieceScale=Math.max(.8,Math.min(1.35,Number(value)||1));boardLayoutSignature='';mapSignature=null;renderMapSVG()}if(key==='graphicsQuality')applyGraphics17()};
function effectiveGraphics17(){if(['high','low'].includes(APP.graphicsQuality))return APP.graphicsQuality;return APP.performanceMode||(navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4)?'low':'high'}
function applyGraphics17(){document.body.dataset.graphics=effectiveGraphics17();globalThis.Ships17?.invalidate();}
const saveBefore17=saveSettings;
saveSettings=function(){saveBefore17();applyGraphics17()};
const settingsBefore17=renderSettingsCategory;
renderSettingsCategory=function(cat=settingsCategory){settingsBefore17(cat);if(cat==='display')$('app-panel-content').querySelector('.category-content')?.insertAdjacentHTML('beforeend',optionSelect('graphicsQuality','Graphics quality',[['auto','Automatic'],['high','High'],['low','Low']])+optionRange('pieceScale','Map piece size',.8,1.35,.05)+actionButton('Map view controls','showMapReadability17()'))};
// Preserve each existing destination and its accessible name beneath supplied art.
const nav17=document.querySelector('.nav-tabs');
nav17?.classList.add('art-navigation');
nav17?.querySelectorAll('.nav-tab').forEach((b,i)=>b.setAttribute('aria-label',['Map','Gods','Creatures','Heroes'][i]||b.textContent.trim()));
const mapTools17=document.querySelector('.map-tools');
mapTools17?.insertAdjacentHTML('beforeend','<button class="readability-toggle" onclick="showMapReadability17()" aria-label="Map view controls">Aa</button>');
// Replace legacy building references in inspectors and construction notices as well.
function refreshDisabledActions17(root=document){for(const b of root.querySelectorAll?.('button.btn[disabled],button.apollo-choose[disabled]')||[]){const code=b.getAttribute('onclick')||'',label=b.textContent.trim();b.disabled=false;b.setAttribute('aria-disabled','true');b.classList.add('unavailable');b.onclick=e=>{e.preventDefault();e.stopPropagation();explainNotice17(unavailableReason17(code,label))}}}
function refreshBuildingArt17(root=document){for(const img of root.querySelectorAll?.('img[src*="painted/building-"],image[href*="painted/building-"]')||[]){const key=img.tagName==='image'?'href':'src',t=img.getAttribute(key).match(/building-([FUPTMC])/i)?.[1];if(t)img.setAttribute(key,buildingAsset17(t))}}
let buildingArtQueued17=false;
const buildingObserver17=new MutationObserver(()=>{if(buildingArtQueued17)return;buildingArtQueued17=true;queueMicrotask(()=>{buildingArtQueued17=false;refreshBuildingArt17();refreshDisabledActions17()})});
buildingObserver17.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['disabled']});
// Explain unavailable actions in a visible nonmodal notice, even over a shop.
let actionNoticeTimer17;
function explainNotice17(message){setPrompt(message);let notice=$('action-explanation');if(!notice){notice=document.createElement('div');notice.id='action-explanation';notice.setAttribute('role','status');document.body.appendChild(notice)}notice.textContent=message;notice.hidden=false;clearTimeout(actionNoticeTimer17);actionNoticeTimer17=setTimeout(()=>notice.hidden=true,5000);haptic('invalid')}
function unavailableReason17(code,label){const p=G.players[humanPid()],z=G.zones[R.inspected],ts=G.turnState||{};if(R.pending||B)return 'Finish the current choice first.';if(!myAction())return 'Wait until your faction’s action turn.';if(!p)return 'Start a campaign first.';
 if(/sacrifice/i.test(code+label)){if(p.god==='APOLLO'&&!/leto/.test(code))return 'Only Leto can sacrifice while serving Apollo.';return 'A hero can sacrifice starting in the cycle after recruitment.'}
 if(/startMoveMode|moveChosenForce/.test(code)&&z)return movementReason(z)||'No reachable destination is available.';
 if(/recruitAt/.test(code)&&z)return recruitReason(z)||'No eligible recruitment space is available.';
 if(/recruitHero|hireHero/.test(code)){if(p.god!=='HERA')return 'Recruiting a hero requires Hera.';if(ts.hiredHero)return 'You have already recruited a hero this turn.';if(p.gp<4)return `Recruiting a hero costs 4 gold. You have ${p.gp}.`;return 'No eligible land is available for this hero.'}
 if(/buyCreature/.test(code)){if(p.god==='APOLLO')return 'Apollo cannot summon creatures.';const i=Number(code.match(/\((\d+)/)?.[1]),c=G.creatures[i];if(c?.reservedBy!==undefined&&c.reservedBy!==p.id)return 'This creature is reserved for another faction.';if(c&&p.gp<creatureCost(p,c))return `This creature costs ${creatureCost(p,c)} gold. You have ${p.gp}.`;return 'This creature has no eligible target.'}
 if(/playerRecruitUnit|recruitAt/.test(code)){const kind={ARES:'troops',POSEIDON:'fleets',HERA:'mercs'}[p.god],n=ts.recruitedCount||0;if(!kind)return 'Recruitment requires Ares, Poseidon, or Hera.';if(n>=3)return 'All three paid recruitments have been used this turn.';const cost=RECRUIT_COSTS[p.god][n];if(p.gp<cost)return `The next recruit costs ${cost} gold. You have ${p.gp}.`;if(kind==='troops'&&basicCount(p.id)>=8)return 'All eight troops are already on the board.';if(kind==='fleets'&&fleetCount(p.id)>=8)return 'All eight fleets are already on the board.';if(kind==='mercs'&&mercCount()>=16)return 'The shared mercenary reserve is empty.';return 'There is no legal space for this recruit.'}
 if(/build/i.test(code+label)){const type=code.match(/['"]([FPTU])['"]/)?.[1];if(p.gp<2)return `A basic building costs 2 gold. You have ${p.gp}.`;if(type&&buildingCount(type)>=10)return 'Every building of this type is already in play.';return 'No eligible building site or replacement is available.'}
 if(/Priestess|Philosopher/i.test(label)){if(ts.boughtExtraCard)return 'You have already purchased an extra card this turn.';if(p.gp<4)return `An extra card costs 4 gold. You have ${p.gp}.`;return 'The required god or card supply is unavailable.'}
 if(/Apollo/i.test(label)&&getGodHolder('APOLLO'))return 'Apollo is already occupied. Only one faction can choose Apollo.';
 const cost=Number(label.match(/(?:·|\()\s*(\d+)/)?.[1]);if(cost&&p.gp<cost)return `This action costs ${cost} gold. You have ${p.gp}.`;return 'The required god, remaining action, or eligible target is unavailable.';
}
explainAction15=function(code,label){explainNotice17(unavailableReason17(decodeURIComponent(code),decodeURIComponent(label)))};
inlineUnavailable=function(label){explainNotice17(unavailableReason17('',label))};
// The popup owns a stable touch target; map selection must not swallow hero taps.
const showInfoBefore17=showUnitInfo;
showUnitInfo=function(id){showInfoBefore17(id);const box=$('unit-card-popover');if(box){box.setAttribute('tabindex','-1');box.querySelector('img')?.setAttribute('alt',(HEROES.find(h=>h.id===id)||CREATURES.find(c=>c.id===id))?.name||id)}};
// A touch-generated click can be retargeted onto the newly opened popup's
// Close or Sacrifice button. Consume that one click; a fresh pointerdown or
// keyboard action remains usable immediately.
let suppressHeroClick17=false;
document.addEventListener('pointerdown',()=>{suppressHeroClick17=false},true);
const inspectBefore17=inspectMapUnit16;
inspectMapUnit16=function(...args){const result=inspectBefore17(...args);suppressHeroClick17=!!$('unit-card-popover');return result};
document.addEventListener('click',e=>{if(suppressHeroClick17&&e.detail!==0){suppressHeroClick17=false;e.preventDefault();e.stopImmediatePropagation()}},true);
// Keep displayed strength tied to the force BEFORE the round's casualties.
function strengthSnapshot17(side){const f=B[side],pid=B[side+'Id'],parts=strengthParts(side);return {...parts,base:battleStrength(f,pid,side==='def'),heroNames:f.heroes.map(h=>h.name||HEROES.find(v=>v.id===h.id)?.name||h.id),effects:f.heroes.map(h=>HEROES.find(v=>v.id===h.id)).filter(Boolean).map(h=>h.name+': '+h.mil)}}
battleBreakdown=function(side,roll=null){if(!B)return '';const r=roll||B.lastRoll,cached=B.breakdown17,part=r&&cached?.round===r.round?cached[side]:strengthSnapshot17(side),die=r?.[side==='att'?'ad':'dd'],total=r?.[side==='att'?'at':'dt'],name=G.players[B[side+'Id']].name;return `<section class="strength-breakdown"><b>${htmlEscape(name)}</b><span>${B.type==='sea'?'Ships':'Troops / mercenaries'} <strong>${part.units}</strong></span><span>Heroes / creatures <strong>${part.heroes}</strong></span><span>Buildings / bonuses <strong>${part.buildings}</strong></span><span>Die <strong>${die??'—'}</strong></span><strong>Total ${total??part.base}</strong>${part.effects.length?`<details><summary>Hero effects · ${part.heroNames.map(htmlEscape).join(', ')}</summary>${part.effects.map(t=>`<p>${htmlEscape(t)}</p>`).join('')}</details>`:''}</section>`};
function renderBattleDetails17(roll=B?.lastRoll?.round===B?.round?B.lastRoll:null){if(!B)return;const report=B.report,lossName=v=>({troops:B.type==='sea'?'Ship':'Troop',mercs:'Mercenary',minotaur:'Minotaur'})[v]||HEROES.find(h=>h.id===v)?.name||v;let text='<div class="battle-breakdowns">'+battleBreakdown('att',roll)+battleBreakdown('def',roll)+'</div>';if(report)text+=`<div class="battle-loss-summary">${['att','def'].map(side=>`<p><b>${htmlEscape(G.players[B[side+'Id']].name)} casualties:</b> ${report.losses[side].map(lossName).map(htmlEscape).join(', ')||'None'}</p>`).join('')}${report.events.map(e=>`<p>${htmlEscape(e)}</p>`).join('')}</div>`;$('battle-roll-summary').innerHTML=text}
const roundBefore17=animateBattleRound;
animateBattleRound=async function(roll){if(B)B.breakdown17={round:roll.round,att:strengthSnapshot17('att'),def:strengthSnapshot17('def')};const result=await roundBefore17(roll);renderBattleDetails17(roll);return result};
const showBattleBefore17=showBattle;
showBattle=function(msg){showBattleBefore17(msg);renderBattleDetails17()};
const waitBefore17=waitBattleContinue;
waitBattleContinue=async function(...args){renderBattleDetails17();return waitBefore17(...args)};
applyGraphics17();refreshBuildingArt17();
