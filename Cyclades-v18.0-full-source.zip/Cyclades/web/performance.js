// Presentation-only optimization. Rules, random draws and game state stay in the engine.
const PERF={mapBuilds:0,mapHits:0,packingBuilds:0,packingHits:0};
let displayedTab='map';
const packedPieces=new WeakMap(),uncachedPacking=piecePositions;
piecePositions=function(z,n,x=z.x,y=z.y){
 const key=[n,x,y,z.pros].join('|'),cached=packedPieces.get(z);
 if(cached&&cached.board===G.zones&&cached.key===key){PERF.packingHits++;return cached.value}
 const value=uncachedPacking(z,n,x,y);PERF.packingBuilds++;
 packedPieces.set(z,{board:G.zones,key,value});return value;
};
// Cache only the most recent presentation, not snapshots of campaigns or hidden money.
let mapBoard=null,mapSignature=null;
const uncachedMap=renderMapSVG;
function mapPresentationKey(){return JSON.stringify([
 G.zones.map(z=>[z.owner,z.troops,z.mercs,z.fleets,z.heroes,z.bldgs,z.metros,z.pros,z.priestIcon]),
 G.monsters,G.players.map(p=>[p.name,p.color,p.faction]),R.inspected,
 R.choiceMap?R.pending?.options.map(o=>o.zone):null,currentStage()?.zone,
 R.pending?.title,routeSource,routeDestination,APP.labels,APP.tileEdges,APP.contrast,APP.condensed,APP.darkTheme,APP.pieceScale,APP.hideMapLabels,APP.graphicsQuality,R.pending?.options.map(o=>o.building)
])}
renderMapSVG=function(){
 const key=mapPresentationKey();
 if(mapBoard===G.zones&&mapSignature===key){PERF.mapHits++;return}
 uncachedMap();mapBoard=G.zones;mapSignature=key;PERF.mapBuilds++;
 // Direct map updates also restart ambient motion; they don't always call renderAll.
 livingBoard();
};
// A single animation per wave survives unchanged renders. Removed SVG nodes are cancelled
// by the renderer; a WeakMap doesn't retain old islands/campaigns.
const waveAnimations=new WeakMap();
livingBoard=function(){
 const paused=!!document.hidden||displayedTab!=='map'||pointers.size>0;
 document.querySelectorAll?.('.sea-wave').forEach((el,i)=>{
  let animation=waveAnimations.get(el);
  if(FX.reduced||R.auto){animation?.cancel();waveAnimations.delete(el);return}
  if(!animation||animation.playState==='idle'){
   animation=playFX(`water-${i%2?'near':'far'}-${WATER_ACTIONS[i%10]}`,{target:el,loop:true});
   if(animation)waveAnimations.set(el,animation);
  }
  if(paused)animation?.pause?.();else if(animation?.playState==='paused')animation.play?.();
 });
};
// Memoize panel renders against the complete engine state and transient controls.
// This preserves edits/focus on bid inputs when unrelated presentation refreshes occur.
function memoPanel(fn){let previous=null,lastSig='';return function(...args){
 const sig=JSON.stringify([G,R.busy,R.pending?.title,R.pending?.options,R.choiceMap,R.inspected,APP.condensed,displayedTab,!!B]);
 if(sig===lastSig)return previous;
 previous=fn.apply(this,args);lastSig=sig;return previous;
}}
renderAuctionBoard=memoPanel(renderAuctionBoard);
renderMarket=memoPanel(renderMarket);
// Keep the current camera focal point during trackpad/mouse wheel zoom.
function zoomAt(clientX,clientY,factor){
 const rect=mapEl.getBoundingClientRect(),scale=Math.min(rect.width/560,rect.height/690);
 if(!(scale>0))return;
 const x=(clientX-rect.left-(rect.width-560*scale)/2)/scale;
 const y=(clientY-rect.top-(rect.height-690*scale)/2)/scale;
 const anchorX=viewX+x/viewZoom,anchorY=viewY+y/viewZoom;
 viewZoom=Math.max(1,Math.min(3.5,viewZoom*factor));
 viewX=anchorX-x/viewZoom;viewY=anchorY-y/viewZoom;applyView();
}
mapEl.addEventListener('wheel',e=>{
 e.preventDefault();const delta=e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?690:1);
 zoomAt(e.clientX,e.clientY,Math.exp(-Math.max(-120,Math.min(120,delta))*.002));
},{passive:false});
function cancelMapGesture(){
 clearTimeout(pressTimer);pressTimer=null;pressStart=null;
 if(pointers.size){dragged=true;suppressMapClickUntil=Date.now()+500}
 pointers.clear();gesture=null;
}
// Pinching must never confirm a space, even if the synthetic click lands on a child.



const cameraReset=resetMapView;resetMapView=function(){cancelMapGesture();cameraReset();applyView()};
const performanceTab=switchTab;switchTab=function(tab){displayedTab=tab;cancelMapGesture();const result=performanceTab(tab);livingBoard();return result};
// Rotation/reflow keeps normalized camera coordinates and starts a fresh gesture baseline.
// ResizeObserver also catches fullscreen/sidebar changes without polling or layout reads.
function resizeMapCamera(){cancelMapGesture();applyView()}
if(typeof ResizeObserver==='function')new ResizeObserver(resizeMapCamera).observe(mapEl);
globalThis.addEventListener?.('resize',resizeMapCamera);
globalThis.addEventListener?.('blur',cancelMapGesture);
mapEl.setAttribute('tabindex','0');mapEl.setAttribute('aria-label','Aegean map. Pinch or scroll to zoom. Arrow keys pan; Home fits the map.');
mapEl.addEventListener('keydown',e=>{
 if(e.ctrlKey||e.metaKey||e.altKey)return;
 const d=45/viewZoom,steps={ArrowLeft:[-d,0],ArrowRight:[d,0],ArrowUp:[0,-d],ArrowDown:[0,d]};
 if(steps[e.key]){e.preventDefault();viewX+=steps[e.key][0];viewY+=steps[e.key][1];applyView()}
 else if(e.key==='Home'){e.preventDefault();resetMapView()}
 else if(e.key==='+'||e.key==='='){e.preventDefault();zoomMap(.2)}
 else if(e.key==='-'){e.preventDefault();zoomMap(-.2)}
});
document.querySelector('.map-tools')?.insertAdjacentHTML('beforeend','<output id="zoom-readout" aria-label="Map zoom" title="Pinch or scroll to zoom">100%</output>');
const backgroundAnimations=new Set();
document.addEventListener?.('visibilitychange',()=>{
 cancelMapGesture();
 if(document.hidden){for(const a of document.getAnimations?.()||[]){if(a.playState==='running'){a.pause();backgroundAnimations.add(a)}}}
 else{for(const a of backgroundAnimations){if(a.playState==='paused'&&!FX.reduced)a.play()}backgroundAnimations.clear();livingBoard();applyView()}
});
// Synchronize stale session/body flags with the saved preference, and react to OS changes.
function syncMotionPreference(){
 FX.reduced=!APP.motion||!!globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 document.body.classList.toggle('reduced-motion',FX.reduced);
 const label=$('motion-setting');if(label)label.textContent=FX.reduced?'Motion: reduced':'Motion: full';
 if(FX.reduced){for(const a of FX.active)a.cancel()}
 livingBoard();
}
globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').addEventListener?.('change',syncMotionPreference);
const performanceSettings=saveSettings;saveSettings=function(){performanceSettings();syncMotionPreference()};
const performanceTools=showAppPanel;showAppPanel=function(tab='settings'){
 performanceTools(tab);if(tab==='settings')$('app-panel-content').insertAdjacentHTML('beforeend',`<p class="panel-note">Motion status: ${!APP.motion?'disabled in Settings':FX.reduced?'reduced by your device preference':'enabled'}. Sea motion pauses off-map and in the background. Use arrow keys on the map to pan, Home to fit, or scroll to zoom at the pointer.</p>`);
};
REFERENCE_TOPICS.find(t=>t[0]==='Touch controls')[1]+=' Scroll zooms around your pointer. With the map focused, arrow keys pan, +/− zoom and Home fits the map. The zoom percentage appears beside the map controls.';
syncMotionPreference();applyView();
