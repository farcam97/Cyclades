FACTIONS[1].name='Frog';
// Central asset routing: no game-state changes and no recoloring other factions.
const factionArtBefore18=factionAsset;
factionAsset=function(pid,kind){const f=G.players[pid]?.faction,art=ARTWORK18.factions[f];return (kind==='warrior'?art?.troop:kind==='fleet'?art?.ship?.idle:art?.emblem)||factionArtBefore18(pid,kind)};
const buildingArtBefore18=buildingAsset17;
buildingAsset17=function(type){return ARTWORK18.buildings[type]||buildingArtBefore18(type)};
const pieceArtBefore18=unitPiecePath,cardArtBefore18=unitCardPath;
unitPiecePath=function(id){return ARTWORK18.creatures[id]?.piece||pieceArtBefore18(id)};
unitCardPath=function(id){return ARTWORK18.creatures[id]?.card||cardArtBefore18(id)};
// Legacy panels have literal portrait paths. Replace only exact matching assets.
function refreshSuppliedArt18(root=document){for(const el of root.querySelectorAll?.('img,image')||[]){const attr=el.tagName==='image'?'href':'src',src=el.getAttribute(attr)||'';let next=null;const god=src.match(/^assets\/(?:cards\/)?(apollo|ares|athena|hera|poseidon|zeus)\.webp$/);if(god)next=ARTWORK18.gods[god[1]];const building=src.match(/building-([FUPTMC])\.(?:webp|svg|png)$/);if(building)next=el.closest('.top-hud')?(ARTWORK18.hudBuildings[building[1]]||ARTWORK18.buildings[building[1]]):ARTWORK18.buildings[building[1]];const creature=src.match(/^assets\/(cards\/|figures\/)?([a-z-]+)\.webp$/);if(creature&&ARTWORK18.creatures[creature[2]])next=creature[1]==='figures/'?ARTWORK18.creatures[creature[2]].piece:ARTWORK18.creatures[creature[2]].card;if(next&&next!==src)el.setAttribute(attr,next)}}
let queuedArt18=false;
new MutationObserver(()=>{if(queuedArt18)return;queuedArt18=true;queueMicrotask(()=>{queuedArt18=false;refreshSuppliedArt18()})}).observe(document.body,{childList:true,subtree:true});
APP.edgeClouds??=false;
const cloudSettingsBefore18=renderSettingsCategory;
renderSettingsCategory=function(cat=settingsCategory){cloudSettingsBefore18(cat);if(cat==='display')$('app-panel-content').querySelector('.category-content')?.insertAdjacentHTML('beforeend',check14('edgeClouds','Soft clouds around board edges'))};
function syncClouds18(){document.body.classList.toggle('edge-clouds-enabled',!!APP.edgeClouds);document.body.classList.toggle('sprite-motion-paused',!APP.motion||FX.reduced||APP.performanceMode);}
const cloudPreferenceBefore18=updatePreference;
updatePreference=function(...args){cloudPreferenceBefore18(...args);syncClouds18()};
const cloudMotionBefore18=syncMotionPreference;
syncMotionPreference=function(){cloudMotionBefore18();syncClouds18()};
// Decorative edge anchors belong to the imported board, never to selectable areas.
function cloudMarkup18(){const anchors=ARTWORK18.map?.cloudAnchors||[];return `<g class="board-edge-clouds" pointer-events="none" aria-hidden="true">${anchors.map(([x,y],i)=>`<g transform="translate(${x} ${y})"><g class="edge-cloud" style="--cloud-delay:-${i*7}s"><ellipse rx="23" ry="8" fill="#fff"/><ellipse cx="-9" cy="-3" rx="12" ry="8" fill="#fff"/><ellipse cx="7" cy="-4" rx="14" ry="10" fill="#fff"/></g></g>`).join('')}</g>`}
const cloudsMapBefore18=renderMapSVG;
renderMapSVG=function(){cloudsMapBefore18();if(!pointers.size&&G.zones?.[0]?.customMap18){if(!mapEl.querySelector('.board-edge-clouds'))cameraScene().insertAdjacentHTML('beforeend',cloudMarkup18());if(!mapEl.querySelector('.chart-watermark'))cameraScene().insertAdjacentHTML('afterbegin',chartWatermark18())}syncClouds18()};
refreshSuppliedArt18();syncClouds18();

const suppliedHudBefore18=renderCompactHUD;
renderCompactHUD=function(){suppliedHudBefore18();const p=G.players[humanPid()];for(const counter of $('phase-label').querySelectorAll('.building-counter')){const t=TYPES.find(t=>BN[t]===counter.title)||(counter.title==='Unused Temple discounts'?'T':null);const src=t&&(ARTWORK18.hudBuildings[t]||ARTWORK18.buildings[t]);if(src&&counter.querySelector('svg'))counter.querySelector('svg').outerHTML=`<img class="hud-building-art" src="${src}" alt="">`;}if(ARTWORK18.hudBuildings.M)$('phase-label').insertAdjacentHTML('beforeend',`<span class="building-counter" title="Metropolises"><img class="hud-building-art" src="${ARTWORK18.hudBuildings.M}" alt="">${countMetropolises(p.id)}</span>`)};

const suppliedSetupBefore18=setupHTML;setupHTML=function(){return suppliedSetupBefore18().replaceAll('assets/v15/factions/1.webp',ARTWORK18.factions[1].emblem)};

function chartWatermark18(){const f=boardFrame(),edge=ARTWORK18.map.board.outerPath;return `<defs><mask id="chart-outside18"><rect width="${f.width}" height="${f.height}" fill="white"/><path d="${edge}" fill="black"/></mask></defs><g class="chart-watermark" mask="url(#chart-outside18)" pointer-events="none" aria-hidden="true"><g transform="translate(42 449)"><circle r="23"/><circle r="29" stroke-dasharray="1 5"/><path d="M0-39 6-6 39 0 6 6 0 39-6 6-39 0-6-6Z"/><path d="M-20-20 0-7 20-20 7 0 20 20 0 7-20 20-7 0Z"/></g><path d="M9 416Q68 390 102 428M4 486Q65 511 100 476M475 520Q520 531 551 508" stroke-dasharray="2 5"/></g>`}

const factionSyncBefore18=syncColors16;syncColors16=function(){for(const p of G.players||[])if(p.faction===1&&p.name==='Scorpion')p.name='Frog';return factionSyncBefore18()};
