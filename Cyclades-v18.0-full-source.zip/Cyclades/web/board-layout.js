// Presentation geometry only. Territory paths, adjacency, sites and game state are never changed.
const boardLayoutGeometry = new WeakMap();
let boardLayoutIdentity = null, boardLayoutSignature = '', boardLayoutResults = new Map();
function boardArea(z) {
 const area = p => Math.abs(p.reduce((n,a,i)=>{const b=p[(i+1)%p.length];return n+a[0]*b[1]-b[0]*a[1]},0))/2;
 return Math.max(1,area(z.polygon)-(z.holes||[]).reduce((n,p)=>n+area(p),0));
}
function layoutGeometry(z) {
 let data=boardLayoutGeometry.get(z);if(data)return data;
 const xs=z.polygon.map(p=>p[0]),ys=z.polygon.map(p=>p[1]);
 const bounds={left:Math.min(...xs),right:Math.max(...xs),top:Math.min(...ys),bottom:Math.max(...ys)},candidates=[];
 // Cap the candidate grid independently of screen size/zoom.
 const step=Math.max(4,Math.sqrt(boardArea(z)/320));
 for(let y=bounds.top+step/2;y<bounds.bottom;y+=step)for(let x=bounds.left+step/2;x<bounds.right;x+=step)if(tileContainsV14(z,x,y))candidates.push({x,y});
 if(tileContainsV14(z,z.x,z.y))candidates.push({x:z.x,y:z.y});
 data={bounds,candidates,area:boardArea(z),fits:new Map()};boardLayoutGeometry.set(z,data);return data;
}
function layoutRectInside(z,x,y,w,h) {
 return [[-w/2,-h/2],[0,-h/2],[w/2,-h/2],[-w/2,0],[w/2,0],[-w/2,h/2],[0,h/2],[w/2,h/2]].every(([dx,dy])=>tileContainsV14(z,x+dx,y+dy));
}
function boardUnitList(z,condensed) {
 const units=[],add=(kind,n,src)=>{if(!n)return;if(condensed)units.push({kind,n,src});else for(let i=0;i<n;i++)units.push({kind,n:1,src})};
 add('mercenary',z.mercs,PAINT+'mercenary.webp');
 for(const h of z.heroes||[])units.push({kind:'hero',id:h.id,src:unitPiecePath(h.id)});
 for(const m of minis(z)){
  const pair=G.monsters.filter(v=>v.id===m.id&&v.owner===m.owner);
  const charybdis=m.id==='charybdis-scylla'&&(m.aspect==='charybdis'||!m.aspect&&pair.indexOf(m)===0);
  units.push({kind:'creature',id:m.id,pid:m.owner,src:charybdis?V16+'charybdis.webp':unitPiecePath(m.id)});
 }
 add(z.type==='sea'?'fleet':'troop',z.type==='sea'?z.fleets:z.troops,factionAsset(z.owner,z.type==='sea'?'fleet':'warrior'));
 return units;
}
function smartBoardLayout(z) {
 const signature=JSON.stringify([APP.condensed,APP.pieceScale,G.players.map(p=>p.faction),G.zones.map(q=>[q.owner,q.troops,q.mercs,q.fleets,q.heroes,q.bldgs,q.metros,q.pros]),G.monsters]);
 if(boardLayoutIdentity===G.zones&&boardLayoutSignature===signature)return boardLayoutResults.get(z.id);
 boardLayoutIdentity=G.zones;boardLayoutSignature=signature;boardLayoutResults=new Map();
 const occupied=[];
 // Reserve every printed construction site, including unoccupied sites. Figures
 // must not conceal the board's building spaces or neighboring resource plaques.
 for(const q of G.zones)if(q.churchSite)occupied.push({x:q.churchSite.x,y:q.churchSite.y-2,w:27,h:32});
 for(const q of G.zones)for(const [i,site]of(q.buildingSites||[]).entries()){const city=i>=(q.bldgs?.length||0)&&i<(q.bldgs?.length||0)+(q.metros?.length||0);occupied.push({x:site.x,y:site.y-(city?7:5),w:city?37:27,h:city?38:28})}
 function findSpot(q,w,h,preferred,extra=[],supplied=null) {
  const geometry=layoutGeometry(q),fit=geometry.candidates.filter(p=>layoutRectInside(q,p.x,p.y,w,h));
  const candidates=supplied|| (fit.length?fit:geometry.candidates);
  const nearby=[...occupied,...extra].filter(o=>o.x+o.w/2>geometry.bounds.left-35&&o.x-o.w/2<geometry.bounds.right+35&&o.y+o.h/2>geometry.bounds.top-35&&o.y-o.h/2<geometry.bounds.bottom+35);
  let best=null,score=-Infinity;
  for(const p of candidates){
   let overlap=0,clearance=40;
   for(const o of nearby){const dx=Math.abs(p.x-o.x)-(w+o.w)/2-2,dy=Math.abs(p.y-o.y)-(h+o.h)/2-2;if(dx<0&&dy<0)overlap+=(-dx)*(-dy);clearance=Math.min(clearance,Math.hypot(Math.max(0,dx),Math.max(0,dy)))}
   const value=-overlap*100+Math.min(clearance,16)*2-Math.hypot(p.x-preferred.x,p.y-preferred.y)*.12;
   if(value>score){score=value;best=p}
  }
  return {...(best||{x:q.x,y:q.y}),w,h};
 }
 for(const q of G.zones){
  const geometry=layoutGeometry(q),printed=q.printedHorns?.[0],hasBadge=(q.pros||0)>0||!!printed;
  const badge=hasBadge?(printed?{x:printed.x,y:printed.y,w:32,h:25}:findSpot(q,32,25,{x:q.x,y:q.y+15})):null;
  if(badge)occupied.push({...badge,resource:true});
  const full=boardUnitList(q,false),condensed=!!APP.condensed||full.length*750>geometry.area*.45;
  const units=condensed?boardUnitList(q,true):full;
  boardLayoutResults.set(q.id,{key:signature,bounds:geometry.bounds,badge,row:{x:(badge?.x||q.x)-16,y:(badge?.y||q.y)-12},tokenSize:20,gap:23,points:[],owner:null,condensed,units});
 }
 // Place larger figures first, with a shared obstacle list across territory edges.
 const requests=[];
 for(const q of G.zones){const l=boardLayoutResults.get(q.id);l.units.forEach((u,i)=>requests.push({q,l,u,i}));if(q.type==='land'&&q.owner!==null&&!q.troops)requests.push({q,l,u:{kind:'owner'},i:-1})}
 requests.sort((a,b)=>(a.u.kind==='creature'?-2:a.u.kind==='hero'?-1:0)-(b.u.kind==='creature'?-2:b.u.kind==='hero'?-1:0)||a.q.id-b.q.id);
 for(const {q,l,u,i}of requests){
  const large=['hero','creature'].includes(u.kind),base=(u.kind==='owner'?20:large?29:24)*Math.max(.8,Math.min(1.35,Number(APP.pieceScale)||1));
  let w=base,h=u.kind==='fleet'?base*.92:base*1.16;
  const countLabel=l.condensed&&u.n>1?8:0;
  let choices=[];
  for(const scale of [1,.85,.7,.55,.4,.3,.2]){
   w=base*scale;h=(u.kind==='fleet'?base*.92:base*1.16)*scale;
   const geometry=layoutGeometry(q),key=[w,h,countLabel].join('|');
   if(!geometry.fits.has(key))geometry.fits.set(key,geometry.candidates.filter(p=>layoutRectInside(q,p.x,p.y,w+2,h+countLabel+2)&&layoutRectInside(q,p.x,p.y-countLabel/2,w,h)));
   choices=geometry.fits.get(key).filter(p=>!occupied.some(o=>o.resource&&Math.abs(p.x-o.x)<(w+o.w)/2+2&&Math.abs(p.y-o.y)<(h+countLabel+o.h)/2+2));
   if(choices.length)break;
  }
  const p=findSpot(q,w+2,h+countLabel+2,{x:q.x,y:q.y},[],choices.length?choices:null);
  const point={x:p.x,y:p.y-countLabel/2,w,h};
  if(!tileContainsV14(q,point.x,point.y))point.y=p.y;
  occupied.push(p);if(i<0)l.owner=point;else l.points[i]=point;
 }
 for(const q of G.zones){const l=boardLayoutResults.get(q.id);l.owner??={x:q.x,y:q.y,w:20,h:20}}
 return boardLayoutResults.get(z.id);
}
