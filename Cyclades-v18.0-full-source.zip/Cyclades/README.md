# Cyclades 18.0 Preview

Offline Android board game with supplied faction/building/god artwork, sprite ships, and a versioned three-player map. See [release changes](UPDATE-v18.0.md).

## Development

Node 22+, Chromium and Java 21 are used by this workspace. Dependencies are pinned in package-lock.json.

```
npm ci
npm run check
npm run build
npm start
npm test
```

The browser entry point is web/index.html. The production build is dist/. CYCLADES_TEST_URL can target a running production server. Tests expect /usr/bin/chromium unless CHROMIUM_PATH is set. Classic script boundaries must be preserved.

Android preview: bash tools/build-preview.sh. It verifies the SDK and registered artwork, builds production assets, compiles the Android wrapper, and signs with a local preview key outside the source tree. Signing keys are never included in archives. The package is com.aegean.cyclades.preview, version 18.0-preview (code 21).

## Artwork and map authoring

Prepared sources are retained in tools/art-source-v18. Runtime sprites are compact transparent WebP files; large intermediate SVG views are omitted from production when their WebP replacements exist. Source archives retain the authoring images and scripts, not duplicate embedded atlas SVGs.

The map guide is tools/map-data/three-player-v18-guide.jpg. tools/trace-map-v18.py regenerates the canonical geometry; optional tracing dependencies live in /workspace/.tools/map-tracing in this environment. The app does not need Python or tracing dependencies. Existing v17 map data remains for saved-game compatibility.

For sprite re-authoring, tools/import-v18-assets.py creates source-preserving SVG views, then tools/bake-v18-sprites.cjs rasterizes those prepared views through Chromium while the web server runs on port 4173. Image retouching was performed with image_gen. tools/verify-artwork.cjs checks that registered release assets exist.

Physical Android testing remains necessary. The supplied Medusa replacement is pending its original file; current Medusa art is retained.
