// Prevent packaging a graphics release while supplied originals are missing.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'../web'),context={};vm.runInNewContext(fs.readFileSync(path.join(root,'map-three-player-data-v18.js'),'utf8'),context);vm.runInNewContext(fs.readFileSync(path.join(root,'artwork-v18-data.js'),'utf8'),context);const a=context.SUPPLIED_ARTWORK18,missing=[];
function file(label,p){if(typeof p!=='string'||!p.startsWith('assets/')||!fs.existsSync(path.join(root,p)))missing.push(label)}
for(const f of [0,1])for(const view of ['idle','front','rear','side','frontQuarter','rearQuarter'])file(`Faction ${f} ship ${view}`,a.factions[f]?.ship?.[view]);
for(const f of [0,4,6])file(`Faction ${f} troop`,a.factions[f]?.troop);
for(const t of ['F','U','T','P','M','C']){file(`${t} building`,a.buildings[t]);if(t!=='C')file(`${t} top icon`,a.hudBuildings[t])}
for(const god of ['apollo','ares','athena','hera','poseidon','zeus'])file(god,a.gods[god]);
// No replacement Medusa file was included in Updated.zip or fg.zip.
if(a.creatures.medusa)for(const role of ['card','piece'])file(`Medusa ${role}`,a.creatures.medusa[role]);
file('Replacement three-player map',a.map?.image);if(!a.map?.board?.regions?.length)missing.push('Traced three-player map geometry');
if(missing.length){console.error('Graphics release is not ready. Import original supplied files:\n- '+missing.join('\n- '));process.exitCode=1}else console.log('Supplied graphics registered and present.');
