"""Trace the uploaded annotation; colors define geometry, never visible artwork.
Authoring only: PYTHONPATH=/workspace/.tools/map-tracing python3 tools/trace-map-v18.py
"""
from pathlib import Path
import json,hashlib
import numpy as np,cv2
from PIL import Image
from scipy import ndimage as nd
root=Path(__file__).resolve().parents[1];guide=root/'tools/map-data/three-player-v18-guide.jpg'
im=np.array(Image.open(guide));r,g,b=[im[:,:,i].astype(float)for i in range(3)];H,W=r.shape
red=(r>180)&(g<95)&(b<100);green=(g>175)&(r<120)&(b<130)
bar=cv2.morphologyEx((red|green).astype('uint8'),cv2.MORPH_CLOSE,np.ones((5,5),'uint8'));bar=cv2.dilate(bar,np.ones((3,3),'uint8'))
n,labels,stats,cents=cv2.connectedComponentsWithStats(1-bar)
# Fourteen red-enclosed lands. Names are UI labels, not new rules.
landkeys=[3,6,9,12,18,17,22,24,23,31,35,29,34,26]
landnames=['Northern Cape','Northern Sanctuary','Northern Isle','Eastern Sanctuary','Eastern Fields','Mountain Spine','Offering Isle','Western Reach','Western Heights','Western Farms','Southern Farms','Southern Sanctuary','Southern Ridge','Volcanic Isle']
keep=[k for k in range(1,n)if stats[k,4]>2000 and np.mean(np.all(im[labels==k]>235,axis=1))<.5]
assert set(landkeys)<=set(keep)
keys=landkeys+[k for k in keep if k not in landkeys];index={k:i for i,k in enumerate(keys)}
inds=nd.distance_transform_edt(bar,return_distances=False,return_indices=True);full=labels[tuple(inds)]
full=np.array([index.get(int(x),-1)+1 for x in full.ravel()],dtype='int16').reshape(H,W)
scale=560/W;guideScale=W/1546
pt=lambda x,y:{'x':round(x*scale,3),'y':round(y*scale,3)}
polypt=lambda p:[[round(float(x)*scale,3),round(float(y)*scale,3)]for x,y in p]
path=lambda polygons:' '.join('M'+' L'.join(f'{x},{y}'for x,y in p)+' Z'for p in polygons)
adj={}
for left,right in [(full[:,:-1],full[:,1:]),(full[:-1,:],full[1:,:])]:
 m=(left!=right)&(left>0)&(right>0);pairs=np.sort(np.stack([left[m],right[m]],1),axis=1);uniq,counts=np.unique(pairs,axis=0,return_counts=True)
 for pair,count in zip(uniq,counts):key=tuple(int(x)-1 for x in pair);adj[key]=adj.get(key,0)+int(count)
regions=[];diagnostic=im.copy()
for i,k in enumerate(keys):
 mask=(full==i+1).astype('uint8');cnts,tree=cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE);outer=max((j for j,v in enumerate(tree[0])if v[3]<0),key=lambda j:cv2.contourArea(cnts[j]));polygon=polypt(cv2.approxPolyDP(cnts[outer],1.8,True).reshape(-1,2));holes=[polypt(cv2.approxPolyDP(cnts[j],1.8,True).reshape(-1,2))for j,v in enumerate(tree[0])if v[3]==outer and cv2.contourArea(cnts[j])>80];d=nd.distance_transform_edt(mask);y,x=np.unravel_index(np.argmax(d),d.shape)
 reg={'id':i,'name':landnames[i]if i<14 else f'Sea {i-13}','type':'land'if i<14 else'sea',**pt(x,y),'polygon':polygon,'holes':holes,'path':path([polygon,*holes]),'adj':sorted(v if u==i else u for (u,v),length in adj.items()if length>=18 and i in(u,v)),'island':None,'tileArtV14':True,'pros':0,'printedPros':0,'priestIcon':False,'capacity':0,'buildingSites':[],'printedHorns':[]}
 regions.append(reg);cv2.drawContours(diagnostic,[cnts[outer]],-1,(255,120,0),2);cv2.putText(diagnostic,str(i),(x,y),cv2.FONT_HERSHEY_SIMPLEX,.9,(0,0,0),5);cv2.putText(diagnostic,str(i),(x,y),cv2.FONT_HERSHEY_SIMPLEX,.9,(255,255,255),2)
# Center positions are reviewed against the real dirt patches, not shifted by red strokes.
sites={0:[(527,167)],1:[(313,126),(248,207),(446,320)],2:[(866,320)],3:[(1306,302),(1150,484),(1426,468)],4:[(1355,665)],5:[(1016,479),(900,543),(972,675)],6:[],7:[(151,768),(249,720)],8:[(565,636),(498,830)],9:[(633,993)],10:[(569,1167),(392,1214),(496,1332)],11:[(800,900),(914,922),(1119,1029)],12:[(1257,1118)],13:[(1136,873)]}
for i,locations in sites.items():
 for x,y in locations:
  X,Y=round(x*guideScale),round(y*guideScale)
  if full[Y,X]!=i+1:
   dist,ind=nd.distance_transform_edt(full!=i+1,return_indices=True);assert dist[Y,X]<45,(i,x,y,dist[Y,X]);Y,X=ind[:,Y,X]
  regions[i]['buildingSites'].append(pt(X,Y))
 regions[i]['capacity']=len(locations)
def dots(mask,minarea=50):
 n,_,s,c=cv2.connectedComponentsWithStats(mask.astype('uint8'));return [(float(c[k,0]),float(c[k,1]))for k in range(1,n)if s[k,4]>minarea]
for mask,value in [((r>200)&(g>200)&(b<90),1),((r>170)&(b>170)&(g>100)&(r>g+20)&(b>g+20),2)]:
 for x,y in dots(mask):
  i=int(full[round(y),round(x)])-1;assert i>=0;reg=regions[i];reg['pros']+=value;reg['printedPros']+=value;reg['printedHorns'].append({**pt(x,y),'n':value})
for x,y in dots((g>180)&(b>180)&(r<100)):
 i=int(full[round(y),round(x)])-1;assert 0<=i<14;regions[i]['priestIcon']=True;regions[i]['churchSite']=pt(x,y)
# Land adjacency groups define physical islands.
seen=set();groups=[]
for i in range(14):
 if i in seen:continue
 todo=[i];members=[]
 while todo:
  q=todo.pop()
  if q in seen:continue
  seen.add(q);members.append(q);todo.extend(j for j in regions[q]['adj']if j<14 and j not in seen)
 island=len(groups)
 for q in members:regions[q]['island']=island
 groups.append({'path':' '.join(regions[q]['path']for q in members),'polygon':regions[members[0]]['polygon'],'regions':members,'island':island})
# The outside board contour is used to clip the untouched original artwork.
cs,_=cv2.findContours((full>0).astype('uint8'),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE);outerPath=path([polypt(cv2.approxPolyDP(c,1.5,True).reshape(-1,2))for c in cs if cv2.contourArea(c)>100])
meta={'id':'three-player-v2','sourceSha256':hashlib.sha256(guide.read_bytes()).hexdigest(),'frame':{'width':560,'height':round(H*scale,3)},'macroShapes':groups,'regions':regions,'outerPath':outerPath}
(root/'tools/map-data/three-player-map-v18.json').write_text(json.dumps(meta,indent=2)+'\n');(root/'web/map-three-player-data-v18.js').write_text('// Derived from the supplied annotation, never displayed as art.\nglobalThis.CYCLADES_MAP_3P18='+json.dumps(meta,separators=(',',':'))+';\n')
(root/'artifacts').mkdir(exist_ok=True);cv2.imwrite(str(root/'artifacts/map-topology-v18.png'),diagnostic)
print(json.dumps({'land':14,'sea':len(regions)-14,'sites':sum(z['capacity']for z in regions),'churches':sum(z['priestIcon']for z in regions),'singleLocations':sum(h['n']==1 for z in regions for h in z['printedHorns']),'doubleLocations':sum(h['n']==2 for z in regions for h in z['printedHorns']),'adjacency':[(z['id'],z['adj'])for z in regions]}))
