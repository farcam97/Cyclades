"""Register generated transparent cutouts and source-preserving SVG sprite views.
The image edits themselves are performed by image_gen; this writes SVG views.
"""
from pathlib import Path
import json,base64,shutil
import cv2,numpy as np
from PIL import Image
root=Path(__file__).resolve().parents[1];web=root/'web';out=web/'assets/v18';gen=root/'tools/art-source-v18'
p=web/'artwork-v18-data.js';config=json.loads(p.read_text().split('const ARTWORK18=',1)[1].split(';',1)[0])
def view(src,dest,box,clip=''):
 im=Image.open(src);w,h=im.size;mime='image/png'if src.suffix=='.png'else'image/jpeg';data=base64.b64encode(src.read_bytes()).decode();(out/dest).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{" ".join(map(str,box))}">{clip}<image width="{w}" height="{h}" href="data:{mime};base64,{data}"'+(' clip-path="url(#cut)"'if clip else'')+'/></svg>');return 'assets/v18/'+dest
# Six isolated components are kept complete, rather than cropped at arbitrary grid lines.
def sheet(filename,prefix,names):
 src=gen/filename;im=Image.open(src);n,lab,stats,cents=cv2.connectedComponentsWithStats((np.array(im)[:,:,3]>127).astype('uint8'));items=[(stats[i],cents[i])for i in range(1,n)if stats[i,4]>10000];assert len(items)==6,(prefix,len(items));top=sorted(sorted(items,key=lambda v:v[1][1])[:3],key=lambda v:v[1][0]);bottom=sorted(sorted(items,key=lambda v:v[1][1])[3:],key=lambda v:v[1][0]);result={}
 for name,(s,c)in zip(names,top+bottom):
  x,y,w,h=[int(v)for v in s[:4]];pad=2;left=max(0,x-pad);upper=max(0,y-pad);result[name]=view(src,prefix+'-'+name+'.svg',(left,upper,min(im.width,x+w+pad)-left,min(im.height,y+h+pad)-upper))
 return result
config['gods']=sheet('exec-4881fd94-7b42-4a86-bff5-ab72b9846028.png','god',['apollo','ares','athena','hera','poseidon','zeus'])
config['hudBuildings']=sheet('exec-06c83c5e-5043-41b1-8c4a-a06a265d5be9.png','hud-building',['F','U','T','P','M','C']);config['hudBuildings'].pop('C')
config['buildings']=sheet('exec-5d396432-09fc-402b-96e6-3f167018adad.png','building',['F','U','T','P','M','C'])
shutil.copy2(gen/'exec-49925afc-33b5-42ac-9aa4-a74c22d8e29c.png',out/'building-M.png');config['buildings']['M']='assets/v18/building-M.png'
for faction,name,source in [(0,'lion','exec-3d8ddeb2-d46e-4a6a-9d82-965bf84e1778.png'),(1,'red-frog','exec-b79b07ef-3f76-4b62-8fb6-8525c3ee94f2.png'),(4,'ox','exec-957b9bf3-776d-484e-8c21-e09c3a7d93ab.png'),(6,'otter','exec-af55be48-d17c-4cc9-a08e-a5d84d5e8c06.png')]:
 dest='troop-'+name+'.png';shutil.copy2(gen/source,out/dest);config['factions'].setdefault(str(faction),{})['troop']='assets/v18/'+dest
# The emblem comes from the exact user-uploaded sheet.
source=gen/'user/frog-faction.png';config['factions']['1']['emblem']=view(source,'emblem-red-frog.svg',(960,573,426,426),'<defs><clipPath id="cut"><circle cx="1173" cy="786" r="210"/></clipPath></defs>')
# Cream sails replace the all-gold Lion sails in all six directional views.
src=gen/'exec-d2a72e3f-4684-4f2f-a32f-a48e596a1fa3.png'
for name,box in {'idle':(0,0,560,512),'front':(560,0,440,512),'side':(1000,0,536,512),'frontQuarter':(0,512,560,512),'rear':(560,512,440,512),'rearQuarter':(1000,512,536,512)}.items():view(src,'ship-lion-'+name+'.svg',box)
# Avoid clipping the bows at the original atlas's nominal row boundaries.
src=gen/'exec-4b7c2a60-603b-484d-b295-7b5bf1e8ed9d.png';xs=[0,490,980,1448];ys=[0,375,733,1086]
for name,(x,y)in {'idle':(0,0),'S':(1,0),'E':(0,1),'SE':(1,1),'N':(2,1),'SW':(0,2),'W':(1,2),'NW':(2,2)}.items():view(src,'ship-red-frog-'+name+'.svg',(xs[x],ys[y],xs[x+1]-xs[x],ys[y+1]-ys[y]))
# New geometry and art are versioned; existing saves retain three-player-v1.
shutil.copy2(gen/'exec-c85c73fa-11d0-43e5-85ad-1fe325301890.png',out/'map-three-player.png')
config['map']={'image':'assets/v18/map-three-player.png','cloudAnchors':[[28,35],[103,4],[246,24],[465,46],[550,140],[537,248],[487,400],[277,460],[242,574],[110,568],[89,460],[8,270]]}
p.write_text('// Registered supplied artwork. Churches are permanent map landmarks, not counters.\nconst ARTWORK18='+json.dumps(config,separators=(',',':'))+';\nARTWORK18.map.board=globalThis.CYCLADES_MAP_3P18;\nglobalThis.SUPPLIED_ARTWORK18=ARTWORK18;\n')
print('Registered',len(config['gods']),'gods,',len(config['buildings']),'map structures,',len(config['hudBuildings']),'HUD structures and supplied faction art.')
