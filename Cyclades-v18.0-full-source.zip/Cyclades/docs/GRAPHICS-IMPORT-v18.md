# Graphics import — 18.0

The supplied Updated.zip graphics and fg.zip map have been imported, isolated, optimized and connected. Source images and authoring tools are retained in tools/art-source-v18. The latest Medusa replacement was not included and remains pending.

Churches are confirmed permanent landmarks that award Priestesses through the existing claim rule; they cannot be built/destroyed and consume no normal building capacity. Church icons are omitted from top counters.

Red faction working name: Frog. Natural skin is used for Lion. Cream sails replace all-gold sails. Other factions use existing sprite ships. Static troops have no idle animation.

See UPDATE-v18.0.md and README.md for release behavior and authoring steps.
