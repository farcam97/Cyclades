# Performance and animation maintenance

The game rules, board art, full figure roster, sound assets and 400 animation treatments are unchanged.

- Pinch/pan computes camera state per input but commits SVG viewBox at most once per animation frame. Layout is read at gesture boundaries, not on every pointermove.
- Piece packing is cached by zone identity, board identity, force size, position and prosperity. A WeakMap releases obsolete campaigns.
- The map renderer skips unchanged presentation state. Auction and market renderers also skip unchanged state, preserving input focus and avoiding repeated image DOM creation.
- Water has one tracked animation per wave. Unchanged refreshes no longer cancel/restart it. Direct map updates restart water on the replacement nodes.
- The quiet post-auction effect filter excludes ambient loops. Mandatory rewards and bidding remain free of bursts.
- Saved motion preferences now synchronize the body class and settings indicator; system preference changes update immediately.

Six app improvements: pointer-centered wheel/trackpad zoom; map keyboard pan/zoom/Home; visible zoom percentage; pointer-cancellation/background recovery and accidental-tap suppression; camera preservation across resize/orientation/fullscreen; off-map/background animation pause/resume.

Validation: existing rules (32 cases), complete campaign, randomized setup, touch, save/restore, individual figures and battle suites pass. The additional performance suite verifies 100 pointer events produce one camera DOM write and two layout reads at gesture starts; 100 unchanged map refreshes produce zero rebuilds; changed prosperity invalidates the map; real WAAPI dispatch is requested for water and action effects; quiet bidding, pause/resume and motion re-enabling work.

These are deterministic Node DOM/WAAPI simulations, not browser FPS measurements. Physical-phone rendering, audio and GPU performance have not been measured in this environment.
