const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},querySelectorAll(){return []},style:{setProperty(){}},remove(){this.removed=true},listeners:{},addEventListener(t,f){(this.listeners[t]??=[]).push(f)},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {left:0,top:0,width:560,height:690}},focus(){}};nodes.set(id,n);return n}
const frames=new Map();let frameId=0;
const c=vm.createContext({requestAnimationFrame:f=>{frames.set(++frameId,f);return frameId},document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js','usability.js','immersion.js','campaign-tools.js','campaign-v11.js','streamlined-v12.js','polish-v13.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}



r('setupConfig.count=6;R.auto=true;startConfiguredGame()');
r("G.phase='OFFERINGS';G.activeBidder=0;G.biddingQueue=[0,1,2,3,4,5];G.players[0].priests=0;G.players[0].gp=100;G.config.bidding='exponential'");
assert.equal(r('JSON.stringify(legalOffers(G.players[0],G.openGods[0]))'),'[0,1,2,3,5,7,10,15,20,25]');
r('placeBid(0,G.openGods[0],4)');assert.equal(r('G.activeBidder'),0,'off-track bid rejected');
r('placeBid(0,G.openGods[0],0)');assert.equal(r('G.players[0].bid'),0);assert.equal(r('G.players[0].god'),r('G.openGods[0]'));
assert(!r('legalOffers(G.players[1],G.openGods[0]).includes(0)'),'zero holder cannot be matched');
r("G.config.bidding='fine';G.players[1].gp=100");assert(r('legalOffers(G.players[1],G.openGods[0]).includes(4)'));
r("G.config.bidding='exponential';G.activeBidder=1;G.players[1].controller=0;R.auto=false;renderAuctionBoard()");
assert(!el('gods-container').innerHTML.includes('auction-ribbon'));
assert.equal((el('gods-container').innerHTML.match(/class="track-god"/g)||[]).length,5);
assert(!el('.nav-tabs').innerHTML.includes('Settings'));assert(el('.nav-tabs').innerHTML.includes('Creatures'));assert(el('.nav-tabs').innerHTML.includes('Heroes'));
assert(!el('.map-tools').innerHTML.includes('zoomMap'));assert(!el('.map-tools').innerHTML.includes('showPieceLegend'));assert(el('.map-tools').innerHTML.includes('Reset map view'));
r("G.activeBidder=0;G.players[0].controller=0;G.phase='ACTIONS';R.busy=false;G.players[0].god='HERA';R.pending=null;R.auto=false;renderAll()");
assert(!el('factions-hud').innerHTML.includes('Hidden'));assert(!el('factions-hud').innerHTML.includes('<small>AI'));
r("openMarket('heroes');G.heroes=[HEROES[0],HEROES[1]];renderMarket()");assert(el('market-view .panel-inner').innerHTML.includes('Military'));assert(el('market-view .panel-inner').innerHTML.includes('Sacrifice'));
r("G.creatures=[{...CREATURES[0],cost:2}];openMarket('creatures')");assert(el('market-view .panel-inner').innerHTML.includes('Swap one of your Heroes'));
r("G.zones[0].owner=0;G.zones[0].troops=3;G.zones[0].mercs=2;G.zones[0].heroes=[];APP.condensed=false");assert(!r('renderIndividualPieces(G.zones[0],100,100)').includes('ownership-token'));
r('G.zones[0].troops=0');assert(r('renderIndividualPieces(G.zones[0],100,100)').includes('ownership-token'));
r('G.zones[0].troops=3;APP.condensed=true');const pieces=r('renderIndividualPieces(G.zones[0],100,100)');assert.equal((pieces.match(/data-piece="troop"/g)||[]).length,1);assert(pieces.includes('>3</text>'));
assert.equal(r("prosperityStrip({type:'sea',pros:0},0,0)"),'');assert(!r("paintedImage('building-T',0,0,30,30,'building-sprite')").includes('tint-'));
r("R.auto=false;ask(0,'Hera: choose a basic Building you do not own',[{value:'F',label:'Fortress',image:'painted/building-F'},{value:'U',label:'University'}]);inspectDecisionMap()");assert.equal(r('R.pending.options[0].value'),'F');assert.equal(el('decision-map').hidden,false);assert.equal(r('displayedTab'),'map');assert(el('action-btns').innerHTML.includes('Return to choice'));r('answerDecision(0)');
r("ask(0,'Sphynx: play one of these Creatures',[{value:0,label:'Kraken'}]);inspectDecisionMap()");assert(r('R.pending!==null'));r('answerDecision(0)');
r('watching=true;followCamera=true;releaseCamera()');assert.equal(r('followCamera'),false);assert.equal(el('follow-camera').hidden,false);r('resumeFollowCamera()');assert.equal(r('followCamera'),true);
// Three independent camera/cache runs, each with 1,000 input updates and 100 no-op renders.
for(let pass=0;pass<3;pass++){
 frames.clear();r('cameraFrame=null;R.auto=true;APP.condensed=false;viewZoom=2;viewX=10;viewY=10;renderMapSVG()');
 const builds=r('PERF.mapBuilds'),packs=r('PERF.packingBuilds');
 for(let i=0;i<1000;i++)r('viewX+=.01;applyView()');assert.equal(frames.size,1);
 for(const f of [...frames.values()])f();frames.clear();
 for(let i=0;i<100;i++)r('renderMapSVG()');assert.equal(r('PERF.mapBuilds'),builds);assert.equal(r('PERF.packingBuilds'),packs);
 r('G.zones[0].troops++;renderMapSVG()');assert.equal(r('PERF.mapBuilds'),builds+1);
 console.log('PASS camera/cache stress pass',pass+1);
}
r('pointers.set(91,{x:1,y:1});dragged=true;G.zones[0].pros++;renderMapSVG()');assert(r('deferredMap'));const beforeRelease=r('PERF.mapBuilds');r('pointers.clear();renderMapSVG()');assert.equal(r('PERF.mapBuilds'),beforeRelease+1);assert(!r('deferredMap'));
r("toggleFullMap();switchTab('market')");assert(r('fullMap'));assert.equal(r('displayedTab'),'market');r("switchTab('auction');toggleFullMap()");assert(!r('fullMap'));assert.equal(r('displayedTab'),'auction');
assert.equal(r('Object.keys(CREATURE_VOICES).length'),18);assert.equal(r('new Set(Object.values(CREATURE_VOICES).map(JSON.stringify)).size'),18);
r("G.teams=null;G.players.forEach(p=>{p.protected=[];p.gp=0});G.zones.forEach(z=>z.metros=[]);G.players[0].protected=['gold','gold','gold']");assert(r('humanWon()'));r("G.players[0].protected=[];G.players[2].protected=['gold','gold','gold'];G.players[2].controller=2");assert(!r('humanWon()'));
for(const n of nodes.values())for(const m of n.innerHTML.matchAll(/onclick="([^"]+)"/g))new vm.Script(m[1].replaceAll('&amp;','&').replaceAll('&quot;','"').replaceAll('&#39;',"'"));
console.log('PASS printed/fine bids, compact HUD/navigation, powers, numbered pieces, ownership, Hera/Sphynx map return, follow camera, 18 sounds, victory/defeat and UI handler syntax');

(async()=>{
 r("R.auto=false;APP.watchCPU=false;G.teams=null;G.players.forEach((p,i)=>{p.isAI=true;p.controller=i+1;p.god='ARES'});G.zones.forEach(z=>{z.troops=0;z.mercs=0;z.heroes=[];z.bldgs=[];z.metros=[]});G.zones[0].owner=1;G.zones[1].owner=2;G.zones[1].troops=1;R.pending=null;watching=true;viewZoom=1;viewX=0;viewY=0");
 await r("battle(G.players[1],G.zones[0],G.zones[1],{troops:2,mercs:0,heroes:[]},'land')");
 assert.equal(r('B'),null);assert.equal(r('viewZoom'),1);assert(r('G.lastBattle.rounds.length>0'));
 console.log('PASS computer battle resolves without modal, cinematic waits or camera jump when viewing is disabled');
})().catch(e=>{console.error(e);process.exitCode=1});
