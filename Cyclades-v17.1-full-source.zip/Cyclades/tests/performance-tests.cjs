const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},listeners:{},addEventListener(type,fn){(this.listeners[type]??=[]).push(fn)},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {left:0,top:0,width:560,height:690}},focus(){}};nodes.set(id,n);return n}
const frames=new Map();let fid=0;
const c=vm.createContext({requestAnimationFrame:f=>{frames.set(++fid,f);return fid},cancelAnimationFrame:id=>frames.delete(id),document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}
const map=el('archipelago'),ev=(id,x,y)=>({pointerId:id,clientX:x,clientY:y,pointerType:'touch',target:{closest:()=>null}}),fire=(name,e)=>map.listeners[name].forEach(fn=>fn(e));

function frame(){const work=[...frames.values()];frames.clear();work.forEach(f=>f())}
let writes=0,reads=0;const oldSet=map.setAttribute.bind(map),oldRect=map.getBoundingClientRect.bind(map);
map.setAttribute=(k,v)=>{if(k==='viewBox')writes++;oldSet(k,v)};
map.getBoundingClientRect=()=>{reads++;return oldRect()};
frame();writes=0;reads=0;
fire('pointerdown',ev(1,100,100));fire('pointerdown',ev(2,300,100));
for(let i=1;i<=100;i++)fire('pointermove',ev(2,300+i,100));
assert.equal(writes,0);assert.equal(reads,2);assert.equal(frames.size,1);frame();assert.equal(writes,1);
assert.equal(r('viewZoom'),1.5);fire('pointerup',ev(1,100,100));fire('pointerup',ev(2,400,100));
r('viewZoom=2;viewX=100;viewY=100;zoomAt(200,200,1.1)');
assert(Math.abs(r('viewX+200/viewZoom')-200)<1e-9);assert(Math.abs(r('viewY+200/viewZoom')-200)<1e-9);
fire('pointerdown',ev(3,100,100));fire('pointercancel',ev(3,100,100));assert.equal(r('pointers.size'),0);
r('renderMapSVG()');const builds=r('PERF.mapBuilds'),pack=r('PERF.packingBuilds');
const start=performance.now();for(let i=0;i<100;i++)r('renderMapSVG()');const elapsed=performance.now()-start;
assert.equal(r('PERF.mapBuilds'),builds);assert.equal(r('PERF.packingBuilds'),pack);
r('G.zones[0].pros++;renderMapSVG()');assert.equal(r('PERF.mapBuilds'),builds+1);
// Count real animation requests via a minimal WAAPI mock (not catalog membership).
let starts=0;const animations=[];
function animatedNode(id){const n=el(id);n.style={};n.appendChild=()=>{};n.remove=()=>{};n.animate=()=>{
 starts++;const a={playState:'running',cancel(){this.playState='idle';this.oncancel?.()},pause(){this.playState='paused'},play(){this.playState='running'}};animations.push(a);return a;
};return n}
const waves=Array.from({length:32},(_,i)=>animatedNode('wave'+i));
c.document.querySelectorAll=sel=>sel==='.sea-wave'?waves:[0,1,2,3].map(i=>el('nav'+i));
c.document.createElement=tag=>animatedNode('new'+tag+starts);
el('fx-layer').appendChild=()=>{};
r("R.auto=false;APP.motion=true;FX.reduced=false;G.phase='OFFERINGS';quietGodResolution=true;livingBoard()");assert.equal(starts,32,'quiet bidding must not suppress looping water');
r('livingBoard();renderAll();livingBoard()');assert.equal(starts,32,'unchanged renders must not stack wave animations');
r("switchTab('auction')");assert(animations.slice(0,32).every(a=>a.playState==='paused'));
r("switchTab('map')");assert(animations.slice(0,32).every(a=>a.playState==='running'));
r("G.phase='ACTIONS';quietGodResolution=false;actionEvent('muster',{zone:0,pid:0})");assert(starts>32,'recruit actions should start actual animations');
const actionCount=starts;r("quietGodResolution=true;actionEvent('muster',{zone:0,pid:0})");assert.equal(starts,actionCount,'mandatory postbid effects remain quiet');
r('APP.motion=false;syncMotionPreference()');assert(animations.slice(0,32).every(a=>a.playState==='idle'));
r('APP.motion=true;quietGodResolution=false;syncMotionPreference()');assert(starts>actionCount,'motion can be re-enabled');
console.log(`PASS: 100 pointer moves -> 1 camera write / 2 gesture layout reads; focal zoom, cancellation, map invalidation, 100 unchanged redraws -> 0 rebuilds (${elapsed.toFixed(1)}ms synthetic VM), actual animation dispatch, persistent water, tab pause/resume, quiet bidding, motion re-enable.`);
