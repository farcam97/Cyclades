const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},querySelectorAll(){return []},style:{setProperty(){}},listeners:{},addEventListener(k,f){(this.listeners[k]??=[]).push(f)},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {left:0,top:0,width:560,height:690}},remove(){},focus(){}};nodes.set(id,n);return n}
const storage=new Map();const c=vm.createContext({document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','tiles-v14.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js','usability.js','immersion.js','campaign-tools.js','campaign-v11.js','streamlined-v12.js','polish-v13.js','maelstrom-v14.js','faq-v14.js','interface-v14.js','interface-v15.js','board-layout.js','interface-v16.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}




(async()=>{
r('setupConfig.count=3;setupConfig.spectator=false;startConfiguredGame();R.auto=true');await drainUntil("G.phase==='OFFERINGS'&&!R.busy");q.clear();r("timers.forEach(clearTimeout);timers.clear();R.auto=false;APP.motion=false;APP.cinematics=false;G.phase='ACTIONS';G.activeBidder=0;G.actionOrder=[0,1,2];G.activePlayerIdx=0;G.players[0].god='ARES';G.players[0].gp=20;G.turnState={heroMoves:{},recruitedCount:0};R.inspected=lands(0)[0].id;renderActionButtons()");
assert(el('action-btns').innerHTML.includes('2 gold'));
assert(el('action-btns').innerHTML.includes('recruit-troop'));
const original=r('JSON.stringify(G)');
r("globalThis.choicePromise=ask(0,'Place a test offering',optsAreas(lands(0)))");await new Promise(setImmediate);assert(r('R.pending!==null&&R.choiceMap'));

const index=r('R.pending.options.findIndex(o=>o.zone===lands(0)[0].id)');
r(`answerDecision(${index})`);await r('choicePromise');assert.equal(r('R.pending'),null);assert.equal(r('JSON.stringify(G)'),original);
r("G.turnState.recruitedCount=3;renderActionButtons()");assert(el('action-btns').innerHTML.includes('Recruitment limit reached'));assert(el('action-btns').innerHTML.includes('aria-disabled="true"'));
r("G.turnState.recruitedCount=0;G.players[0].god='POSEIDON';R.inspected=G.zones.find(z=>z.type==='sea'&&z.owner===0).id;renderActionButtons()");assert(el('action-btns').innerHTML.includes('recruit-ship'));assert(el('action-btns').innerHTML.includes('move-fleet'));
for(let faction=0;faction<7;faction++){
 r(`G.players[0].faction=${faction}`);assert(r('factionAsset(0,"owner")').includes('/'+faction+'.webp'));assert(r('forceSprites({troops:1,mercs:0,heroes:[],minotaur:null},0,"sea","att")').includes('fleet-'+faction+'.webp'));
}
// Resolve the actual setup and character art paths, including dynamic expansion IDs.
for(const src of [...r('setupHTML()').matchAll(/src="([^"]+)"/g)].map(m=>m[1]))assert(fs.existsSync(root+'/'+src),'Missing setup art '+src);
for(const src of r('[...MAELSTROM_IDS].flatMap(id=>[unitPiecePath(id),unitCardPath(id)])'))assert(fs.existsSync(root+'/'+src),'Missing expansion art '+src);
r('G.config.spectator=true;pauseSpectator15=true');const gate=r('spectatorGate15()');let released=false;gate.then(()=>released=true);await new Promise(setImmediate);assert(!released);r('stepSpectator15()');await gate;assert(released);assert.equal(r('stepBudget15'),1);r('pauseSpectator15=false');
r('R.busy=false;R.pending=null;checkpointGame()');assert(r('readSave()'));assert(r('validateImportedCampaign(readSave())'));
console.log('PASS human choices, recruitment prices/caps, Poseidon controls, all faction assets, spectator gate and spectator save');
})().catch(e=>{console.error(e);process.exitCode=1});
