const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},addEventListener(){},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {width:560,height:690}},focus(){}};nodes.set(id,n);return n}
const c=vm.createContext({document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}
(async()=>{
await drainUntil("G.phase==='OFFERINGS' && !R.busy");
assert.equal(r('G.players.every(p=>lands(p.id).length===3&&basicCount(p.id)===3&&fleetCount(p.id)===3)'),true,'Setup forces');
assert.equal(r('G.creatures.length'),4);assert.equal(r('G.heroes.length'),2);assert.equal(r('CREATURES.length'),18);assert.equal(r('HEROES.length'),9);
r('renderAll()');assert.equal((el('factions-hud').innerHTML.match(/Hidden/g)||[]).length,2);
fs.writeFileSync(require('path').join(require('os').tmpdir(),'cyclades-rules-map.svg'),'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1120" height="1380" viewBox="0 0 560 690"><style>.zone-hit{fill:transparent;stroke:none}.sea-name{font:italic 8px Georgia;fill:#c8e7df}.land-name{font:9px Georgia;fill:#fff4ce;paint-order:stroke;stroke:#283d37;stroke-width:2.5px}.unit-number{font:bold 10px Arial;fill:#fff8dd}</style>'+el('archipelago').innerHTML.replaceAll('href="#','xlink:href="#')+'</svg>');
const steps=await drainUntil("G.phase==='GAME_OVER' && !R.busy",6000);console.log('Full campaign completed in',r('G.cycle'),'cycles and',steps,'scheduled steps');
for(const n of nodes.values()){for(const m of n.innerHTML.matchAll(/src="([^"<>]+)"/g))assert(fs.existsSync(root+'/'+m[1]),'Missing asset '+m[1]);for(const m of n.innerHTML.matchAll(/onclick="([^"]+)"/g))new vm.Script(m[1])}
assert(r('G.players.every(p=>p.gp>=0&&p.priests>=0&&p.phils>=0)'));
assert(r('G.players.every(p=>basicCount(p.id)<=8&&fleetCount(p.id)<=8)'));
assert(r('mercCount()<=15'));
console.log('PASS: full campaign, hidden gold, setup, roster sizes, asset references, controls, reserve and nonnegative-resource invariants.');
})().catch(e=>{console.error(e);process.exitCode=1});
