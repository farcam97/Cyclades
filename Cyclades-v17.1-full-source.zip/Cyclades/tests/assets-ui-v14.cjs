const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},querySelectorAll(){return []},style:{setProperty(){}},addEventListener(){},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {width:560,height:690}},focus(){}};nodes.set(id,n);return n}
const c=vm.createContext({document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','tiles-v14.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js','usability.js','immersion.js','campaign-tools.js','campaign-v11.js','streamlined-v12.js','polish-v13.js','maelstrom-v14.js','faq-v14.js','interface-v14.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}
let passed=0;
function fixture(){r("setupConfig.count=3;setupConfig.faction=0;startConfiguredGame();timers.forEach(clearTimeout);timers.clear();R.busy=false;R.auto=true;G.phase='ACTIONS';G.activeBidder=0;G.turnState={recruitedCount:0,boughtExtraCard:false,hiredHero:false,peeked:false,heroMoves:{}};G.players.forEach(p=>{p.gp=30;p.god='ARES'});G.zones.filter(z=>z.type==='land').forEach(z=>{z.owner=Math.floor(z.id/4);z.troops=1});G.logs=[];G.zones=RULE_MAP.map(z=>({...z,adj:[...z.adj],owner:z.type==='land'?Math.floor(z.id/4):null,troops:z.type==='land'?1:0,mercs:0,fleets:0,heroes:[],bldgs:[],metros:[],metroUsed:[],templeUses:[],capacity:1,pros:z.pros||0}));delete G.zones[0].macroShapes");q.clear()}
async function test(name,fn){fixture();await fn();passed++;console.log('PASS',name)}
(async()=>{
fixture();
for(const category of ['gods','heroes','creatures','rules'])r(`renderReferenceCategory('${category}')`);
for(const id of r('[...HEROES,...CREATURES].map(u=>u.id)')){
 r(`showUnitInfo('${id}')`);
 const html=el('app-panel-content').innerHTML;
 for(const [,src] of html.matchAll(/(?:src|href)="(assets\/[^"?#]+)"/g))assert(fs.existsSync(root+'/'+src),'Missing '+src);
}
for(const category of ['display','sound','animation','controls','campaign','info']){r(`renderSettingsCategory('${category}')`);assert(!el('app-panel-content').innerHTML.includes('undefined'))}
for(const name of ['ARES','POSEIDON','HERA'])for(let n=0;n<4;n++){
 r(`G.players[0].god='${name}';G.turnState.recruitedCount=${n};R.auto=false;R.inspected=${name==='POSEIDON'?12:0};renderActionButtons()`);
 if(n<3)assert(el('action-btns').innerHTML.includes('gold'));
 assert(!el('action-btns').innerHTML.includes('Reserves'));
}
console.log('PASS all hero/creature card assets, reference categories, settings categories and recruitment cost states');
})().catch(e=>{console.error(e);process.exitCode=1});
