const{test,expect}=require('@playwright/test');
async function prepare(page){await page.goto('/');await page.evaluate(()=>{skipIntro();APP.sound=false;APP.motion=false;APP.cinematics=false;APP.performanceMode=true;APP.battleManual=true;APP.confirmMap=true;startConfiguredGame();R.epoch++;timers.forEach(clearTimeout);timers.clear();R.pending=null;R.busy=false;B=null;G.phase='ACTIONS';G.activeBidder=0;G.actionOrder=[0,1,2];G.activePlayerIdx=0;G.players.forEach(p=>{p.god='ARES';p.gp=20});document.getElementById('welcome').hidden=true;document.body.classList.remove('title-active');switchTab('map');renderAll()})}
test('dark mode has bright text and colored building counters',async({page})=>{
 await prepare(page);await page.evaluate(()=>{updatePreference('darkTheme',true);showAppPanel('settings')});
 expect(await page.locator('.setting-row').first().evaluate(el=>getComputedStyle(el).color)).toBe('rgb(247, 251, 255)');
 const colors=await page.locator('#phase-label .building-counter').evaluateAll(els=>els.map(el=>getComputedStyle(el).color));expect(new Set(colors).size).toBeGreaterThan(2);
 await page.screenshot({path:'artifacts/dark-settings-v16.2.png'});
});
test('only Close stays accessible after scrolling settings',async({page})=>{
 await page.setViewportSize({width:390,height:540});await prepare(page);await page.evaluate(()=>showAppPanel('settings'));
 const close=page.getByRole('button',{name:'Close tools',exact:true}),before=await close.boundingBox();
 await page.locator('.app-panel-box').evaluate(el=>el.scrollTop=el.scrollHeight);const after=await close.boundingBox();
 expect(after.y).toBeGreaterThanOrEqual(0);expect(after.y+after.height).toBeLessThanOrEqual(540);await close.click();await expect(page.locator('#app-panel')).toBeHidden();
});
test('offering badges display live counts on white backgrounds with no blank masks',async({page})=>{
 await prepare(page);const id=await page.evaluate(()=>{const z=G.zones.find(z=>z.printedHorns.length);z.pros=3;renderAll();return z.id});
 
 expect(await page.evaluate(id=>{const z=G.zones[id],s=offerings16(z);return s.includes('data-offerings="3"')&&s.includes('fill="#fff"')&&!s.includes('#eddbab')},id)).toBe(true);
 expect(await page.evaluate(id=>{G.zones[id].pros=0;renderAll();return offerings16(G.zones[id]).includes('data-offerings="0"')},id)).toBe(true);
 const broken=await page.locator('img').evaluateAll(imgs=>imgs.filter(i=>i.complete&&i.naturalWidth===0).map(i=>i.src));expect(broken).toEqual([]);
 await page.screenshot({path:'artifacts/map-layout-v16.2.png'});
});
test('map footprints stay within their territory and avoid offering plaques',async({page})=>{
 await prepare(page);
 const issues=await page.evaluate(()=>{G.zones.forEach((z,i)=>{z.owner=i%3;if(z.type==='land')z.troops=6;else z.fleets=4});renderAll();const issues=[];for(const z of G.zones){const l=layout16(z);for(const p of l.points){if(!layoutRectInside(z,p.x,p.y,p.w,p.h))issues.push('outside '+z.id);if(l.badge&&Math.abs(p.x-l.badge.x)<(p.w+l.badge.w)/2&&Math.abs(p.y-l.badge.y)<(p.h+l.badge.h)/2)issues.push('badge overlap '+z.id)}}return issues});
 expect(issues).toEqual([]);
});
test('Back and Confirm are compact text rectangles, with Confirm on the right',async({page})=>{
 await prepare(page);await page.evaluate(()=>{document.getElementById('action-btns').innerHTML=actionButton('Confirm','confirmSpaceSelection()')+actionButton('Back','undoSpaceSelection()')});
 const confirm=page.locator('#action-btns').getByRole('button',{name:'Confirm',exact:true}),back=page.locator('#action-btns').getByRole('button',{name:'Back',exact:true});
 expect((await confirm.boundingBox()).x).toBeGreaterThan((await back.boundingBox()).x);await expect(confirm.locator('.action-disc')).toHaveCount(0);await expect(back.locator('.action-disc')).toHaveCount(0);await expect(confirm).toHaveClass(/rectangular-action/);
});
test('narration disappears without leaving duplicate prompt text',async({page})=>{
 await prepare(page);await page.evaluate(()=>{followCamera=false;window.notice=observation('Lion takes a Priestess from Eagle.',null,0)});await expect(page.locator('#ai-caption')).toBeVisible();
 await expect(page.locator('#ai-caption')).toBeHidden({timeout:3500});await expect(page.locator('#prompt-text')).not.toHaveText('Lion takes a Priestess from Eagle.');
 await page.evaluate(()=>observation('Lion summons a Creature.',null,0));await expect(page.locator('#ai-caption')).toBeHidden();
});
test('battle waits for Continue even with animations disabled, then holds the outcome',async({page})=>{
 await prepare(page);await page.evaluate(()=>{const a=G.zones.find(z=>z.type==='land'),d=G.zones.filter(z=>z.type==='land')[1];a.owner=0;a.troops=2;a.heroes=[];d.owner=1;d.troops=1;d.mercs=0;d.heroes=[];d.bldgs=[];d.metros=[];G.monsters=[];battleDie=async pid=>pid===0?3:0;R.busy=true;window.fight=battle(G.players[0],a,d,{troops:2,mercs:0,heroes:[],minotaur:null},'land')});
 await page.locator('#battle-actions').getByRole('button',{name:'Roll battle dice',exact:true}).click();
 const next=page.locator('#battle-actions').getByRole('button',{name:'Continue',exact:true});await expect(next).toBeVisible();await page.waitForTimeout(300);expect(await page.evaluate(()=>!!B&&!!battleContinueJob)).toBe(true);await next.click();
 const done=page.locator('#battle-actions').getByRole('button',{name:'Return to map',exact:true});await expect(done).toBeVisible();await page.screenshot({path:'artifacts/battle-outcome-v16.2.png'});await done.click();await expect.poll(()=>page.evaluate(()=>B===null)).toBe(true);
});
test('Triton selects the exact glowing building on the map before confirmation',async({page})=>{
 await prepare(page);const target=await page.evaluate(()=>{G.zones.forEach(z=>{z.bldgs=[];z.metros=[];z.heroes=[];z.troops=0;z.fleets=0});const mine=G.zones.find(z=>z.type==='land'),enemy=G.zones.filter(z=>z.type==='land'&&z.capacity>=2)[1];mine.owner=0;enemy.owner=1;enemy.bldgs=['F','T'];G.monsters=[];window.tritonRun=playCreature(G.players[0],CREATURES.find(c=>c.id==='triton'));return{zone:enemy.id,mine:mine.id}});
 await expect(page.locator('.stealable-building')).toHaveCount(2);
 await expect(page.locator('#decision')).not.toHaveClass(/active/);
 await page.evaluate(id=>focusZone(id),target.zone);
 await page.locator(`[data-building-zone="${target.zone}"][data-building="1"]`).click();
 expect(await page.evaluate(()=>R.pending.options[currentStage().index].value.i)).toBe(1);
 await page.locator('#action-btns').getByRole('button',{name:'Confirm',exact:true}).click();
 await expect.poll(()=>page.evaluate(()=>R.pending?.title)).toBe('Place the stolen Building');
 await page.evaluate(id=>onZoneClick(id),target.mine);await page.locator('#action-btns').getByRole('button',{name:'Confirm',exact:true}).click();
 await expect.poll(()=>page.evaluate(id=>G.zones[id].bldgs.includes('T'),target.mine)).toBe(true);expect(await page.evaluate(id=>G.zones[id].bldgs.includes('T'),target.zone)).toBe(false);
});
test('intro covers the title from its first frame and has an explicit skip control',async({page})=>{
 await page.goto('/');await expect(page.locator('#game-intro')).toBeVisible();await expect(page.locator('.intro-skip')).toHaveText(/Skip intro/);
 expect(await page.evaluate(()=>{const r=document.getElementById('game-intro').getBoundingClientRect();return r.top<=0&&r.left<=0&&r.bottom>=innerHeight&&r.right>=innerWidth})).toBe(true);
 await page.screenshot({path:'artifacts/intro-v16.2.png'});await page.locator('#game-intro').click();await expect(page.locator('#game-intro')).toHaveCount(0);expect(await page.evaluate(()=>document.documentElement.classList.contains('intro-pending'))).toBe(false);
});
test('hero recruitment names the hero in both the announcement and Chronicle',async({page})=>{
 await prepare(page);const target=await page.evaluate(()=>{const z=G.zones.find(z=>z.type==='land');z.owner=0;z.heroes=[];G.players[0].god='HERA';G.heroes=[HEROES.find(h=>h.id==='ajax')];G.turnState.hiredHero=false;followCamera=false;window.hireRun=hireHero(G.players[0],0);return z.id});
 await expect.poll(()=>page.evaluate(()=>R.pending?.title)).toBe('Place your recruited Hero');await page.evaluate(id=>onZoneClick(id),target);await page.locator('#action-btns').getByRole('button',{name:'Confirm',exact:true}).click();
 await expect(page.locator('#ai-caption')).toContainText('recruits Ajax');expect(await page.evaluate(()=>G.logs.some(l=>l.includes('recruits Ajax')))).toBe(true);
});
test('map presentation preserves all territory shapes, sites and connections',async({page})=>{
 await prepare(page);expect(await page.evaluate(()=>{const snapshot=()=>JSON.stringify(G.zones.map(z=>[z.id,z.path,z.adj,z.polygon,z.buildingSites,z.capacity]));const before=snapshot();APP.darkTheme=true;APP.condensed=true;renderAll();APP.condensed=false;renderAll();return snapshot()===before})).toBe(true);
});
test('cinematic battles animate figures and still wait for the result to be read',async({page})=>{
 await prepare(page);await page.evaluate(()=>{APP.cinematics=true;APP.motion=true;APP.performanceMode=false;APP.speed=2;FX.reduced=false;const a=G.zones.find(z=>z.type==='land'),d=G.zones.filter(z=>z.type==='land')[1];a.owner=0;a.troops=2;a.heroes=[];d.owner=1;d.troops=1;d.mercs=0;d.heroes=[];d.bldgs=[];d.metros=[];G.monsters=[];battleDie=async pid=>pid===0?3:0;R.busy=true;window.fight=battle(G.players[0],a,d,{troops:2,mercs:0,heroes:[],minotaur:null},'land')});
 await page.locator('#battle-actions').getByRole('button',{name:'Roll battle dice',exact:true}).click();
 await expect.poll(()=>page.evaluate(()=>document.getElementById('battlefield')?.getAnimations({subtree:true}).some(a=>a.playState==='running'))).toBe(true);
 await expect(page.locator('#battle-actions').getByRole('button',{name:'Continue',exact:true})).toBeVisible();
 expect(await page.evaluate(()=>!!B&&!!battleContinueJob)).toBe(true);
});
test('dark battle panels use a dark surface behind bright text',async({page})=>{
 await prepare(page);await page.evaluate(()=>{updatePreference('darkTheme',true);const z=G.zones.find(z=>z.type==='land');B={type:'land',attId:0,defId:1,toId:z.id,att:{troops:2,mercs:0,heroes:[],minotaur:null},def:{troops:1,mercs:0,heroes:[],minotaur:null},round:1,report:{rounds:[],losses:{att:[],def:[]},retreats:[],events:[]}};showBattle('Prepare for battle')});
 expect(await page.locator('.battle-box').evaluate(el=>getComputedStyle(el).backgroundColor)).toBe('rgb(20, 44, 54)');await expect(page.locator('#battle-modal')).toHaveClass(/active/);
});
