// Exercise the real keyed SVG patcher with parsed, generated board markup.
// This DOM contract test does not claim browser rasterization or frame-rate coverage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),cp=require('child_process');
const code=fs.readFileSync(__dirname+'/../web/streamlined-v12.js','utf8');
const snippet=code.slice(code.indexOf('const boardMarkup='),code.indexOf('// Camera frames'));
const parse=s=>JSON.parse(cp.execFileSync('python3',['-c',`import sys,json
from lxml import etree
r=etree.fromstring(('<svg>'+sys.stdin.read()+'</svg>').encode())
def walk(n):
 return {'tag':n.tag,'attrs':dict(n.attrib),'text':n.text,'children':[walk(x) for x in n]}
print(json.dumps(walk(r)))`],{input:s,maxBuffer:4*1024*1024}));
class Node {
 constructor(tag,attrs={},text=null){this.nodeName=tag;this.nodeType=tag==='#text'?3:1;this.attrs={...attrs};this.nodeValue=text;this.childNodes=[];this.parent=null}
 get children(){return this.childNodes.filter(n=>n.nodeType===1)}get id(){return this.attrs.id||''}
 get attributes(){return Object.entries(this.attrs).map(([name,value])=>({name,value}))}
 getAttribute(k){return this.attrs[k]??null}hasAttribute(k){return k in this.attrs}setAttribute(k,v){this.attrs[k]=String(v)}removeAttribute(k){delete this.attrs[k]}
 appendChild(n){n.remove();n.parent=this;this.childNodes.push(n);return n}remove(){if(this.parent){this.parent.childNodes.splice(this.parent.childNodes.indexOf(this),1);this.parent=null}}
 replaceWith(n){const p=this.parent,i=p.childNodes.indexOf(this);n.remove();p.childNodes[i]=n;n.parent=p;this.parent=null}
 get outerHTML(){return JSON.stringify([this.nodeName,this.attrs,this.nodeValue,this.childNodes.map(n=>n.outerHTML)])}
 set innerHTML(s){this.childNodes=[];for(const n of build(parse(s)).childNodes.slice())this.appendChild(n)}
 querySelectorAll(sel){const names=sel.split(',').map(x=>x.slice(1));return this.children.flatMap(n=>[...((n.attrs.class||'').split(' ').some(c=>names.includes(c))?[n]:[]),...n.querySelectorAll(sel)])}
}
function build(x){const n=new Node(x.tag,x.attrs);if(x.text)n.appendChild(new Node('#text',{},x.text));for(const c of x.children)n.appendChild(build(c));return n}
const root=new Node('svg'),G={zones:[]},PERF={};const c=vm.createContext({G,PERF,$:()=>root,document:{createElementNS:()=>new Node('svg')},console});vm.runInContext(snippet,c);
cp.execFileSync(process.execPath,[__dirname+'/render-v14.cjs']);
let markup=fs.readFileSync(require('path').join(require('os').tmpdir(),'cyclades-check-map.svg'),'utf8').replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'');
markup=markup.replace(/\s+on\w+="[^"]*"/g,'').replaceAll('&','&amp;');
const render=s=>{c.markup=s;vm.runInContext('reconcileBoard(markup)',c)};
render(markup);render(markup);const initial=[...root.children],images=root.querySelectorAll('.uploaded-tile-art');assert(images.length>0);
for(let i=0;i<3;i++){render(markup);assert(root.children.every((n,j)=>n===initial[j]));assert(root.querySelectorAll('.uploaded-tile-art').every((n,j)=>n===images[j]));}
const zone=root.children.find(n=>n.id==='zone-0'),picture=zone.children.find(n=>n.nodeName==='image'),originalPath=zone.children[0];
const changed=markup.replace('id="zone-0"','data-check="changed" id="zone-0"');render(changed);assert.equal(zone.getAttribute('data-check'),'changed');assert.strictEqual(zone.children[0],originalPath);if(picture)assert(zone.children.includes(picture));assert(root.querySelectorAll('.uploaded-tile-art').every((n,j)=>n===images[j]));
render(markup);assert(!zone.hasAttribute('data-check'));assert.strictEqual(root.children.find(n=>n.id==='zone-0'),zone);
const ids=[];function visit(n){if(n.id)ids.push(n.id);n.children.forEach(visit)}visit(root);assert.equal(new Set(ids).size,ids.length,'no duplicate SVG IDs');
console.log('PASS actual generated board: static coastline/image identity preserved across repeated and changed renders, attributes patched in place, no duplicate IDs');
