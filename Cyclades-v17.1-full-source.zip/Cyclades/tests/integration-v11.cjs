const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},querySelectorAll(){return []},style:{setProperty(){}},addEventListener(){},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {left:0,top:0,width:560,height:690}},focus(){}};nodes.set(id,n);return n}
const storage=new Map();const c=vm.createContext({document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js','usability.js','immersion.js','campaign-tools.js','campaign-v11.js','streamlined-v12.js','polish-v13.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}


(async()=>{
r('setupConfig.count=6;startConfiguredGame();R.auto=true');await drainUntil("G.phase==='OFFERINGS'&&!R.busy");q.clear();r('timers.forEach(clearTimeout);timers.clear()');
// Reserve shared gold for a teammate's outstanding offering.
r("G.players[0].gp=10;G.players[1].bid=7;G.players[1].priests=2;G.players[0].priests=1");assert.equal(r('maximumOffer(G.players[0])'),6);r('G.players[0].gp-=2');assert.equal(r('G.players[1].gp'),8);
// Four buildings across a team produce a team metropolis, forced singles are never prompted.
r("G.players.forEach(p=>p.god='ARES');G.zones.forEach(z=>{z.bldgs=[];z.metros=[]});globalThis.a=lands(0)[0];globalThis.b=lands(1)[0];a.bldgs=['F','P'];b.bldgs=['T','U'];G.metroDeck=['gold'];G.phase='ACTIONS';G.activeBidder=0");await r('settle(G.players[0])');assert.equal(r('teamScore(G.players[0])'),1);assert.equal(r('teamLands(G.players[0]).flatMap(z=>z.bldgs).length'),0);
assert(!r('canAttack(0,lands(1)[0])'));assert(!r('landTargets(G.players[0],lands(0)[0],true).some(z=>z.owner===1)'));
// Rendering never mutates heroes or monsters.
r("a.heroes=[{...HEROES[0],summonedCycle:0}];G.monsters=[{id:'hydra',owner:0,zone:a.id}]");const before=r('JSON.stringify(G)');r('renderAll();renderAll()');assert.equal(r('JSON.stringify(G)'),before);
// A genuine human checkpoint imports, including shared treasury restoration.
r("R.auto=false;G.phase='ACTIONS';G.activeBidder=0;R.busy=false;R.pending=null;G.turnState={heroMoves:{}};checkpointGame()");assert(r('readSave()'));assert(r('validateImportedCampaign(readSave())'));const save=r('JSON.stringify(readSave())');r('G.players[0].gp=99;resumeCampaign()');assert.equal(r('G.players[0].gp'),r('G.players[1].gp'));r('G.players[1].gp--');assert.equal(r('G.players[0].gp'),r('G.players[1].gp'));
for(const patch of ["s.state.teams[0].gold=-1","s.state.players[0].gp=-1","s.state.players[0].faction=99","s.state.zones[0].name='<img>'","s.state.zones[0].adj=[999]"]){assert.throws(()=>r(`(()=>{const s=JSON.parse(${JSON.stringify(save)});${patch};return validateImportedCampaign(s)})()`))}
// Faction choice is independent of seat and two-player human control changes correctly.
r('setupConfig.count=2;setupConfig.faction=5;startConfiguredGame();R.auto=true');await drainUntil("G.phase==='OFFERINGS'&&!R.busy");q.clear();r('timers.forEach(clearTimeout);timers.clear();R.auto=false;G.activeBidder=1');assert(r('human(1)'));assert.equal(r('humanPid()'),1);assert.equal(r('G.players[0].name'),'Fish');assert(r('factionAsset(0,"warrior").includes("warrior-5")'));
console.log('PASS shared treasury, bid reservations, team building conversion, allied attack exclusion, pure rendering, save/import validation, treasury restore, faction identity and two-faction control');
})().catch(e=>{console.error(e);process.exitCode=1});
