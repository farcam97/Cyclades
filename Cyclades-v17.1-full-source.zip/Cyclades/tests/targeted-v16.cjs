const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},querySelectorAll(){return []},style:{setProperty(){}},listeners:{},addEventListener(k,f){(this.listeners[k]??=[]).push(f)},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {left:0,top:0,width:560,height:690}},remove(){},focus(){}};nodes.set(id,n);return n}
const storage=new Map();const c=vm.createContext({document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','tiles-v14.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js','usability.js','immersion.js','campaign-tools.js','campaign-v11.js','streamlined-v12.js','polish-v13.js','maelstrom-v14.js','faq-v14.js','interface-v14.js','interface-v15.js','board-layout.js','interface-v16.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}



(async()=>{
for(const shape of ['tall','wide'])for(const count of [2,3,4,5,6]){
 r(`setupConfig.count=${count};setupConfig.mapShape='${shape}';setupConfig.spectator=true;APP.maelstrom=true;startConfiguredGame();R.auto=true`);
 await drainUntil("G.phase==='OFFERINGS'&&!R.busy");q.clear();r('timers.forEach(clearTimeout);timers.clear()');
 assert(r('G.players.every(p=>p.controller!==0)'));assert(r('G.zones.every(z=>z.adj.every(i=>G.zones[i].adj.includes(z.id)))'));
 assert(r('G.zones.every(z=>z.buildingSites.length===z.capacity)'));
 assert(r('G.zones.every(z=>z.polygon.every(([x,y])=>x>=-1e-6&&x<=boardFrame().width+1e-6&&y>=-1e-6&&y<=boardFrame().height+1e-6))'));
 if(shape==='wide')assert(r('boardFrame().width>boardFrame().height'));
 r('resetMapView()');const ev=(id,x,y)=>({pointerId:id,clientX:x,clientY:y,pointerType:'touch',preventDefault(){}});c.e1=ev(1,120,200);c.e2=ev(2,320,200);c.e3=ev(2,420,200);
 r('pointerDown15(e1);pointerDown15(e2);pointerMove15(e3)');assert.equal(r('viewZoom'),1.5);
 c.e3=ev(2,170,200);r('pointerMove15(e3)');assert.equal(r('viewZoom'),1);assert.equal(r('viewX+viewY'),0);
 r('pointerEnd15(e1);pointerEnd15(e3)');assert.equal(r('pointers.size'),0);assert.equal(r('gesture'),null);
 r('viewZoom=2;viewX=80;viewY=30;applyView()');const before=r('JSON.stringify(G)');c.pt=r('zoneScreen(G.zones[0].id)');const mapped=r('screenBoardPoint(pt.x,pt.y)');assert(Math.abs(mapped.x-r('G.zones[0].x'))<1e-7);assert(Math.abs(mapped.y-r('G.zones[0].y'))<1e-7);assert.equal(r('JSON.stringify(G)'),before);
 console.log('PASS layout/setup/pinch/coordinate round-trip',shape,count);
}
// Boar can move a selected quantity together, respecting non-mixing of factions.
r("G.monsters=[];G.zones.forEach(z=>{z.troops=0;z.mercs=0;z.heroes=[];z.owner=null});globalThis.source=G.zones.find(z=>z.type==='land'&&z.adj.some(i=>G.zones[i].type==='land'));globalThis.dest=G.zones[source.adj.find(i=>G.zones[i].type==='land')];source.owner=1;source.troops=3;G.monsters=[{id:'calydonian-boar',owner:0,zone:source.id}];globalThis.decisions=[];globalThis.originalAsk=ask;ask=async function(pid,title,opts){decisions.push(title);if(title.includes('how many'))return 2;if(title.includes('adjacent land'))return dest.id;return opts[0]?.value??null}");
await r('activateMonster(G.monsters[0])');assert.equal(r('source.troops'),0);assert.equal(r('dest.troops'),3);assert(r("decisions.some(t=>t.includes('how many'))"));r('ask=originalAsk');
console.log('PASS grouped Boar displacement');
// Plan actual enemy battles of both types; route choices must honor the plan.
for(const type of ['land','sea']){
 r(`G.monsters=[];G.teams=null;G.players.forEach(p=>{delete p.team;p.gp=20;p.god='${type==='sea'?'POSEIDON':'ARES'}';p.difficulty='medium'});G.zones.forEach(z=>{z.owner=null;z.troops=0;z.mercs=0;z.fleets=0;z.heroes=[];z.bldgs=[];z.metros=[]});globalThis.a=G.zones.find(z=>z.type==='${type}'&&z.adj.some(i=>G.zones[i].type==='${type}'));globalThis.b=G.zones[a.adj.find(i=>G.zones[i].type==='${type}')];a.owner=0;b.owner=1;a.${type==='sea'?'fleets':'troops'}=5;b.${type==='sea'?'fleets':'troops'}=1;b.pros=20;G.zones.filter(z=>z.type==='land'&&z!==a&&z!==b).slice(0,2).forEach(z=>z.owner=1);G.activeBidder=0;G.turnState={heroMoves:{},heroicMoves:0};globalThis.plan=planAIMove15(G.players[0],'${type}');globalThis.calls=0;globalThis.originalBattle=battle;battle=async function(...args){calls++;return originalBattle(...args)}`);
 assert(r('plan&&plan.to===b.id'),'enemy plan '+type);await r('executeAIPlan15(G.players[0],plan)');assert.equal(r('calls'),1);assert(r('G.lastBattle.rounds.length>0'));assert(r('G.players.every(p=>p.gp>=0)'));r('battle=originalBattle');console.log('PASS CPU vs CPU resolved',type);
}
console.log('V15 TARGETED CHECKS PASSED');
})().catch(e=>{console.error(e);process.exitCode=1});
