const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},addEventListener(){},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {width:560,height:690}},focus(){}};nodes.set(id,n);return n}
const storage=new Map();const c=vm.createContext({localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}
(async()=>{
await drainUntil("G.phase==='OFFERINGS'&&!R.busy");
r("timers.forEach(clearTimeout);timers.clear();R.auto=false;G.phase='ACTIONS';G.activeBidder=0;G.players[0].god='ARES';G.turnState={recruitedCount:1,boughtExtraCard:false,hiredHero:false,peeked:false,heroMoves:{}};R.busy=false");
assert(r('checkpointGame()'));const old=r('JSON.stringify(G)');r('G.players[0].gp=999');assert(r('resumeCampaign()'));assert.equal(r('JSON.stringify(G)'),old);assert.equal(r('G.turnState.recruitedCount'),1);
r("R.busy=true;G.players[0].gp=777");assert.equal(r('checkpointGame()'),false);r('R.busy=false;resumeCampaign()');assert.equal(r('JSON.stringify(G)'),old);
r('APP.sound=false;APP.labels=false;saveSettings()');assert.equal(JSON.parse(storage.get('cyclades-settings-v5')).sound,false);
r("$('force-t').min=0;$('force-t').max=3;$('force-t').value=2;stepForce('force-t',5)");assert.equal(r("Number($('force-t').value)"),3);r("stepForce('force-t',-10)");assert.equal(r("Number($('force-t').value)"),0);
assert.equal(r('ANIMATIONS.length'),400);assert.equal(r('new Set(ANIMATIONS.map(a=>a.name)).size'),400);for(const a of r('ANIMATIONS')){const frames=a.id>300?r(`beatFrames(${JSON.stringify(a.beat)})`):a.id>200?r(`sceneProfile(${JSON.stringify(a.action)},0).frames`):a.id<=100?r(`motionFrames(${JSON.stringify(a.name)},${a.id})`):r(`${a.category==='water'?'waterMotionFrames':'unitMotionFrames'}(ANIMATIONS[${a.id-1}])`);assert(frames.length>=3);assert(!JSON.stringify(frames).includes('NaN'))}
for(const z of r("G.zones.filter(z=>z.type==='land')"))assert.equal(r(`mapZoneAt(${z.x},${z.y}).id`),z.id);
r("checkpoints.length=0;checkpoints.push(JSON.stringify(G));globalThis.pendingCancelled=false;R.pending={reject(){pendingCancelled=true},options:[]};R.busy=true");assert(r('canCancelOptional()'));r('cancelOptionalAction()');assert(r('pendingCancelled&&!R.pending&&!R.busy'));assert.equal(r('JSON.stringify(G)'),old);
r("checkpoints.push(JSON.stringify(G));R.pending={options:[]};G.players[0].gp--");assert(!r('canCancelOptional()'));r('R.pending=null');
const snapshot=JSON.parse(storage.get(SAVE_KEY='cyclades-campaign-v5'));snapshot.version=3;storage.set('cyclades-campaign-v5',JSON.stringify(snapshot));assert.equal(r('readSave()'),null);
fs.writeFileSync(root+'/animation-catalog.json',JSON.stringify(r('ANIMATIONS'),null,2));
console.log('PASS: checkpoint round trip, stable-only saving, unchanged turn state, preference persistence, force stepper bounds, 400 motion profiles, coast-accurate hit centers, safe cancellation, save version validation.');
})().catch(e=>{console.error(e);process.exitCode=1});
