const {test,expect}=require('@playwright/test');
async function load(page){await page.goto('/');await page.evaluate(()=>{skipIntro();APP.sound=false;APP.motion=false;APP.cinematics=false;APP.performanceMode=true;});}
async function stableCampaign(page){return page.evaluate(()=>{startConfiguredGame();R.epoch++;timers.forEach(clearTimeout);timers.clear();R.pending=null;R.busy=false;B=null;G.phase='ACTIONS';G.activeBidder=0;G.actionOrder=[0,1,2];G.activePlayerIdx=0;G.players[0].god='ARES';G.turnState={...G.turnState,recruitedCount:0};return JSON.parse(JSON.stringify(G));});}
test('startup, phone/tablet/landscape setup and keyboard dialog focus',async({page})=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));await load(page);
 for(const viewport of [{width:360,height:740},{width:844,height:390},{width:1024,height:768}]){await page.setViewportSize(viewport);await page.evaluate(()=>openSetup());await expect(page.locator('#app-panel')).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.keyboard.press('Tab');expect(await page.evaluate(()=>document.getElementById('app-panel').contains(document.activeElement))).toBe(true);await page.keyboard.press('Escape');await expect(page.locator('#app-panel')).toBeHidden();}
 await page.waitForTimeout(500);expect(errors).toEqual([]);
});
test('checkpoint includes piece changes and retries failed writes',async({page})=>{
 await load(page);await stableCampaign(page);
 expect(await page.evaluate(()=>checkpointGame())).toBe(true);
 expect(await page.evaluate(()=>{const z=G.zones.find(z=>z.type==='land');z.troops++;return checkpointGame()&&readSave().state.zones[z.id].troops===z.troops})).toBe(true);
 expect(await page.evaluate(()=>{G.cycle++;const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k===SAVE_KEY)throw new DOMException('full','QuotaExceededError');return original.call(this,k,v)};const failed=checkpointGame();Storage.prototype.setItem=original;const retried=checkpointGame();return !failed&&retried&&readSave().state.cycle===G.cycle})).toBe(true);
});
test('corrupt checkpoint recovers and malformed imports are rejected',async({page})=>{
 await load(page);await stableCampaign(page);
 const recovery=await page.evaluate(()=>{checkpointGame();G.cycle=2;checkpointGame();localStorage.setItem(SAVE_KEY,'{corrupt');return readSave()?.state.cycle});expect(recovery).toBe(1);
 expect(await page.evaluate(()=>[null,{}, {version:5,state:{players:{length:3},zones:[]}}].every(s=>{try{return !validSave(s)}catch{return false}}))).toBe(true);
 expect(await page.evaluate(()=>{const s=readSave();s.state.zones[0].adj=[99999];try{validateImportedCampaign(s);return false}catch{return true}})).toBe(true);
});
test('map regions expose names and keyboard selection',async({page})=>{
 await load(page);await stableCampaign(page);await page.evaluate(()=>{document.getElementById('welcome').hidden=true;document.body.classList.remove('title-active');switchTab('map');renderAll()});
 const region=page.locator('[id^="region-"]').first();await expect(region).toHaveAttribute('role','button');await expect(region).toHaveAttribute('aria-label',/land|sea/);await region.focus();await page.keyboard.press('Enter');expect(await page.evaluate(()=>R.inspected)).toBe(0);
});
test('audio cleanup completes without asynchronous errors',async({page})=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));await load(page);await page.evaluate(async()=>{APP.sound=true;APP.stereo=false;await playFoley('wood','UI')});await page.waitForTimeout(800);expect(errors).toEqual([]);
});
test('auction cache invalidates when resources change without log changes',async({page})=>{
 await load(page);expect(await page.evaluate(()=>{let calls=0;const fn=memoPanel(()=>++calls);fn();fn();G.players[0].gp++;fn();return calls})).toBe(2);
});
test('import storage failure preserves the previous checkpoint',async({page})=>{
 await load(page);await stableCampaign(page);
 expect(await page.evaluate(()=>{checkpointGame();const before=localStorage.getItem(SAVE_KEY);importCandidate=readSave();importCandidate.state.cycle=9;const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k===SAVE_KEY)throw Error('quota');return original.call(this,k,v)};const ok=acceptImportedCampaign();Storage.prototype.setItem=original;return !ok&&localStorage.getItem(SAVE_KEY)===before})).toBe(true);
});
test('completed checkpoint restores the same campaign state',async({page})=>{
 await load(page);const before=await stableCampaign(page);await page.evaluate(()=>{checkpointGame();G.cycle=99;resumeCampaign()});expect(await page.evaluate(()=>JSON.parse(JSON.stringify(G)))).toEqual(before);
});
test('automated game reaches a winner without browser errors',async({page})=>{
 test.setTimeout(120000);const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});await load(page);
 await page.evaluate(()=>{startConfiguredGame();R.auto=true;const timeout=window.setTimeout;window.setTimeout=(fn,ms,...args)=>timeout(fn,Math.min(ms,5),...args)});
 await expect.poll(()=>page.evaluate(()=>G.phase),{timeout:110000,intervals:[1000]}).toBe('GAME_OVER');
 expect(await page.evaluate(()=>G.players.every(p=>Number.isFinite(p.gp)&&p.gp>=0))).toBe(true);expect(errors).toEqual([]);
});
for(const count of [2,3,4,5,6])test(`existing ${count}-player configuration completes setup and a cycle`,async({page})=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));await load(page);await page.evaluate(count=>{setupConfig.count=count;setupConfig.mapShape=count%2?'tall':'wide';setupConfig.maelstrom=count===4;startConfiguredGame();R.auto=true;const timeout=window.setTimeout;window.setTimeout=(fn,ms,...args)=>timeout(fn,Math.min(ms,5),...args)},count);
 await expect.poll(()=>page.evaluate(()=>G.cycle),{timeout:45000,intervals:[500]}).toBeGreaterThan(1);
 expect(await page.evaluate(()=>G.zones.every(z=>z.owner===null||G.players[z.owner])&&G.players.every(p=>p.gp>=0))).toBeTruthy();expect(errors).toEqual([]);
});
test('rules guide navigates without changing a campaign',async({page})=>{
 await load(page);const before=await page.evaluate(()=>JSON.stringify(G));
 await page.evaluate(()=>showQuickGuide());await expect(page.locator('#guide-heading')).toHaveText('Your next decision');
 for(let i=0;i<5;i++)await page.getByRole('button',{name:'Next',exact:true}).click();
 await expect(page.locator('#guide-heading')).toHaveText('Keep a recoverable campaign');
 await page.getByRole('button',{name:'Return to game',exact:true}).click();await expect(page.locator('#app-panel')).toBeHidden();expect(await page.evaluate(()=>JSON.stringify(G))).toBe(before);
});
test('Apollo accepts one faction and computer bids for a different god',async({page})=>{
 await load(page);await stableCampaign(page);
 expect(await page.evaluate(()=>{G.players.forEach(p=>{p.god=null;p.bid=0;p.gp=20});G.phase='OFFERINGS';G.biddingQueue=[0,1,2];G.activeBidder=0;placeBid(0,'APOLLO',0);placeBid(1,'APOLLO',0);const blocked=G.players.filter(p=>p.god==='APOLLO').length===1&&G.biddingQueue[0]===1;aiBid(G.players[1]);return blocked&&G.players[1].god!=='APOLLO'&&G.players[1].god!==null&&G.players.filter(p=>p.god==='APOLLO').length===1})).toBe(true);
});
