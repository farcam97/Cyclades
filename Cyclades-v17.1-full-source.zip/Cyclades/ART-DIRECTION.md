# Painted edition

Replaces the geometric map renderer with project-bound painted WebP sprites in `dist/assets/painted/`. The new presentation is `dist/painted.js` and `dist/painted.css`; the previous engine continues to own rules, randomness, hidden information and legal-area decisions.

## Source and generation

Built-in image generation used the user's tile and miniature reference images. No CLI or API fallback was used.

Atlas prompt: production transparent 3-column by 4-row game sprite atlas, six different top-down Greek islands with natural coves, limestone cliffs, forests, footpaths and clear token areas; gold Lion hoplite, crimson Scorpion spearman and purple Eagle archer; three matching sculpted-prow galleys. Rich painted fantasy board-game illustration, dimensional armor, warm limestone, hand-inked edges, no text or UI. References were the supplied Cyclades common-material and faction-miniature sheets.

Building prompt: transparent horizontal atlas of a terracotta fortress, turquoise harbor, lavender Greek temple, ivory circular university, and walled metropolis combining those structures. Elevated isometric view, painted details, limestone and gilded accents, complete silhouettes and no text.

The generated atlases were sliced into 17 runtime assets and compressed as alpha-preserving WebP. Sprite art is inspired by the references; neither artwork nor geometry is claimed to reproduce official tile faces exactly. Every new game still randomizes the map and shuffles island illustrations.

## Motion

`dist/animation-catalog.json` contains the 100 named motion treatments: 8 ambient, 12 interface, 18 faction action variants, 10 building, 12 god, 18 creature, 18 hero, and 4 battle effects. Some share motion primitives with different trajectories, art, colors and timing. These are event effects, not 100 frame-by-frame character sequences.

Chronicle includes a gallery to preview all 100 and a session-persistent reduced-motion control. OS reduced-motion preference is respected on initial load. Animations are presentation-only and never delay or resolve rules, spend resources, or expose hidden gold. Ambient effects on a map are cancelled when that map is redrawn.

## Verification

Static SVG render reviewed with embedded PNG equivalents of WebP assets. Runtime assets retain WebP for browsers. Logic verified with the presentation scripts loaded: 32 targeted rule cases, 200 unique connected maps, 20 complete randomized setups, complete AI campaign, 100 unique catalog entries, all effect asset paths and motion profiles, reduced-motion toggles. Browser and physical-device QA unavailable in this environment; no browser screenshot is claimed.

# Macro-tile / living Aegean update

## Art and board
- Repainted all 18 Creature portraits, 9 Hero portraits, and 6 gods with the built-in image generator, using the supplied manual identity references and the existing painted terrain/warrior atlas as style reference. The full-bleed portraits live at their original runtime asset paths in `dist/assets/`.
- Repainted six larger single-landmass terrain assets without baked-in sea; saved in `dist/assets/painted/coast-0.webp` through `coast-5.webp`. Coast contours are traced from the alpha silhouette and simplified for runtime use in `dist/coasts.js`.
- Ten custom macro faces select six per game. Faces use either two connected land territories or two separate islands. Displayed borders, land hit polygons, coast-to-sea adjacency, and movement topology share the traced contours. Sea areas are partitioned separately and masked at land. These are reference-inspired layouts, not exact reproductions of the ten printed faces. One site per land remains this build's explicit map configuration.
- God panels now use large full-bleed illustrations with readable rules and offerings below the art. Hero and Creature portraits use the same painted finish; old tiny manual crops are replaced.

Generation briefs: 3x3 full-bleed atlas of Charon, Chimera, Cyclops, Dryad, Giant, Griffin, Harpy, Graeae, Pegasus; second 3x3 atlas of Satyr, Sphynx, Sylph, Cerberus, Hydra, Kraken, Medusa, Minotaur, Polyphemus; third 3x3 atlas of Ajax, Helen, Odysseus, Croesus, Hector, Penthesilea, Pandora, Perseus, Jason. Preserve manual identity cues and use detailed painted Greek environments, no UI or lettering. God atlas: 3x2 full-bleed Ares/Poseidon/Zeus/Athena/Hera/Apollo, preserved palettes and symbols. Terrain atlas: six single connected Greek landmasses, transparent surroundings, no water or labels, detailed olive forests and limestone coasts. Built-in generation only; atlases sliced to WebP assets and retained in the workspace generation folder.

## Controls and four app improvements
1. Browser-local completed-action autosave and resume, schema versioned. In-progress setup/battle/choices are deliberately not serialized; resume returns to the prior complete checkpoint, with that behavior explained in the app.
2. Current-turn checklist and contextual map actions.
3. Searchable reference for controls, gods, all Heroes and Creatures, and core rule topics.
4. Persistent settings for sound, volume, motion, names, tile boundaries and high contrast.

Additional touch behavior: direct force selection, skip redundant source prompt, force-size steppers, hold to focus, consistent 1–3.5x pinch/button zoom, pointer capture/cleanup, and cancel only before an optional action has changed game state. No post-reveal or post-spend rollback.

Selection audio uses Web Audio square oscillators with a short gain envelope, begins on user gestures, and can be muted or set to zero. No audio files or external audio service.

## Motion and verification
Catalog now contains 200 named treatments. Added 40 ship/weather action variants, 40 troop/faction action variants, and 20 near/far water patterns. Motion includes actual piece travel between source and destination, living ship/warrior sprites, wakes and waves. These are procedural motion treatments with shared primitives, not hand-drawn animation sequences. Gallery and reduced-motion preference cover both sets.

Verified: 200 randomized macro boards, connected/symmetric graph, coastal access, 20 complete starting setups, 32 rules regression cases on fixed fixtures, completed AI campaign with current presentation, all 200 profile names/frames, checkpoint round trip and resume turn state, preference persistence, cancellation only on unmodified actions, coast hit centers, force-size bounds, simulated pinch and pointer cleanup, shared zoom bounds. Static map render inspected. No browser/physical-device audio or touch QA was available; no claim of such testing.


# Current tabletop update

Terrain and faction sprites now use bold outlined, brighter 2D illustrations referencing the uploaded material and miniature sheets. New terrain uses `dist/assets/painted/coast-v6-{0..5}.webp`. Legal shapes are traced from alpha; artwork is clipped to those contours. Older saved boards retain their old coast art and geometry. New campaigns use the new terrain. All units are individual map elements, never count badges; large forces need zoom. Mercenaries have a pale treatment and white foot marker. Each Prosperity point has its own cornucopia; zero spaces display 0. Hydra still modifies income, not printed Prosperity.

Six god portraits now come directly from embedded images in the supplied manual (534, 569, 573, 658, 696, 700) and accompany four SVG power/cost icons each. This supersedes the previous generated god portraits. God order was already shuffled only at setup, then rotated first-to-bottom; this update makes that visible with a numbered track and next-cycle preview.

Selection audio now uses triangle/sine partials, filtered noise and short echo, with user-gesture startup and persistent mute/volume. Square-wave bleeps removed. Automatic auction and choice bursts, mandatory god-resolution effects, and idle ship/Troop swaying are disabled. Catalog now has 300 treatments: the additional 100 combine 20 actions with five spatial formations. Gallery includes older effects disabled during live play. These are procedural multi-part effects (projectiles, shields, rowing/oars, force travel, wakes, retreat, masonry), not hand-drawn sprite clips.

Six app improvements: staged map choices with Back before committing; movement/fleet-chain previews; illustrated piece legend; full-screen map with in-page fallback; last-battle dice/strength/casualty report; relaxed/normal/quick pacing. No changes to legal actions, costs, dice or victory.

Validation: full campaigns, 32 targeted rule cases, randomized geometry and 20 complete setups, individual piece and exact cornucopia counts including crowded force, staged/undo/confirm and stale-choice guard, post-bid suppression, 300 profile checks, save/resume, simulated pinch/pointer cleanup, fake-AudioContext waveform and mute checks. Normal and crowded static SVG renders inspected. Physical-phone browser, perceived audio and fullscreen device QA were unavailable.

Built-in image generation briefs: six isolated Mediterranean islands in a transparent 3×2 atlas, referencing the common-material tile sheet; bright lime/olive grass, outlined forests, ochre mountains, ivory shore, dark ink cliffs, top-down flat boardgame painting, no labels/buildings/water. Six-piece transparent 3×2 atlas referencing faction miniature sheets: gold Lion hoplite, crimson Scorpion hoplite, violet Eagle archer, plus matching lion/scorpion/eagle prow triremes; bold contours, luminous faction colors, cel shading, no bases/scenery, full silhouettes. Integrated at the versioned coast paths and existing warrior/fleet paths in dist/assets/painted.


# Current compact auction / cinematic battle update

Auction: two compact god rows/cards, five-slot rotation ribbon, small Apollo control, four engraved icon medallions per god, optional full power sheets. Responsive short-screen layout hides ancillary text and keeps offerings together. Creature market now renders four permanent price slots; purchases leave visible gaps. Explicit rotateCreatureTrack implements the manual: discard 2-gold occupant if any, compact survivors only at cycle start, refill. The previous engine already mostly did this; collapsed UI slots were misleading.

New generated runtime art: ownership medallions owner-0/1/2.webp and cornucopia.webp; all 18 Creatures and 9 Heroes at assets/figures/{id}.webp. These are full-body transparent figures; existing card portraits remain on cards. Persistent creatures are packed as individual pieces alongside armies; one-use creatures appear temporarily while summoned, never as invented permanent units. Troop nominal size increases 30→39; buildings 25×26→36×38 with dark outline and positions fitted into legal land shapes. Crowded armies scale down and can be inspected in a larger roster.

Audio: ten local Foley-style WAV assets generated from decaying wood/metal resonance and filtered noise (wood, coin, cloth, dice, clash, march, build, splash, surf, arrow). They are procedural sound effects, not field recordings. Selection playback no longer uses pitched oscillator bleeps. Browser buffers are loaded after interaction; UI/battle/ambient mixer, mute and hidden-tab handling. Ambient ocean is off by default.

Battle presentation: actual engine die results, visible wooden pip dice showing 0/1/1/2/2/3 distribution, paced roll and impact phases before casualty resolution, individual full-body forces, in-battle decision buttons, map access for retreat, outcome animation and skip. Replays use the stored report and never reroll/mutate game state. New catalog entries 301–400 are 25 combat beats with four faction treatments; procedural motion/particles, not hand-drawn frame sequences. Live stage uses formation, advance, spear/volley/lunge/charge, block/parry, stagger, spray, roll and outcome beats. Older automatic auction bursts remain suppressed.

Ten implemented app tools: bid steppers with net payment; god power sheets; enlarged force inspector; previous/next owned area navigation; camera bookmark/return; sound mixer; animation intensity; battle replay; chronicle filtering; keyboard shortcuts and polite live prompts. No rule changes except correcting/clarifying implementation against manual.

Validation: existing 32 rule checks, full AI campaigns, save/resume and hidden-gold invariants; explicit gapped and empty-deck creature rotation cases; fixed four-slot market; actual dice animation sequencing; replay state immutability; 400 motion profiles; buffered audio/mute stub; all 27 figure paths; ownership/cornucopia and WAV assets; static figure map inspected. Browser/physical-device audio, gesture and short-screen layout QA not available, so not asserted.

Built-in generation briefs: 2×2 transparent icon atlas with gold lion, red scorpion, violet eagle embossed Greek-key ownership medallions plus standalone fruit-filled cornucopia; bold outlined 2D painted boardgame finish. Three 3×3 transparent full-body figure atlases referencing the supplied manual art sheet: Charon/Chimera/Cyclops/Dryad/Giant/Griffin/Harpy/Graeae/Pegasus; Satyr/Sphynx/Sylph/Cerberus/Hydra/Kraken/Medusa/Minotaur/Polyphemus; Ajax/Helen/Odysseus/Croesus/Hector/Penthesilea/Pandora/Perseus/Jason. Distinct silhouettes, cel-painted highlights, no portraits, text, bases or environments. Atlases cropped to individual runtime WebP assets.
