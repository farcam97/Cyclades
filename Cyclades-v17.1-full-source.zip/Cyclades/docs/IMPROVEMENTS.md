# Existing-game improvements, version 16.1 (historical baseline)

## Implemented

- Recovered readable web sources and artwork from the supplied APK into `web/` without modifying the original APK.
- Added a frozen dependency lockfile, local server, syntax/entry-asset checks, browser regression tests and repeatable production build.
- Checkpoints compare complete game state. Changes to pieces or cards cannot be missed merely because gold and log length stay the same. Failed storage writes remain retryable.
- Up to three spaced previous compatible checkpoints are retained; primary saves remain synchronous. A malformed primary save falls back to the newest compatible backup. Backup quota failures do not block the primary checkpoint.
- Imported and locally restored campaigns use the existing detailed validator. Malformed metadata is rejected safely. Import write failures preserve the previous checkpoint.
- Auction/panel caches invalidate when state affecting action availability changes; failed renders do not mark the cache valid.
- v16 map regions expose keyboard activation, territory names, type, faction and availability. Special units expose named power controls. Keyboard activation does not bubble into map selection.
- Campaign tools trap keyboard focus while open, support Escape and restore focus when possible. Turn prompts announce status changes.
- Visible keyboard focus, larger tool targets, input text sizing, screen-cutout clearance, short landscape screens and system reduced motion are supported.
- Audio cleanup no longer tries to call a method on a false boolean when stereo is disabled. Absent mixer values default safely, background audio does not restart after an asynchronous decode, and ambience nodes are disconnected during backgrounding.
- Corrected missing SVG coordinate separators that produced repeated browser rendering errors in construction markers.
- Minified each classic JavaScript file independently and combined 14 stylesheets into one fingerprinted production stylesheet. All artwork is retained. Original scripts were already compact: JS/CSS reduction is approximately 5% versus the original APK’s JavaScript/CSS, not a claimed equivalent reduction in total APK size.

## Validation

The browser suite covers phone/tablet/landscape startup, dialog focus, full-state saves, quota retry, corruption recovery, import failures, exact campaign-state restoration, map keyboard selection, audio cleanup, panel invalidation, a complete automated game, and setup/first-cycle progression for all existing 2–6 player configurations. The four-player configuration also exercises the existing Maelstrom expansion. Tests are run against development and production assets. All 16 production browser checks pass, including the optional rules guide, single-occupant Apollo and the final backup-performance refinement. The initial 14 checks also passed against development assets. Final results are recorded in artifacts/validation-summary.json. Syntax/entry-asset checks, frozen dependency installation and production build also passed.

The complete-game check accelerates timers and disables presentation using the existing `R.auto` simulation flag. It does not prove AI strength, every creature interaction or frame rate on a physical phone. Save tests use stable state fixtures to isolate persistence; the complete-game and configuration checks exercise the real engine.

## Native Android findings

Static inspection of the original APK reports package `com.aegean.cyclades`, version 16.0/code 16, minimum SDK 26 and target SDK 35. No Android permissions are declared. V1 and V2 signature blocks are present; this statement is not a cryptographic signature verification.

The native wrapper loads local assets from `appassets.androidplatform.net`, disables file access, enables DOM storage and exposes file export/orientation bridges. It supports a document picker and Back handling. These capabilities have been inspected statically, not exercised on an Android device.

## Native integration and additional changes

The smaller source archive was successfully imported. The Android wrapper now restricts asset requests and navigation to the bundled HTTPS origin/path, returns explicit 403/404 responses, clears pending exports on cancel, limits concurrent export requests, handles missing document apps, avoids duplicate fullscreen callbacks, releases picker callbacks on destruction, and dismisses unit powers before returning to the title on Back. It reloads the local entry point after process recreation so JavaScript can offer its validated campaign checkpoint instead of treating WebView history as saved game memory.

Version 16.1/code 17 builds with Android platform 35/build-tools 35.0.0. The preview package is `com.aegean.cyclades.preview`, labeled Cyclades Preview, with no declared permissions. Alignment and V2/V3 signatures verify with Android's tools. It uses a separate local test key and does not replace the original app. Export/import is required to transfer an existing campaign into Preview. No private signing material is included in artifacts.

The optional six-page How to play guide explains existing actions and controls without changing game state. The user explicitly selected one Apollo occupant. Both bid validation and AI bidding now enforce that choice; it has a dedicated regression check.

Source-provided v16 features, targeted cases, interaction, integration, and full core/Maelstrom campaigns pass, including complete games for 2–6 player configurations. The SVG reconciliation test now reads its snippet from readable source because its original comment-based extraction is incompatible with minification; the production renderer is separately exercised in browser tests.

Two source-provided suites remain failed: `rules-cases.cjs` now passes the Apollo check but expects a capture bonus to the previous owner that the original supplied v16 `takeLand` function does not implement; `performance-tests.cjs` loads an obsolete subset of scripts and tries to call pointer listeners installed only by later interface code. The latter also fails against the unchanged APK. Neither assertion has been disabled, and these failures are not counted as passes.

## Outstanding work

A physical Android device or emulator has not been used. Rotation, Back, process recreation, native picker import/export, device FPS/memory and battery behavior therefore remain unverified. Release updates to the original package require the original signing key through a secure local/CI process.

Broader visual refinement, strategic AI evaluation, asset-usage pruning and comprehensive creature/rules edge-case coverage remain future work. The inherited capture-bonus rule discrepancy needs reconciliation before claiming all rules checks pass. No 3D conversion or new gameplay has been added.

## Measured browser performance for version 16.1

An alternating comparison of the unchanged APK web assets and the updated production build used seven measured runs per version after two warmups, fresh browser contexts, a fixed random seed, a 390×844 viewport and reduced motion. Local load medians were 509.5 ms original and 410.0 ms updated (about 20% faster in this environment). Five hundred unchanged-map renders took 4.2 ms in both versions. Sixty changed-map renders took 139.3 ms original and 143.6 ms updated (roughly unchanged). Sixty HUD refreshes took 168.1 ms original and 210.5 ms updated: around 0.7 ms extra per refresh for stronger state/save checks. The initially much larger save overhead was reduced by caching validation against exact serialized text and spacing optional backup-history writes. Primary checkpoints remain synchronous.

These are CPU/local-server browser measurements, not phone startup, frame rate, GPU, battery or Android WebView results. The raw samples are in artifacts/performance-comparison.json. JavaScript/CSS decreases from 681,931 to 649,031 bytes (about 4.8%) despite the added guide and reliability code; all artwork is retained.

The current interface release is documented in [UI-UPDATE-16.2.md](UI-UPDATE-16.2.md). Historical benchmark numbers above do not describe version 16.2.
