# Three-player rules reconciliation

Source: user-supplied Cyclades Legendary Edition manual, 16 pages, July 2023 PDF.

## Implemented corrections

- Page 2: 5 starting GP, shuffled turn order, two placement passes (second reversed), first two claims on different islands, three starting Fleets, three freely distributed basic Troops, Priestess symbols, two visible Heroes, four Creatures.
- Page 3: rotate one god each cycle; discard the Creature occupying the 2-GP slot, retain and slide others, fill from a real deck; refill the Hero track from a finite deck.
- Page 4: hidden opponent treasuries and income logs; public bids; one occupant per god including Apollo; affordable offers with Priestess discounts; immediate rebids; creature maintenance after offerings.
- Pages 5–9: choose placement of free Buildings and units; one construction site per custom land; replacement or forgoing Buildings when full; finite reserves (8 Troops, 8 Fleets per faction, 15 shared Mercenaries, 10 of each basic Building, 20 Priestesses/Philosophers, 15 cities); separate Mercenaries; one extra Priestess/Philosopher and one recruited Hero per appropriate turn; Zeus top-deck ability; Apollo land AND sea Prosperity plus 2 gold.
- Pages 6/11: Temple discounts can make a Creature free, are consumed once per cycle, include geographical Metropolises, and do not apply to Zeus' top-deck action. Multiple Creature purchases allowed.
- Pages 7–8: partial forces; empty seas lose ownership; land control persists; actual map-border adjacency; fleet chains; player casualty choice; defender-first retreat; legal retreat destinations; last-land protection including immediate economic-development victory; elimination latches the cycle-ending condition.
- Page 10: economic and cultural conversion, chosen Metropolis placement/replacement, five actual bonus types with three tokens each, chosen bonus destinations, real bonus paid to expropriated owner, Fortress/Port/Temple effects of cities, gold tiebreak and shared victory.
- Page 11: hero-led movement with per-Hero escalating costs; Ares treats Heroes as ordinary forces; Apollo forbids Hero actions; no sacrifice in acquisition cycle.
- Pages 13–14: all 18 Creature cards, player-selected effects, discard/deck operations, six persistent miniatures, one Creature per area, maintenance and optional adjacent movement, Kraken/Polyphemus blockade, Cerberus and Hydra income, Medusa movement lock, Minotaur battle unit.
- Page 15: all nine Heroes and corrected military/sacrifice powers. Includes Ajax seven lands, Helen fixed die and two matching pairs, Croesus paid rerolls and 15-gold sacrifice, repeat Hector exchanges, Penthesilea protected city, Jason enemy-fleet access and eight-Fleet condition, Pandora copying, Perseus casualty retreats and teleport.

## Scope and explicit limits

- Three-player free-for-all only. No two-player dual-faction or four/six-player team mode.
- Custom six-island archipelago: twelve land areas, seventeen sea areas, one building site per land. Polygon borders determine adjacency. This is not a reconstruction of the ten official tile faces; the manual does not supply complete readable tile data. Prosperity and Priestess locations are custom.
- The existing 0,1,1,2,2,3 die distribution is retained; the supplied text does not enumerate the physical dice faces.
- The manual does not settle every combined power interaction. Pandora conversion precedes Hector; Helen stays fixed at 2 on a Croesus reroll; a protected Metropolis grants a non-geographic Temple discount. These interpretations are exposed in the Chronicle.
- Hidden money is concealed from gameplay displays and AI targeting logic. This is a local single-player browser game, not a server-enforced anti-cheating implementation.
- Automated checks use a DOM stand-in. No browser-control skill is available in this environment, so phone layout and real browser interaction are not fully verified. The SVG map was separately rendered and visually inspected.

## Verification

32 focused rules checks and 10 full randomized three-faction simulated campaigns passed before publication. Checks cover setup, hidden displays, tracks, reserves, income, conversion/capture bonuses, discounts, troop destruction, upkeep/blockade, roster effects, movement costs, retirement order and victory.

## Reference-inspired randomized board update
- Uses the supplied macro-tile and miniature reference images for turquoise water, green terrain, white borders, colored building pieces, and Lion / Scorpion / Eagle faction silhouettes.
- Every new game generates fresh coastlines, area boundaries, adjacency, island names and resource distribution. Six two-area islands remain; these are procedural adaptations, not exact reproductions of the ten official tile faces. Construction capacity remains one per land.
- Spatial choices open directly on highlighted map areas. Optional recruitment can begin by tapping an eligible space and choosing Recruit here. List view remains available for accessibility and non-spatial alternatives.
- Added two-finger zoom, one-finger pan when zoomed, larger touch targets, and gesture/tap separation.
- Verification: 200 distinct connected maps with symmetric adjacency; 20 complete randomized starting setups; direct map choice/invalid-tap tests; 32 existing focused rules checks; completed AI campaigns. Browser/device touch QA was unavailable in this environment.
