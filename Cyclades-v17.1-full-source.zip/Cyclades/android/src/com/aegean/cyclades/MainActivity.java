package com.aegean.cyclades;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.net.Uri;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.view.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/** Offline WebView shell. Only bundled HTTPS assets may access the native bridges. */
public final class MainActivity extends Activity {
 private static final String HOST = "appassets.androidplatform.net";
 private static final String HOME = "https://" + HOST + "/assets/index.html";
 private static final int IMPORT_SAVE = 7, EXPORT_SAVE = 8;
 private String pendingExport;
 private WebView web;
 private ValueCallback<Uri[]> picker;
 private View custom;
 private WebChromeClient.CustomViewCallback customCallback;

 private static boolean isLocalAsset(Uri uri) {
  return uri != null && "https".equals(uri.getScheme()) && HOST.equals(uri.getHost())
    && uri.getUserInfo() == null && uri.getPort() == -1
    && uri.getPath() != null && uri.getPath().startsWith("/assets/")
    && !uri.getPath().contains("..") && !uri.getPath().contains("\\");
 }
 private void notifyUser(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
 private static WebResourceResponse rejected(int status, String reason) {
  return new WebResourceResponse("text/plain", "UTF-8", status, reason,
    Collections.singletonMap("Cache-Control", "no-store"),
    new ByteArrayInputStream(reason.getBytes(StandardCharsets.UTF_8)));
 }
 private static String mime(String path) {
  String ext = path.substring(path.lastIndexOf('.') + 1).toLowerCase(java.util.Locale.ROOT);
  switch (ext) {
   case "js": return "application/javascript";
   case "css": return "text/css";
   case "html": return "text/html";
   case "svg": return "image/svg+xml";
   case "png": return "image/png";
   case "jpg": case "jpeg": return "image/jpeg";
   case "json": return "application/json";
   case "webmanifest": return "application/manifest+json";
   case "webp": return "image/webp";
   case "wav": return "audio/wav";
   case "mp3": return "audio/mpeg";
   default: return "application/octet-stream";
  }
 }

 @Override public void onCreate(Bundle saved) {
  super.onCreate(saved);
  web = new WebView(this);
  setContentView(web);
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(false);
  settings.setAllowContentAccess(true); // Required by the document picker for save imports.
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  settings.setMediaPlaybackRequiresUserGesture(true);
  web.addJavascriptInterface(new Object() {
   @JavascriptInterface public void save(String name, String json) {
    if (name == null || json == null || json.length() > 1000000) return;
    runOnUiThread(() -> {
     if (isFinishing() || pendingExport != null) return;
     pendingExport = json;
     Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
     intent.addCategory(Intent.CATEGORY_OPENABLE);
     intent.setType("application/json");
     String safeName = name.replaceAll("[^a-zA-Z0-9._-]", "_");
     intent.putExtra(Intent.EXTRA_TITLE, safeName.isEmpty() ? "cyclades-save.json" : safeName.substring(0, Math.min(120, safeName.length())));
     try { startActivityForResult(intent, EXPORT_SAVE); }
     catch (android.content.ActivityNotFoundException e) { pendingExport = null; notifyUser("No document app is available to export the save."); }
    });
   }
  }, "AndroidFiles");
  web.addJavascriptInterface(new Object() {
   @JavascriptInterface public void orientation(String mode) {
    if (!"portrait".equals(mode) && !"landscape".equals(mode) && !"auto".equals(mode)) return;
    runOnUiThread(() -> setRequestedOrientation("portrait".equals(mode)
      ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT : "landscape".equals(mode)
      ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
   }
  }, "AndroidDevice");
  web.setWebViewClient(new WebViewClient() {
   @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return !isLocalAsset(request.getUrl()); }
   @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
    Uri uri = request.getUrl();
    if (!isLocalAsset(uri) || !"GET".equals(request.getMethod())) return rejected(403, "Forbidden");
    String path = uri.getPath().substring("/assets/".length());
    try { return new WebResourceResponse(mime(path), "UTF-8", getAssets().open(path)); }
    catch (IOException e) { return rejected(404, "Not Found"); }
   }
  });
  web.setWebChromeClient(new WebChromeClient() {
   @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
    if (picker != null) picker.onReceiveValue(null);
    picker = callback;
    try {
     Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
     intent.addCategory(Intent.CATEGORY_OPENABLE);
     intent.setType("application/json");
     startActivityForResult(intent, IMPORT_SAVE);
     return true;
    } catch (android.content.ActivityNotFoundException e) { picker = null; return false; }
   }
   @Override public void onShowCustomView(View view, CustomViewCallback callback) {
    if (custom != null) { callback.onCustomViewHidden(); return; }
    custom = view; customCallback = callback; setContentView(view);
   }
   @Override public void onHideCustomView() { hideCustomView(); }
  });
  // A WebView history entry cannot restore JavaScript memory after process death.
  // Reload the app and offer its validated completed-action checkpoint instead.
  web.loadUrl(HOME);
 }
 private void hideCustomView() {
  if (custom == null) return;
  setContentView(web); custom = null;
  WebChromeClient.CustomViewCallback callback = customCallback;
  customCallback = null;
  if (callback != null) callback.onCustomViewHidden();
 }
 @Override protected void onActivityResult(int request, int result, Intent data) {
  super.onActivityResult(request, result, data);
  if (request == EXPORT_SAVE) {
   String json = pendingExport; pendingExport = null; // Clear on cancellation too.
   if (result != RESULT_OK || data == null || data.getData() == null || json == null) return;
   try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
    if (output == null) throw new IOException("Document unavailable");
    output.write(json.getBytes(StandardCharsets.UTF_8));
   } catch (IOException | SecurityException e) { notifyUser("Could not export save. Please try another location."); }
  } else if (request == IMPORT_SAVE && picker != null) {
   ValueCallback<Uri[]> callback = picker; picker = null;
   callback.onReceiveValue(result == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
  }
 }
 @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
 @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
 @Override public void onBackPressed() {
  if (custom != null) hideCustomView();
  else if (web != null) web.evaluateJavascript("if(document.getElementById('unit-card-popover'))dismissUnitCard();else if(!document.getElementById('app-panel')?.hidden)closeAppPanel();else returnToTitle();", null);
 }
 @Override protected void onDestroy() {
  hideCustomView();
  if (picker != null) { picker.onReceiveValue(null); picker = null; }
  pendingExport = null;
  if (web != null) { web.removeJavascriptInterface("AndroidFiles"); web.removeJavascriptInterface("AndroidDevice"); web.stopLoading(); web.destroy(); web = null; }
  super.onDestroy();
 }
}
