// Campaign quality-of-life tools. Saved files include the full local game state;
// the on-screen briefing and diagnostic report intentionally exclude secret treasuries/decks.
const SAVE_HISTORY_KEY='cyclades-checkpoint-history-v10';
const RECOVERY_KEY='cyclades-recovery-v1';
// Cache validation by exact serialized contents. Any external change is validated
// again; callers still receive a fresh object so edits cannot mutate cached saves.
const validatedCheckpointTexts=new Set();
let lastRecoveryAt=0;
function checkedCheckpoint(text){
 if(typeof text!=='string')return null;
 try{
  if(validatedCheckpointTexts.has(text))return JSON.parse(text);
  const value=validateImportedCampaign(JSON.parse(text));
  if(validatedCheckpointTexts.size>=4)validatedCheckpointTexts.delete(validatedCheckpointTexts.values().next().value);
  validatedCheckpointTexts.add(text);return value;
 }catch{return null}
}
function retainPreviousCheckpoint(force=false){
 // Primary checkpoints remain synchronous. Space optional backup writes so a
 // burst of HUD renders does not repeatedly serialize a three-save history.
 if(!force&&lastRecoveryAt&&Date.now()-lastRecoveryAt<2000)return;
 try{
  const previous=localStorage.getItem(SAVE_KEY);if(!checkedCheckpoint(previous))return;
  let history;try{history=JSON.parse(localStorage.getItem(RECOVERY_KEY)||'[]')}catch{history=[]}
  if(!Array.isArray(history))history=[];
  if(history[0]!==previous){history.unshift(previous);localStorage.setItem(RECOVERY_KEY,JSON.stringify(history.slice(0,3)));lastRecoveryAt=Date.now()}
 }catch{/* A full backup store must not prevent the primary save. */}
}

readSave=function(){try{const primary=checkedCheckpoint(localStorage.getItem(SAVE_KEY));if(primary)return primary;const history=JSON.parse(localStorage.getItem(RECOVERY_KEY)||'[]');if(!Array.isArray(history))return null;for(const entry of history){const saved=checkedCheckpoint(entry);if(saved){saveNotice='Recovered previous checkpoint · Cycle '+saved.state.cycle;return saved}}}catch{}return null};
let importCandidate=null,lastHistoryState='',briefingBaseline=null,lastBriefing=[],lastHistoryHTML='',lastHistoryQuery='';
const appErrors=[];
function recordAppError(message){appErrors.push({time:new Date().toISOString(),message:String(message).slice(0,700)});if(appErrors.length>12)appErrors.shift()}
globalThis.addEventListener?.('error',e=>recordAppError(e.message||'Script error'));
globalThis.addEventListener?.('unhandledrejection',e=>recordAppError(e.reason?.message||'Unhandled promise rejection'));
function downloadableJSON(name,value){if(typeof Blob==='undefined'||!globalThis.URL?.createObjectURL){setPrompt('File downloads are unavailable in this browser.');return false}const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);return true}
function exportCampaign(){checkpointGame();const saved=readSave();if(!saved){setPrompt('No completed-action checkpoint is available yet.');return false}return downloadableJSON('cyclades-cycle-'+saved.state.cycle+'.json',saved)}
function validateImportedCampaign(value){
 if(!validSave(value))throw Error('This is not a compatible completed-action Cyclades checkpoint.');
 const s=value.state;if(JSON.stringify(value).length>1000000)throw Error('Save file is too large.');
 let objects=0;function inspect(v,depth=0){if(depth>30||++objects>70000)throw Error('Save structure is too complex.');if(typeof v==='number'&&!Number.isFinite(v))throw Error('Invalid number in save.');if(typeof v==='string'&&(v.length>12000||/[<>"`]/.test(v)))throw Error('Unsupported text in save.');if(v&&typeof v==='object'){for(const [key,item]of Object.entries(v)){if(['__proto__','constructor','prototype'].includes(key))throw Error('Unsupported save field.');inspect(item,depth+1)}}}inspect(value);
 // v15 also restores completed CPU-action checkpoints.

 const integer=(n,max=1000000)=>Number.isInteger(n)&&n>=0&&n<=max,owner=n=>n===null||s.players.some(p=>p.id===n);
 if(!integer(s.cycle)||s.cycle<1||!owner(s.activeBidder)||s.zones.length>100)throw Error('Invalid campaign metadata.');
 if(!Array.isArray(s.godQueue)||s.godQueue.length!==5||new Set(s.godQueue).size!==5||s.godQueue.some(g=>!['ARES','POSEIDON','ZEUS','ATHENA','HERA'].includes(g)))throw Error('Invalid god rotation.');
 for(const [i,p] of s.players.entries())if(p.id!==i||!/^#[0-9a-f]{6}$/i.test(p.color)||!integer(p.gp)||!integer(p.priests)||!integer(p.phils,20)||!Array.isArray(p.protected)||p.protected.length>10||p.god!==null&&!GOD_DATA[p.god])throw Error('Invalid faction data.');
 const heroIDs=new Set(HEROES.map(h=>h.id)),creatureIDs=new Set(CREATURES.map(c=>c.id)),metroIDs=['gold','priest','prosperity','troops','fleets','troop-fleet','building','creature'];
 for(const z of s.zones){if(!owner(z.owner)||!['land','sea'].includes(z.type)||!integer(z.pros,1000)||!Array.isArray(z.polygon)||z.polygon.length<3||z.polygon.length>400||z.polygon.some(p=>!Array.isArray(p)||p.length!==2||p.some(n=>!Number.isFinite(n)||Math.abs(n)>2000))||typeof z.path!=='string'||!/^[MmLlHhVvZz0-9eE+.,\s-]+$/.test(z.path))throw Error('Invalid map geometry.');if(!Number.isFinite(z.x)||!Number.isFinite(z.y))throw Error('Invalid space location.');
 if(z.type==='land'&&(!integer(z.troops,8)||!integer(z.mercs,16)||!Array.isArray(z.heroes)||z.heroes.some(h=>!heroIDs.has(h.id))||!Array.isArray(z.bldgs)||z.bldgs.some(b=>!TYPES.includes(b))||!Array.isArray(z.metros)||z.metros.some(m=>!metroIDs.includes(m))||!Array.isArray(z.metroUsed)||!integer(z.capacity,5)))throw Error('Invalid land pieces.');
 if(z.type==='sea'&&!integer(z.fleets,8))throw Error('Invalid Fleet count.');
 }
 if(s.zones[0].customMap17){validateCustomMapGeometry17(s);}else if(s.zones[0].tileLayoutV14){const ts=s.zones[0].tileLayoutV14;if(!Array.isArray(ts)||![6,8,10,12].includes(ts.length)||ts.some(t=>!integer(t.number,12)||t.number<1||![t.x,t.y,t.w,t.h].every(Number.isFinite)||t.w<=0||t.h<=0||t.x<0||t.y<0||t.x+t.w>560.01||t.y+t.h>690.01||!Array.isArray(t.ids)||t.ids.some(id=>!integer(id,s.zones.length-1))))throw Error('Invalid uploaded tile layout.');for(const z of s.zones)if(!Array.isArray(z.buildingSites)||z.buildingSites.length!==z.capacity||z.buildingSites.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw Error('Invalid construction sites.')}else if(!Array.isArray(s.zones[0].macroShapes)||(s.zones[0].macroShapes.length<6||s.zones[0].macroShapes.length>20)||s.zones[0].macroShapes.some(sh=>!integer(sh.art,5)||!['v6',undefined].includes(sh.artSet)||typeof sh.path!=='string'||!/^[MmLlHhVvZz0-9eE+.,\s-]+$/.test(sh.path)))throw Error('Invalid tile artwork.');
 for(const field of ['creatures','deck','discard'])if(!Array.isArray(s[field])||s[field].length>40||s[field].some(c=>!creatureIDs.has(c.id)))throw Error('Invalid Creature cards.');
 if(!Array.isArray(s.openGods)||s.openGods.length!==s.players.length-1||s.openGods.some(g=>!s.godQueue.includes(g)))throw Error('Invalid open gods.');
 for(const field of ['turnOrder','actionOrder','biddingQueue'])if(!Array.isArray(s[field])||s[field].length>s.players.length||new Set(s[field]).size!==s[field].length||s[field].some(id=>!s.players.some(p=>p.id===id)))throw Error('Invalid turn order.');
 for(const field of ['heroes','heroDeck'])if(!Array.isArray(s[field])||s[field].some(h=>!heroIDs.has(h.id)))throw Error('Invalid Hero cards.');
 if(!Array.isArray(s.monsters)||s.monsters.some(m=>!creatureIDs.has(m.id)||!integer(m.zone,s.zones.length-1)||!s.players.some(p=>p.id===m.owner)))throw Error('Invalid Creature figures.');
 if(!Array.isArray(s.logs)||s.logs.length>300||!s.turnState||!s.turnState.heroMoves||!Array.isArray(s.turnOrder)||!Array.isArray(s.actionOrder)||!Array.isArray(s.biddingQueue))throw Error('Incomplete turn state.');
 return JSON.parse(JSON.stringify(value));
}
async function readImportFile(input){const file=input.files?.[0];if(!file)return;try{if(file.size>1000000)throw Error('Save files must be smaller than 1 MB.');importCandidate=validateImportedCampaign(JSON.parse(await file.text()));$('import-review').innerHTML=`<p>Ready to load Cycle ${importCandidate.state.cycle} · ${importCandidate.state.phase}. Loading replaces the current checkpoint.</p>${btn('Load this checkpoint','acceptImportedCampaign()',true,true)}`;}catch(e){importCandidate=null;$('import-review').textContent=e.message;haptic('invalid')}}
function acceptImportedCampaign(){
 if(!importCandidate)return false;
 let previous;
 try{
  const saved=validateImportedCampaign(importCandidate);
  previous=localStorage.getItem(SAVE_KEY);retainPreviousCheckpoint(true);
  localStorage.setItem(SAVE_KEY,JSON.stringify(saved));
  lastSavedState='';lastCheckpointSig='';
  if(!resumeCampaign())throw Error('Checkpoint could not be restored.');
  importCandidate=null;return true;
 }catch(e){
  if(previous!==undefined)try{if(previous===null)localStorage.removeItem(SAVE_KEY);else localStorage.setItem(SAVE_KEY,previous)}catch{}
  setPrompt('Save could not be loaded: '+e.message);return false;
 }
}

function campaignToolsHTML(){return `<h3>Transfer saved game</h3>${btn('Export saved game','exportCampaign()',!!readSave())}<label class="file-import">Import saved game<input type="file" accept=".json,application/json" onchange="readImportFile(this)"></label><div id="import-review" aria-live="polite"></div>`}
function chronicleHTML(q=''){return G.logs.filter(l=>l.toLowerCase().includes(q.toLowerCase())).map(l=>{const creature=CREATURES.find(c=>l.toLowerCase().includes(c.name.toLowerCase())),hero=HEROES.find(h=>l.includes(h.name)),asset=creature||hero;let text=htmlEscape(l);const zones=G.zones.filter(z=>l.includes(z.name)).sort((a,b)=>b.name.length-a.name.length);for(const z of zones)text=text.replaceAll(htmlEscape(z.name),`<button class="chronicle-place" onclick="jumpHistorySpace(${z.id})">${htmlEscape(z.name)}</button>`);const pic=asset?`<img src="assets/figures/${asset.id}.webp" alt="">`:/Fleet|sail|sea/i.test(l)?`<img src="${PAINT}fleet-0.webp" alt="">`:/build|Metropolis|Fortress|Temple/i.test(l)?`<img src="${PAINT}building-M.webp" alt="">`:/Troop|Mercenary|recruit|moves/i.test(l)?`<img src="${PAINT}warrior-0.webp" alt="">`:'';return `<div class="log-entry illustrated-log">${pic}<span>${text}</span></div>`}).join('')||'<p>No matching public events.</p>'}
filterChronicle=function(q=''){const html=chronicleHTML(q);if(html!==lastHistoryHTML||q!==lastHistoryQuery||$('log-list').innerHTML!==html){$('log-list').innerHTML=html;lastHistoryHTML=html;lastHistoryQuery=q}};
function jumpHistorySpace(id){switchTab('map');R.inspected=id;focusZone(id);renderAll();showSpacePopover(id)}
function diagnosticReport(){return {version:APP_VERSION,at:new Date().toISOString(),phase:G.phase,cycle:G.cycle,busy:R.busy,decisionPending:!!R.pending,motion:{enabled:APP.motion,reduced:FX.reduced,cinematics:APP.cinematics,activeEffects:FX.active.size},camera:{zoom:viewZoom,x:viewX,y:viewY},save:{checkpointAvailable:!!readSave(),status:saveNotice},rendering:{...PERF},errors:[...appErrors]}}
function showDiagnostics(){showAppPanel('diagnostics');$('app-panel-content').innerHTML='<h3>App health · '+APP_VERSION+'</h3><p>This report excludes treasuries, cards, decks and the campaign log.</p><textarea id="diagnostic-text" class="diagnostic-text" readonly aria-label="Diagnostic report"></textarea>'+btn('Copy report','copyDiagnostics()')+btn('Download report','downloadableJSON(\'cyclades-diagnostics.json\',diagnosticReport())');$('diagnostic-text').value=JSON.stringify(diagnosticReport(),null,2)}
async function copyDiagnostics(){const text=JSON.stringify(diagnosticReport(),null,2);try{if(!globalThis.navigator?.clipboard?.writeText)throw Error();await navigator.clipboard.writeText(text);setPrompt('Diagnostic report copied.')}catch{$('diagnostic-text').focus();$('diagnostic-text').select?.();setPrompt('Select and copy the report, or use Download report.')}}
const campaignPanel=showAppPanel;showAppPanel=function(tab='settings'){campaignPanel(tab);if(tab==='save')$('app-panel-content').insertAdjacentHTML('beforeend',campaignToolsHTML());if(tab==='settings')$('app-panel-content').insertAdjacentHTML('beforeend',`<div class="tools-links">${btn('Chronicle',"closeAppPanel();switchTab('log')")}${btn('App health / report','showDiagnostics()')}</div>`)};
const supportedRender=renderAll;renderAll=function(){supportedRender();if(displayedTab==='log')filterChronicle($('chronicle-filter')?.value||'')};
const historyTab=switchTab;switchTab=function(tab){const result=historyTab(tab);if(tab==='log')filterChronicle($('chronicle-filter')?.value||'');return result};
const clearCampaignTools=resetGame;resetGame=function(...args){cameraTweenToken++;travelIntent=null;movementContext=null;forceDraft=null;briefingBaseline=null;lastBriefing=[];closeSpacePopover();return clearCampaignTools(...args)};
const restoredCampaign=resumeCampaign;resumeCampaign=function(...args){cameraTweenToken++;travelIntent=null;movementContext=null;forceDraft=null;briefingBaseline=null;lastBriefing=[];return restoredCampaign(...args)};
renderAll();
