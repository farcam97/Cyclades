const ART='assets/';
const cleanText=s=>String(s).replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu,'').trim();
function icon(name,cls=''){
const paths={coin:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="5"/><path d="M12 8v8m-2-6 2-2 2 2"/>',temple:'<path d="m3 8 9-5 9 5H3Zm2 3v7m5-7v7m4-7v7m5-7v7M3 21h18M4 18h16"/>',leaf:'<path d="M5 20 17 6M7 17C0 7 12 3 20 3c1 8-2 17-13 14Z"/>',scroll:'<path d="M6 4h13v13H8V6a2 2 0 0 0-4 0v2h4m0 9v2a2 2 0 0 0 4 0v-2m0 4H5M11 8h5m-5 4h5"/>',sword:'<path d="m5 19 4-4m1-3 9-9 2 0 0 2-9 9M6 10l8 8M3 21l3-3"/>',ship:'<path d="M3 16h18l-4 5H7l-4-5Zm9-13v13M10 5l-6 8h6m4-7 5 7h-5"/>',map:'<path d="m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2V5Zm6-2v16m6-14v16"/>',god:'<path d="m14 2-9 12h7l-2 8 9-13h-7l2-7Z"/>',myth:'<path d="M4 19c1-8 7-7 8-3s-4 7-6 3M12 16c8 3 10-3 6-5m-7 3c1-7 6-10 10-8l-3 3M13 8 9 3 6 10"/>',shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9S4 17 4 12V6l8-3Z"/>',book:'<path d="M3 4h7l2 2 2-2h7v16h-7l-2 1-2-1H3V4Zm9 2v15M6 8h3m-3 4h3m6-4h3m-3 4h3"/>'};
return `<svg class="ui-icon ${cls}" viewBox="0 0 24 24" aria-hidden="true">${paths[name]||paths.shield}</svg>`;
}
const GOD_EPITHETS={ARES:'Lord of war',POSEIDON:'Ruler of the seas',ZEUS:'King of Olympus',ATHENA:'Goddess of wisdom',HERA:'Queen of the gods',APOLLO:'Bringer of light'};
const GOD_TONES={ARES:'#692e23',POSEIDON:'#195c61',ZEUS:'#42305e',ATHENA:'#6c6243',HERA:'#355f3d',APOLLO:'#73602b'};
const oldSwitchTab=switchTab;
switchTab=function(tab){oldSwitchTab(tab);document.body.dataset.tab=tab};
const oldSetPrompt=setPrompt;
setPrompt=function(s){oldSetPrompt(cleanText(s))};
document.querySelector('.cycle-bar').innerHTML=`<div class="brand"><strong>CYCLADES</strong><small>LEGENDARY EDITION</small></div><div class="cycle-meta"><span id="cycle-label"></span><span class="phase-pill" id="phase-label"></span><button class="top-control" onclick="showWelcome()" aria-label="About the game">?</button></div>`;
document.querySelector('.viewport').insertAdjacentHTML('beforeend',`<div class="map-label">THE AEGEAN<strong>Archipelago</strong></div><div class="map-legend"><span><i class="legend-dot" style="background:#eab308"></i>Sparta</span><span><i class="legend-dot" style="background:#ef4444"></i>Athena</span><span><i class="legend-dot" style="background:#a855f7"></i>Corinth</span><span>${icon('temple')}3 to win</span></div><aside class="inspector" id="inspector"></aside>`);
document.querySelectorAll('.nav-tab').forEach((el,i)=>{el.innerHTML=[icon('map')+'Map',icon('god')+'Gods',icon('myth')+'Myth & Heroes',icon('book')+'Chronicle'][i]});
$('auction-view').querySelector('.panel-inner').innerHTML=`<div><div class="eyebrow">The favor of Olympus</div><h2 class="panel-title">Choose your patron</h2><p class="panel-subtitle">Two gods answer the call this cycle. Make your offering.</p></div><div id="gods-container" style="display:flex;flex-direction:column;gap:12px"></div><div class="help">Priestesses reduce the gold you pay. If outbid, choose a different god. Apollo always accepts a free offering.</div>`;
$('market-view').querySelector('.panel-inner').innerHTML=`<div><div class="eyebrow">Powers beyond mortals</div><h2 class="panel-title">Myths & legends</h2><p class="panel-subtitle">Call on creatures. Rally heroes. Change your fate.</p></div><h3>Mythological creatures</h3><div class="card-grid" id="creature-market"></div><h3>Heroes of the Aegean</h3><div class="card-grid" id="hero-market"></div><h3>Your champions</h3><div class="card-grid" id="player-heroes"></div>`;
$('log-view').querySelector('h3').textContent='Aegean chronicle';
const oldActionButtons=renderActionButtons;
renderActionButtons=function(){oldActionButtons();$('action-btns').innerHTML=cleanText($('action-btns').innerHTML)};
renderAuctionBoard=function(){
const p=G.players[0],my=G.phase==='OFFERINGS'&&G.activeBidder===0,max=p.gp+p.priests;
let html=G.openGods.map(gid=>{
 const g=GOD_DATA[gid],h=getGodHolder(gid),min=h?h.bid+1:1,can=my&&gid!==G.lastKickedFrom[0]&&min<=max;
 return `<article class="god-slot" style="--god-color:${GOD_TONES[gid]}"><img class="god-portrait" src="${ART+gid.toLowerCase()}.webp" alt="${g.name}"><div class="god-top"><div class="god-title-block"><div class="god-subtitle">${GOD_EPITHETS[gid]}</div><span class="god-name">${g.name}</span></div></div><div class="bid-owner" style="color:${h?h.color:'#dacda9'}">${h?h.name+' · '+h.bid+' gold':'Awaiting an offering'}</div><div class="god-desc"><b>${g.free}</b><br>${g.paid}</div>${can?`<div class="bid-controls"><button class="btn primary" onclick="placeBid(0,'${gid}',${min})">Offer ${min} · Pay ${Math.max(0,min-p.priests)}</button>${min+1<=max?`<button class="btn" onclick="placeBid(0,'${gid}',${min+1})">Offer ${min+1}</button>`:''}</div>`:my&&gid===G.lastKickedFrom[0]?'<div class="god-desc">Choose another god after being outbid.</div>':''}</article>`;
}).join('');
html+=`<div class="auction-divider">BEYOND THE VEIL</div><div class="sleeping-gods">${G.godQueue.slice(2).map(gid=>`<div class="sleeping-god"><img src="${ART+gid.toLowerCase()}.webp" alt="">${GOD_DATA[gid].name}<small>RESTING</small></div>`).join('')}</div>`;
const ap=G.players.filter(p=>p.god==='APOLLO');
html+=`<div class="auction-divider">AN OPEN INVITATION</div><article class="god-slot apollo-slot" style="--god-color:${GOD_TONES.APOLLO}"><img class="god-portrait" src="assets/apollo.webp" alt="Apollo"><div class="god-subtitle">Bringer of light</div><div class="god-name">Apollo</div><div class="god-desc">Gain 2 gold and 1 Prosperity.<br>Bid early next cycle.</div>${ap.length?`<div class="bid-owner">${ap.map(p=>p.name.split(' ')[0]).join(' · ')}</div>`:''}${my?'<div class="bid-controls"><button class="btn primary" onclick="placeBid(0,\'APOLLO\',0)">Accept Apollo’s favor · Free</button></div>':''}</article>`;
$('gods-container').innerHTML=html;
};
function artCard(id,name,body,cost,button,mini=false,location=''){
return `<article class="myth-card"><div class="card-art ${mini?'miniature':''}"><img src="${ART+id}.webp" alt="${name}" loading="lazy">${cost!==null?`<span class="card-price">${cost}${icon('coin')}</span>`:''}</div><div class="card-content"><div class="mc-title">${name}</div>${location?`<div class="card-location">${location}</div>`:''}<div class="mc-body">${body}</div>${button}</div></article>`;
}
renderMarket=function(){
const p=G.players[0],my=myAction();
$('creature-market').innerHTML=G.creatures.map((c,i)=>{const cost=creatureCost(p,c),can=my&&p.god!=='APOLLO'&&!G.turnState.boughtCreature&&p.gp>=cost;return artCard(c.id,c.name,c.desc,cost,`<button class="btn primary" ${can?'':'disabled'} onclick="buyCreature(${i})">Summon · ${cost} gold</button>`,c.id==='kraken')}).join('')||'<div class="help">The creatures have departed. New myths arrive next cycle.</div>';
$('hero-market').innerHTML=G.heroes.map((h,i)=>artCard(h.id,h.name,`<b>In battle</b><br>${h.mil}<br><b>Sacrifice</b><br>${h.sac}`,4,`<button class="btn primary" ${my&&p.god==='HERA'&&p.gp>=4?'':'disabled'} onclick="recruitHero(${i})">Recruit through Hera</button>`)).join('')||'<div class="help">All heroes have answered a summons.</div>';
const hs=lands(0).flatMap(z=>z.heroes.map(h=>({...h,zoneId:z.id,zoneName:z.name})));
$('player-heroes').innerHTML=hs.map(h=>artCard(h.id,h.name,h.sac+(h.summonedCycle===G.cycle?'<br><em>Can be sacrificed next cycle.</em>':''),null,`<button class="btn primary" ${my&&p.god!=='APOLLO'&&h.summonedCycle!==G.cycle?'':'disabled'} onclick="sacrificeHero(${h.zoneId},'${h.id}')">Heroic sacrifice</button>`,false,h.zoneName)).join('')||'<div class="help" style="grid-column:span 2">Your legend is yet to be written. Recruit a champion during a Hera turn.</div>';
};
const LAND_PATHS=[
'M55 85 62 74 83 77 96 65 112 67 130 59 148 65 154 79 164 86 161 100 171 112 170 125 70 140 62 125 54 119 58 104 50 96Z',
'M70 140 170 125 175 140 168 153 171 166 161 177 161 191 150 204 131 209 120 201 106 207 94 199 78 203 65 193 69 177 60 161Z',
'M292 75 302 63 322 64 339 55 358 59 369 51 389 57 399 72 396 89 405 101 399 116 400 130 300 135 293 121 296 104 287 91Z',
'M300 135 400 130 411 141 414 157 429 164 430 180 440 191 430 201 411 198 395 207 378 200 361 205 349 198 331 204 322 190 316 173 306 162Z',
'M193 241 202 232 214 234 230 219 249 224 268 217 282 229 294 227 304 239 298 252 310 266 304 278 311 291 298 302 278 300 264 309 249 302 232 307 213 299 193 303 184 289 190 274 183 260Z',
'M48 369 54 358 69 360 83 349 102 354 119 345 136 349 155 345 165 435 148 443 130 436 115 440 101 431 80 439 65 430 54 432 47 420 53 404 43 390Z',
'M155 345 168 350 183 348 197 358 217 356 231 368 246 373 242 390 249 403 241 417 246 432 234 444 235 455 219 461 204 451 190 457 175 442 165 435Z',
'M320 345 332 333 349 337 365 326 384 330 398 317 414 324 432 323 439 336 433 350 443 363 440 379 445 390 325 395 316 382 321 366 313 356Z',
'M325 395 445 390 452 405 441 418 443 434 431 446 425 460 412 469 397 463 380 469 367 460 346 464 330 454 335 439 326 424 332 409Z'
];
const MAP_DEFS=`<defs>
<radialGradient id="ocean"><stop stop-color="#20abb5"/><stop offset=".6" stop-color="#087f94"/><stop offset="1" stop-color="#045568"/></radialGradient>
<linearGradient id="terrain" x2=".4" y2="1"><stop stop-color="#d7d694"/><stop offset=".35" stop-color="#a6bb56"/><stop offset=".8" stop-color="#7fa148"/><stop offset="1" stop-color="#487748"/></linearGradient>
<linearGradient id="cliff" x2="0" y2="1"><stop stop-color="#b39865"/><stop offset="1" stop-color="#695741"/></linearGradient>
<linearGradient id="sail" x2="1" y2=".2"><stop stop-color="#fff2cf"/><stop offset=".55" stop-color="#e1c997"/><stop offset="1" stop-color="#a9916a"/></linearGradient>
<linearGradient id="roof" x2="0" y2="1"><stop stop-color="#d5b875"/><stop offset="1" stop-color="#806039"/></linearGradient>
<pattern id="waves" width="45" height="28" patternUnits="userSpaceOnUse"><path d="M3 8q7-3 14 0m14 13q6-2 12 0" fill="none" stroke="#a2ded5" stroke-width=".5" opacity=".19"/></pattern>
<pattern id="grain" width="13" height="11" patternUnits="userSpaceOnUse"><path d="m2 3 2-1m5 5 2-1M4 9h1" stroke="#354f2f" stroke-width=".5" opacity=".24"/></pattern>
<pattern id="greek" width="20" height="10" patternUnits="userSpaceOnUse"><path d="M0 9h18V1H4v5h9V4H8M0 0v9" fill="none" stroke="#b9c5a0" stroke-width=".7" opacity=".4"/></pattern>
<symbol id="ship-piece" viewBox="0 0 44 42"><ellipse cx="22" cy="37" rx="20" ry="3" fill="#032f3e" opacity=".4"/><path d="M3 29q16 7 37-1l-7 8H12Z" fill="#6c3a25" stroke="#e4b976" stroke-width="1"/><path d="M6 28 11 34m3-4 4 5m4-5 4 5m4-6 3 4" stroke="#eedcaa" stroke-width="1"/><path d="M22 3v28" stroke="#765234" stroke-width="2"/><path d="M21 6Q10 8 8 24q7-1 13 1Z" fill="url(#sail)" stroke="#fcebc3" stroke-width=".7"/><path d="M24 9q3 3 9 13l-9 2Z" fill="#ede0bd"/><path d="M21 2 32 5 23 7" fill="currentColor"/><path d="M1 38q5 2 10 0m20 0q5 2 10 0" stroke="#b9eeea" opacity=".6" fill="none"/></symbol>
<symbol id="helmet-piece" viewBox="0 0 30 34"><path d="M7 9Q14-2 23 9l2 6-5 1-2-8-7 4Z" fill="#b34527"/><path d="M7 13q0-8 10-7 10 3 7 15l-5-1-1 9-5-3-1-9-5 5Z" fill="#e4c580" stroke="#73532e" stroke-width="1"/><path d="m13 14 7 1-1 4-5-1m-3 2-3 5m14-1-3 2" stroke="#57452c" stroke-width="1.4" fill="none"/><path d="M11 9q6-3 9 1" stroke="#fff0c1" fill="none"/></symbol>
<symbol id="city-piece" viewBox="0 0 42 36"><path d="m2 15 19-11 19 11-19 5Z" fill="#e3d8b1"/><path d="m2 15 19 5 19-5v16L21 36 2 30Z" fill="#b8ac87"/><path d="m21 20 19-5v16l-19 5Z" fill="#877e60"/><path d="M6 16v13m6-11v12m5-10v11m9-12v12m6-14v12m5-13v12" stroke="#f4e7bc" stroke-width="3"/><path d="M1 31 21 37 42 31M1 14 21 20 41 14" stroke="#d2bd83" stroke-width="2"/><path d="m4 12 17-10 17 10-17 5Z" fill="url(#roof)" stroke="#f1d89b"/><path d="m12 10 9-5 8 5-8 3Z" fill="#e4cc91"/></symbol>
<symbol id="fort-piece" viewBox="0 0 28 27"><path d="M3 10h22v15H3Z" fill="#a69f7e" stroke="#635f4c"/><path d="M3 6h5v5h4V6h5v5h3V6h5v8H3Z" fill="#e4d6ac"/><path d="M12 25v-7q3-4 5 0v7" fill="#3a4c41"/><path d="M4 15h20M4 21h5m11 0h4" stroke="#d2c79f"/></symbol>
</defs>`;
function mountain(x,y,s=1){return `<g transform="translate(${x} ${y}) scale(${s})" opacity=".65"><path d="m-20 11 15-26L3-7 8-20 29 12Z" fill="#6a7f62"/><path d="m-5-15 5 20 8-25 5 23L29 12H-20Z" fill="#a9b88a"/><path d="m-5-15 4 8-5-2-4 5m18-16 6 11-6-3-4 5" fill="#dbd6ad"/></g>`}
function trees(x,y){return `<g fill="#365f48" opacity=".6"><path d="m${x} ${y} 3-8 3 8Zm8 3 3-9 3 9Zm-5 3 3-8 3 8Z"/></g>`}
renderMapSVG=function(){
let html=MAP_DEFS+`<rect x="0" y="0" width="500" height="540" fill="url(#ocean)" rx="15"/><rect width="500" height="540" fill="url(#waves)" class="ocean-waves"/><rect x="8" y="8" width="484" height="524" rx="10" fill="none" stroke="#99bba133"/><rect x="10" y="9" width="480" height="10" fill="url(#greek)"/><rect x="10" y="524" width="480" height="10" fill="url(#greek)"/>`;
// A compass rose and sailing routes give the sea a chart-like character.
html+=`<g transform="translate(460 65)" opacity=".6"><circle r="19" fill="none" stroke="#ccd7b5" stroke-width=".6"/><path d="M0-26 5-5 0 0-5-5ZM0 26-5 5 0 0 5 5ZM-26 0-5-5 0 0-5 5ZM26 0 5 5 0 0 5-5Z" fill="#e0d9ad"/><path d="M0-26V26M-26 0H26" stroke="#cfdbb4" stroke-width=".7"/><text y="-31" text-anchor="middle" fill="#e3e6c2" font-family="Georgia" font-size="8">N</text></g>`;
G.zones.filter(z=>z.type==='sea').forEach(z=>{
 z.adj.filter(id=>id>z.id&&G.zones[id].type==='sea').forEach(id=>{const n=G.zones[id];html+=`<path d="M${z.x} ${z.y}Q${(z.x+n.x)/2+12} ${(z.y+n.y)/2} ${n.x} ${n.y}" stroke="#a4d4ce" stroke-opacity=".22" stroke-dasharray="2 5" fill="none"/>`});
html+=`<path d="${z.path}" fill="#a5ddd108" stroke="#b1dfd429" stroke-width=".7" stroke-dasharray="2 5"/>`;
});
G.zones.filter(z=>z.type==='land').forEach(z=>{
 const path=LAND_PATHS[z.id];
 html+=`<path d="${path}" fill="none" stroke="#92dac9" stroke-width="13" stroke-opacity=".14"/><path d="${path}" fill="none" stroke="#c6f5d8" stroke-width="7" stroke-opacity=".16"/><path d="${path}" transform="translate(0 5)" fill="url(#cliff)" stroke="#3e5c4d" stroke-width="2"/><path d="${path}" fill="url(#terrain)" stroke="#e1d8ad" stroke-width="2.3"/><path d="${path}" fill="url(#grain)"/>`;
});
[[107,82,.75],[146,184,.45],[345,79,.85],[397,182,.45],[247,243,.9],[89,369,.6],[214,443,.6],[367,343,.65],[405,446,.55]].forEach(([x,y,s])=>html+=mountain(x,y,s));
[[67,100],[144,166],[301,101],[420,182],[203,281],[64,404],[218,381],[330,365],[424,421]].forEach(([x,y])=>html+=trees(x,y));
// All terrain decorations stay below the interactive zones and labels.
G.zones.filter(z=>z.type==='sea').forEach(z=>{
 const col=z.owner===null?'#c3d6cb':G.players[z.owner].color;
 html+=`<g class="map-zone ${selectable(z)?'available':''} ${G.selectedZone===z.id?'chosen':''}" role="button" tabindex="0" aria-label="${z.name}, ${z.fleets} fleets" onclick="onZoneClick(${z.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();onZoneClick(${z.id})}"><path class="zone-hit" d="${z.path}"/><text x="${z.x}" y="${z.y-17}" text-anchor="middle" class="sea-name">${z.name}</text>${z.fleets?`<g class="map-unit" style="color:${col}"><ellipse cx="${z.x}" cy="${z.y+18}" rx="20" ry="6" fill="${col}" opacity=".2"/><use href="#ship-piece" x="${z.x-21}" y="${z.y-13}" width="42" height="40"/><circle cx="${z.x+19}" cy="${z.y+13}" r="8" fill="#102c32" stroke="${col}" stroke-width="1.5"/><text x="${z.x+19}" y="${z.y+16.5}" text-anchor="middle" class="unit-number">${z.fleets}</text></g>`:`<circle cx="${z.x}" cy="${z.y+4}" r="2" fill="#b8e3d7" opacity=".4"/>`}</g>`;
});
G.zones.filter(z=>z.type==='land').forEach(z=>{
 const col=z.owner===null?'#d1c397':G.players[z.owner].color;
 html+=`<g class="map-zone ${selectable(z)?'available':''} ${G.selectedZone===z.id?'chosen':''}" role="button" tabindex="0" aria-label="${z.name}, ${z.troops} troops${z.metro?', Metropolis':''}" onclick="onZoneClick(${z.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();onZoneClick(${z.id})}"><path class="zone-hit" d="${LAND_PATHS[z.id]}"/><text x="${z.x}" y="${z.y-16}" text-anchor="middle" class="land-name">${z.name}</text><g class="map-unit"><ellipse cx="${z.x-19}" cy="${z.y+17}" rx="17" ry="7" fill="#193c37" opacity=".45"/><circle cx="${z.x-19}" cy="${z.y+8}" r="13" fill="#12333b" stroke="${col}" stroke-width="2"/><use href="#helmet-piece" x="${z.x-29}" y="${z.y-8}" width="22" height="26"/><circle cx="${z.x-7}" cy="${z.y+16}" r="7" fill="${col}" stroke="#eddcad" stroke-width=".7"/><text x="${z.x-7}" y="${z.y+19}" text-anchor="middle" font-family="Arial" font-size="9" font-weight="bold" fill="#15272e">${z.troops}</text></g>`;
 if(z.metro)html+=`<use href="#city-piece" x="${z.x+4}" y="${z.y-6}" width="36" height="31"/><path d="M${z.x+39} ${z.y+17}v-26l9 4-9 4" fill="${col}" stroke="#e0c98c" stroke-width=".7"/>`;
 else if(z.bldgs.length){html+=`<use href="#${z.bldgs.includes('F')?'fort-piece':'city-piece'}" x="${z.x+10}" y="${z.y-1}" width="26" height="25"/><text x="${z.x+23}" y="${z.y+29}" text-anchor="middle" font-size="7" font-family="Arial" fill="#fff1c9" paint-order="stroke" stroke="#375045" stroke-width="2">${z.bldgs.join(' · ')}</text>`}
 else html+=`<path d="M${z.x+21} ${z.y+19}v-24l13 4-13 5" fill="${col}" stroke="#e6d3a1" stroke-width=".8"/><ellipse cx="${z.x+21}" cy="${z.y+21}" rx="6" ry="2" fill="#294f3e" opacity=".5"/>`;
 if(z.heroes.length)html+=`<circle cx="${z.x-30}" cy="${z.y+28}" r="7" fill="#f0d28e" stroke="#775a30"/><text x="${z.x-30}" y="${z.y+31}" text-anchor="middle" font-size="9" fill="#564321">★</text>`;
 html+='</g>';
});
$('archipelago').innerHTML=html;
};
let inspectedZone=null;
function renderInspector(){
const z=inspectedZone===null?null:G.zones[inspectedZone],p=G.players[0];
$('inspector').innerHTML=z?`<div class="eyebrow">Territory intelligence</div><h2>${z.name}</h2><p>${z.owner===null?'Unclaimed waters':G.players[z.owner].name+' territory'}</p><div class="inspector-art"></div><div class="intel-stats"><div><strong>${z.type==='land'?z.troops:z.fleets}</strong><small>${z.type==='land'?'TROOPS':'FLEETS'}</small></div><div><strong>${z.pros}</strong><small>GOLD PER CYCLE</small></div></div>${z.type==='land'?`<p>${z.metro?'A Metropolis stands here.':z.bldgs.length?'Buildings: '+z.bldgs.map(t=>({F:'Fortress',P:'Port',T:'Temple',U:'University'}[t])).join(', '):'No buildings yet.'}</p><p>${z.heroes.map(h=>h.name).join(', ')}</p>`:''}<div class="intel-section">CONNECTED AREAS</div><p>${z.adj.map(id=>G.zones[id].name).join(' · ')}</p>`:`<div class="eyebrow">Your campaign</div><h2>The Aegean awaits</h2><p>Three cities will make an empire. Win the favor of the gods and lead Sparta to glory.</p><div class="inspector-art"></div><div class="intel-stats"><div><strong>${countMetropolises(0)} / 3</strong><small>METROPOLISES</small></div><div><strong>${income(0)}</strong><small>INCOME EACH CYCLE</small></div></div><div class="intel-section">${p.god?GOD_DATA[p.god].name.toUpperCase()+'’S FAVOR':'THE PATH TO VICTORY'}</div><p>${p.god?GOD_DATA[p.god].paid:'Gather four Philosophers, complete a set of four different Buildings, or conquer a rival’s Metropolis.'}</p><div class="intel-section">LATEST FROM THE AEGEAN</div>${G.logs.slice(0,3).map(l=>`<div class="intel-event">${cleanText(l)}</div>`).join('')}`;
}
const oldClickZone=onZoneClick;
onZoneClick=function(id){inspectedZone=id;oldClickZone(id);renderInspector()};
const oldRenderAll=renderAll;
renderAll=function(){
 oldRenderAll();
 $('factions-hud').innerHTML=G.players.map(p=>{const bs=getPlayerBuildings(p.id);return `<div class="faction-card ${G.activeBidder===p.id?'active-turn':''}" style="--faction:${p.color}"><div class="f-header"><span>${p.name.split(' ')[0]} <small>${p.id===0?'YOU':'AI'}</small></span><span class="metro-score">${p.god?`<img class="god-mini" src="${ART+p.god.toLowerCase()}.webp" alt="${GOD_DATA[p.god].name}">`:''}${icon('temple')}${countMetropolises(p.id)}/3</span></div><div class="f-stats"><span title="Gold">${icon('coin','gold-icon')}${p.gp}</span><span title="Priestesses">${icon('leaf')}${p.priests}</span><span title="Philosophers">${icon('scroll')}${p.phils}</span></div><div class="f-bldgs">${['F','P','T','U'].map(t=>`<span class="b-badge" title="${{F:'Fortress',P:'Port',T:'Temple',U:'University'}[t]}">${t} ${bs.filter(b=>b===t).length}</span>`).join('')}</div></div>`}).join('');
 $('phase-label').textContent={OFFERINGS:'Offerings',ACTIONS:'God actions',GAME_OVER:'Victory'}[G.phase];
 $('log-list').innerHTML=G.logs.map(l=>`<div class="log-entry">${cleanText(l)}</div>`).join('');renderInspector();
};
const oldUpdateBattle=updateBattleModal;
updateBattleModal=function(msg){oldUpdateBattle(msg);if(!B)return;const a=G.players[B.attId],d=G.players[B.defId];['att-panel','def-panel'].forEach((id,i)=>{const p=i?d:a;$(id).insertAdjacentHTML('afterbegin',`<img class="battle-emblem" src="${ART+(p.god||'ARES').toLowerCase()}.webp" alt="">`)});$('battle-title').textContent=cleanText($('battle-title').textContent);$('battle-actions').innerHTML=cleanText($('battle-actions').innerHTML)};
const oldReset=resetGame;
resetGame=function(){inspectedZone=null;oldReset()};
document.body.insertAdjacentHTML('beforeend',`<section class="welcome" id="welcome" role="dialog" aria-modal="true" aria-label="Welcome to Cyclades"><div class="welcome-box"><img class="welcome-ornament" src="assets/ornament.webp" alt=""><div class="eyebrow">An age of gods. A sea of legends.</div><h1>CYCLADES</h1><div class="edition">LEGENDARY EDITION</div><div class="welcome-gods"><img src="assets/ares.webp" alt="Ares"><img src="assets/poseidon.webp" alt="Poseidon"><img src="assets/zeus.webp" alt="Zeus"><img src="assets/athena.webp" alt="Athena"><img src="assets/hera.webp" alt="Hera"></div><p>Command your fleets. Claim the islands.<br>Build an empire worthy of Olympus.</p><button class="btn primary" onclick="enterGame()">Enter the archipelago →</button><small>Play as Sparta against two AI factions.<br>Control three Metropolises at the end of a cycle to win.</small></div></section>`);
function enterGame(){$('welcome').hidden=true;try{sessionStorage.setItem('cyclades-welcome','seen')}catch{}document.querySelector('.nav-tab.active').focus()}
function showWelcome(){$('welcome').hidden=false;$('welcome').querySelector('button').focus()}
try{if(sessionStorage.getItem('cyclades-welcome'))$('welcome').hidden=true}catch{}
renderAll();switchTab('auction');
