// Shared board iconography and individually addressable forces.
const TABLETOP_ICONS={
 horn:'<image href="assets/cornucopia.webp" width="24" height="24"/>', 
 troop:'<path d="M8 22V12L6 6l6-4 6 4-2 6v10M7 10h10M12 13v9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M3 3v20M1 6l2-5 2 5" fill="none" stroke="currentColor"/>',
 ship:'<path d="M2 17h21l-5 5H7Z M12 2v15M13 3l8 10h-8Z M10 4v9H4Z" fill="currentColor"/>',
 F:'<path d="M4 22V4h4v4h3V4h3v4h3V4h4v18h-7v-7h-4v7Z" fill="currentColor"/>',
 P:'<path d="M12 2v18M6 9h12M3 14q1 8 9 8t9-8M9 4a3 3 0 1 0 6 0a3 3 0 1 0-6 0" fill="none" stroke="currentColor" stroke-width="2"/>',
 T:'<path d="M2 8L12 2l10 6ZM4 10v10m5-10v10m6-10v10m5-10v10M2 22h20" fill="none" stroke="currentColor" stroke-width="2"/>',
 U:'<path d="M2 5q5-3 10 1q5-4 10-1v15q-5-3-10 1q-5-4-10-1ZM12 6v15" fill="none" stroke="currentColor" stroke-width="2"/>',
 priest:'<path d="M12 23V5M12 18Q1 18 3 10q8 0 9 8M12 12Q22 12 21 4q-8 0-9 8" fill="none" stroke="currentColor" stroke-width="2"/>',
 coin:'<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9 6v12m5-12v12M7 9h10M7 15h10" stroke="currentColor"/>',
 hero:'<path d="M12 2l3 6 7 1-5 5 1 8-6-4-6 4 1-8-5-5 7-1Z" fill="currentColor"/>',
 move:'<path d="M2 12h18M14 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2"/>'
};
function tabletopIcon(type,size=24){return `<svg class="tabletop-icon" width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true">${TABLETOP_ICONS[type]||TABLETOP_ICONS.hero}</svg>`}
function prosperityStrip(z,x,y){const n=Math.max(0,z.pros||0),cols=Math.min(5,Math.max(1,n)),rows=Math.ceil(n/5)||1,w=cols*13+8;let s=`<g class="prosperity-strip" aria-label="${n} prosperity cornucopias"><title>${z.name}: ${n} cornucopias${areaIncome(z)!==n?' · Hydra doubles income':''}</title><rect x="${x-w/2}" y="${y-8}" width="${w}" height="${rows*13+3}" rx="5" fill="#fff2c8" stroke="#947343" stroke-width=".7"/>`;for(let i=0;i<n;i++)s+=`<svg data-cornucopia="${z.id}" x="${x-cols*6.5+i%5*13}" y="${y-7+Math.floor(i/5)*13}" width="13" height="13" viewBox="0 0 24 24">${TABLETOP_ICONS.horn}</svg>`;if(!n)s+=`<text x="${x}" y="${y+3}" text-anchor="middle" fill="#5e4a30" font-size="9">0</text>`;if(z.priestIcon)s+=`<svg x="${x+w/2+2}" y="${y-7}" width="13" height="13" viewBox="0 0 24 24" color="#fff3cd">${TABLETOP_ICONS.priest}</svg>`;return s+'</g>'}
const displayAnchors=new WeakMap();
function seaDisplayAnchor(z){if(displayAnchors.has(z))return displayAnchors.get(z);const candidates=[],inside=(x,y)=>x>8&&x<552&&y>8&&y<682&&pointIn(z.polygon,x,y)&&!G.zones.some(l=>l.type==='land'&&pointIn(l.polygon,x,y));
 const xs=z.polygon.map(p=>p[0]),ys=z.polygon.map(p=>p[1]);for(let y=Math.min(...ys)+7;y<Math.max(...ys)-7;y+=9)for(let x=Math.min(...xs)+7;x<Math.max(...xs)-7;x+=9)if(inside(x,y)&&[[-11,-7],[11,-7],[-11,7],[11,7]].every(([dx,dy])=>inside(x+dx,y+dy)))candidates.push({x,y});
 const piece=[...candidates].sort((a,b)=>Math.hypot(a.x-z.x,a.y-z.y)-Math.hypot(b.x-z.x,b.y-z.y))[0]||{x:z.x,y:z.y};
 const resource=[...candidates].filter(p=>Math.hypot(p.x-piece.x,p.y-piece.y)>30).sort((a,b)=>Math.hypot(a.x-piece.x,a.y-piece.y-30)-Math.hypot(b.x-piece.x,b.y-piece.y-30))[0]||{x:piece.x,y:piece.y+26};
 const result={...piece,resource};displayAnchors.set(z,result);return result;}
const siteAnchors=new WeakMap(),ownerAnchors=new WeakMap();
function fittedLandAnchor(z,dx,dy,rx,ry,cache){if(cache.has(z))return cache.get(z);let best={x:z.x,y:z.y},score=Infinity;for(let y=z.y-42;y<=z.y+42;y+=6)for(let x=z.x-42;x<=z.x+42;x+=6){if(![[0,0],[-rx,-ry],[rx,-ry],[-rx,ry],[rx,ry]].every(([a,b])=>pointIn(z.polygon,x+a,y+b)))continue;const d=Math.hypot(x-z.x-dx,y-z.y-dy);if(d<score){score=d;best={x,y}}}cache.set(z,best);return best}
function sitePosition(z){return fittedLandAnchor(z,27,10,16,17,siteAnchors)}
function ownerPosition(z){return fittedLandAnchor(z,-25,23,9,9,ownerAnchors)}
function piecePositions(z,n,x=z.x,y=z.y){
 if(!n)return[];const sea=z.type==='sea',site=sea?null:sitePosition(z),initial=sea?Math.max(16,32-Math.max(0,n-2)*2):Math.max(14,39-Math.max(0,n-2)*1.6);let picked=[],width=initial,height=initial;
 const valid=(a,b)=>a>7&&a<553&&b>7&&b<683&&(!z.polygon||pointIn(z.polygon,a,b))&&(!sea||!G.zones.some(l=>l.type==='land'&&l.polygon&&pointIn(l.polygon,a,b)));
 for(let attempt=0;attempt<6;attempt++){width=initial*Math.pow(.87,attempt);height=sea?width*.9:width*1.2;const step=width*.86,candidates=[];
 for(let row=-7;row<=7;row++)for(let col=-7;col<=7;col++){const a=x+col*step+(row%2?step/2:0),b=y+row*height*.76-3;
 if(!sea&&(Math.abs(a-site.x)<width/2+16&&Math.abs(b-site.y)<height/2+17||Math.abs(a-z.x)<width/2+Math.min(5,Math.max(1,z.pros))*6.5+4&&b+height/2>z.y+23&&b-height/2<z.y+26+Math.ceil(Math.max(1,z.pros)/5)*13||APP.labels&&Math.abs(a-z.x)<36&&Math.abs(b-(z.y-31))<height/2+5))continue;
 if(valid(a,b)&&[[-width*.35,-height*.35],[width*.35,-height*.35],[-width*.35,height*.35],[width*.35,height*.35]].every(([dx,dy])=>valid(a+dx,b+dy)))candidates.push({x:a,y:b,d:Math.hypot(a-x,(b-y)*1.25)})}candidates.sort((a,b)=>a.d-b.d);picked=candidates.slice(0,n);if(picked.length===n)break;
 }while(picked.length<n){const i=picked.length;picked.push({x:x+(i%5-2)*6,y:y+Math.floor(i/5)*6})}return picked.sort((a,b)=>a.y-b.y||a.x-b.x).map(p=>({...p,w:width,h:height}));
}
function renderIndividualPieces(z,x,y){const sea=z.type==='sea',units=sea?Array.from({length:z.fleets},()=>({kind:'fleet',src:PAINT+'fleet-'+z.owner+'.webp'})):[...Array.from({length:z.troops||0},()=>({kind:'troop',src:PAINT+'warrior-'+z.owner+'.webp'})),...Array.from({length:z.mercs||0},()=>({kind:'mercenary',src:PAINT+'warrior-'+z.owner+'.webp'})),...(z.heroes||[]).map(h=>({kind:'hero',src:'assets/figures/'+h.id+'.webp',name:h.name}))];
 units.push(...minis(z).map(m=>({kind:'creature',src:'assets/figures/'+m.id+'.webp',name:CREATURES.find(c=>c.id===m.id)?.name||m.id,pid:m.owner})));
 const op=sea?{x,y}:ownerPosition(z);
 const token=(!sea&&z.troops>0)?'':z.owner===null?`<circle cx="${x}" cy="${y}" r="9" fill="#f1dfb6" stroke="#8e8059" stroke-width="2"/>`:`<image class="ownership-token" href="assets/owner-${z.owner}.webp" x="${units.length?op.x-9.5:x-15}" y="${units.length?op.y-9.5:y-15}" width="${units.length?19:30}" height="${units.length?19:30}"/>`;
 if(!units.length)return sea?'':token;
 const positions=piecePositions(z,units.length,x,y);return (sea?'':token)+units.map((u,i)=>{const p=positions[i];return `<g class="individual-piece ${u.kind}-piece" data-piece="${u.kind}" data-faction="${u.pid??z.owner}" data-piece-index="${i}"><title>${u.name||G.players[z.owner]?.name+' '+u.kind} ${i+1}</title>${sea?`<path class="oar-wake" d="M${p.x-p.w*.4} ${p.y+p.h*.35}q-5 3-9 1m7 4-8 1" fill="none" stroke="#e1f5e6" stroke-width=".8"/>`:''}<image class="${u.kind==='creature'?'creature-sprite':sea?'fleet-sprite':'warrior-sprite'} ${u.kind==='mercenary'?'mercenary-sprite':''}" href="${u.src}" x="${p.x-p.w/2}" y="${p.y-p.h/2}" width="${p.w}" height="${p.h}" preserveAspectRatio="xMidYMid meet"/>${u.kind==='creature'?`<circle cx="${p.x}" cy="${p.y+p.h*.45}" r="2.8" fill="${G.players[u.pid].color}" stroke="#fff5ca"/>`:''}${u.kind==='mercenary'?`<circle cx="${p.x}" cy="${p.y+p.h*.4}" r="2.2" fill="white" stroke="#494231"/>`:''}</g>`}).join('');
}
