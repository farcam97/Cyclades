/* 100 named motion treatments. No animation changes rules, timings, or hidden information. */
const ANIMATIONS=[];
function motionGroup(names,category){for(const name of names)ANIMATIONS.push({id:ANIMATIONS.length+1,name,category})}
motionGroup(['ocean-drift','surf-wash','foam-sweep','cloud-shadow','compass-turn','treasury-glint','temple-incense','fire-flicker'],'ambient');
motionGroup(['tab-open','panel-rise','choice-pulse','choice-confirm','button-press','card-reveal','card-hover','bid-place','bid-outbid','income-count','cycle-banner','victory'],'interface');
for(const faction of ['lion','scorpion','eagle'])motionGroup(['spawn','march','sail','attack','retreat','defeat'].map(n=>faction+'-'+n),'unit');
for(const building of ['fortress','port','temple','university','metropolis'])motionGroup([building+'-raise',building+'-glow'],'building');
for(const god of ['ares','poseidon','zeus','athena','hera','apollo'])motionGroup([god+'-invoke',god+'-blessing'],'god');
for(const c of CREATURES)motionGroup([c.id+'-power'],'creature');
for(const h of HEROES)motionGroup([h.id+'-arrival',h.id+'-sacrifice'],'hero');
motionGroup(['dice-roll','sword-clash','shield-block','sea-splash'],'battle');
if(ANIMATIONS.length!==100)throw Error('Animation catalog must contain 100 entries');
const FX={reduced:globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches||(function(){try{return sessionStorage.getItem('cyclades-reduced-motion')==='yes'}catch{return false}})(),history:[],active:new Set(),snap:null};
const factionNames=['lion','scorpion','eagle'],buildingNames={F:'fortress',P:'port',T:'temple',U:'university',M:'metropolis'};
function motionFrames(name,id){
 const d=9+id%13,angle=5+id%7;
 if(/defeat|sacrifice/.test(name))return [{opacity:1,transform:'scale(1)'},{opacity:.9,transform:`translateY(-${d}px) scale(1.14)`,filter:'brightness(1.8)'},{opacity:0,transform:`translateY(${d*2}px) scale(.35)`}];
 if(/march|retreat/.test(name)){const sign=name.includes('retreat')?-1:1;return[{opacity:0,transform:`translateX(${-sign*d*2}px) rotate(-4deg)`},{opacity:1,transform:'translateY(-5px) rotate(3deg)'},{opacity:0,transform:`translateX(${sign*d*2}px) rotate(-3deg)`}]}
 if(/sail|foam|poseidon|kraken|sea-splash/.test(name))return[{opacity:0,transform:`translateX(-${d}px) rotate(-${angle}deg)`},{opacity:1,transform:'translateY(-6px) scale(1.15)'},{opacity:0,transform:`translateX(${d*2}px) rotate(${angle}deg)`}];
 if(/attack|clash|ares|harpy|hector/.test(name))return[{opacity:0,transform:'scale(.65) rotate(-25deg)'},{opacity:1,transform:`translateX(${d}px) rotate(18deg) scale(1.2)`},{opacity:0,transform:'scale(.9) rotate(-5deg)'}];
 if(/roll|compass|chimera|satyr/.test(name))return[{opacity:0,transform:'rotate(-160deg) scale(.4)'},{opacity:1,transform:'rotate(20deg) scale(1.2)'},{opacity:0,transform:'rotate(160deg) scale(.7)'}];
 if(/raise|arrival|spawn|panel|reveal/.test(name))return[{opacity:0,transform:`translateY(${d*2}px) scale(.65)`},{opacity:1,transform:'translateY(-8px) scale(1.1)'},{opacity:0,transform:'translateY(0) scale(1)'}];
 if(/hover|press|confirm|block/.test(name))return[{opacity:.3,transform:'scale(.9)'},{opacity:1,transform:'scale(1.12)'},{opacity:0,transform:'scale(1)'}];
 return[{opacity:0,transform:`translateY(${d}px) scale(.6)`},{opacity:1,transform:`translateY(-${d/2}px) scale(1.18) rotate(${id%2?angle:-angle}deg)`},{opacity:0,transform:`translateY(-${d*2}px) scale(1.35)`}];
}
function fxAsset(a,opts){
 if(a.category==='god')return 'assets/'+a.name.split('-')[0]+'.webp';
 if(a.category==='creature'){const id=a.name.replace('-power','');return 'assets/'+(id==='minotaur'?'minotaur-piece':id)+'.webp'}
 if(a.category==='hero')return 'assets/'+a.name.replace(/-(arrival|sacrifice)$/,'')+'.webp';
 if(a.category==='unit')return PAINT+(a.name.endsWith('sail')?'fleet-':'warrior-')+factionNames.indexOf(a.name.split('-')[0])+'.webp';
 if(a.category==='building'){const b=Object.entries(buildingNames).find(([k,v])=>a.name.startsWith(v));return PAINT+'building-'+b[0]+'.webp'}
 return null;
}
function playFX(name,opts={}){
 const a=ANIMATIONS.find(a=>a.name===name);if(!a)return;FX.history.push(name);if(FX.history.length>200)FX.history.shift();if(FX.reduced||R.auto||!document.createElement)return;
 const target=opts.target||(opts.zone!==undefined?$('zone-'+opts.zone):null)||document.querySelector('.viewport');if(!target)return;
 const rect=target.getBoundingClientRect();if(!rect.width||!rect.height)return;
 const layer=$('fx-layer'),cx=rect.left+rect.width/2,cy=rect.top+rect.height/2,src=fxAsset(a,opts),color=opts.color||['#efd17d','#fff2ba','#e5894c','#82dfd5','#cba1ef'][a.id%5];
 function launch(el,frames,duration){layer.appendChild(el);if(!el.animate){el.remove();return}const animation=el.animate(frames,{duration,easing:'cubic-bezier(.2,.7,.3,1)',fill:'forwards'});FX.active.add(animation);animation.onfinish=animation.oncancel=()=>{el.remove();FX.active.delete(animation)}}
 if(src){const el=document.createElement('img');el.src=src;el.alt='';el.className='fx-sprite';el.style.left=cx-50+'px';el.style.top=cy-50+'px';launch(el,motionFrames(name,a.id),850+(a.id%4)*90)}
 const n=/victory|metropolis|invoke/.test(name)?14:6;
 for(let i=0;i<n;i++){const el=document.createElement('i'),t=i*Math.PI*2/n+(a.id%7)/7,dist=22+a.id%23;el.className='fx-particle';el.style.cssText=`left:${cx}px;top:${cy}px;width:${3+i%4}px;height:${3+i%4}px;--fx-color:${color};`;
 const drift=/income|glint/.test(name)?-40:Math.sin(t)*dist;
 launch(el,[{opacity:0,transform:'translate(0,0) scale(.2)'},{opacity:1,offset:.25,transform:`translate(${Math.cos(t)*dist*.4}px,${drift*.4}px) scale(1.2)`},{opacity:0,transform:`translate(${Math.cos(t)*dist}px,${drift}px) scale(.1)`}],550+i*45+(a.id%5)*50)}
}
function toggleMotion(){FX.reduced=!FX.reduced;sessionStorage.setItem('cyclades-reduced-motion',FX.reduced?'yes':'no');document.body.classList.toggle('reduced-motion',FX.reduced);if(FX.reduced){for(const a of FX.active)a.cancel();document.getAnimations?.().forEach(a=>a.cancel())}$('motion-setting').textContent=FX.reduced?'Motion: reduced':'Motion: full';}
function showAnimationCatalog(){const el=$('animation-catalog');el.hidden=!el.hidden;el.innerHTML=ANIMATIONS.map(a=>`<button onclick="playFX('${a.name}',{target:this})">${a.id}. ${a.name.replaceAll('-',' ')}</button>`).join('')}
document.body.insertAdjacentHTML('beforeend','<div id="fx-layer" class="fx-layer" aria-hidden="true"></div>');
$('log-view').querySelector('.panel-inner')?.insertAdjacentHTML('afterbegin',`<button id="motion-setting" class="motion-toggle" onclick="toggleMotion()">Motion: ${FX.reduced?'reduced':'full'}</button><button class="motion-toggle" onclick="showAnimationCatalog()">Preview all 100 animations</button><div id="animation-catalog" class="animation-catalog" hidden></div>`);
document.body.classList.toggle('reduced-motion',FX.reduced);
// Event hooks are presentation-only wrappers; promises and return values are preserved.
function fxWrap(name,before,after){const fn=globalThis[name];globalThis[name]=function(...args){before?.(args);const out=fn.apply(this,args);if(out?.then)return out.then(value=>{after?.(args,value);return value});after?.(args,out);return out}}
fxWrap('resetGame',()=>{FX.snap=null;for(const a of FX.active)a.cancel()});
fxWrap('renderMapSVG',()=>{$('archipelago').getAnimations?.({subtree:true}).forEach(a=>a.cancel())});
// Mandatory bonuses are deliberately quiet after the auction.
// Creature presentation is target-aware in v15.
fxWrap('sacrifice',a=>playFX(a[2].id+'-sacrifice',{zone:a[1].id,pid:a[0].id}));
fxWrap('move',a=>playFX(factionNames[a[0].id]+'-'+(a[1]==='sea'?'sail':'march'),{pid:a[0].id}));
fxWrap('battle',a=>{playFX(factionNames[a[0].id]+'-attack',{zone:a[2].id,pid:a[0].id});playFX(a[4]==='sea'?'sea-splash':'sword-clash',{zone:a[2].id,pid:a[0].id})});
fxWrap('retreatSide',a=>{if(B)playFX(factionNames[B[a[0]+'Id']]+'-retreat',{zone:B.toId})});
fxWrap('battleDie',()=>playFX('dice-roll',{target:$('battle-modal')}));
fxWrap('removeCasualty',a=>{if(B)playFX('shield-block',{zone:B.toId})});

fxWrap('newCycle',()=>playFX('cycle-banner'));
fxWrap('resetMapView',null,()=>playFX('compass-turn',{target:document.querySelector('.map-tools')}));
fxWrap('switchTab',null,a=>playFX('tab-open',{target:$(a[0]==='map'?'map-view':a[0]+'-view')}));
fxWrap('ask',(a)=>{playFX('panel-rise');if(a[2].some(o=>o.zone!==undefined))playFX('choice-pulse')});
fxWrap('answerDecision',()=>playFX('choice-confirm'));
fxWrap('placeBid',a=>{playFX('bid-place');if(getGodHolder(a[1]))playFX('bid-outbid')});
function stateMotion(){
 const snap={zones:G.zones.map(z=>({owner:z.owner,n:z.type==='land'?z.troops+z.mercs:z.fleets,b:z.bldgs?.join('')||'',m:z.metros?.length||0,h:z.heroes?.map(h=>h.id)||[]})),phase:G.phase,market:G.creatures.map(c=>c.id).join(',')};
 if(FX.snap){for(const z of G.zones){const old=FX.snap.zones[z.id],now=snap.zones[z.id];if(!old)continue;if(now.n>old.n&&now.owner!==null)playFX(factionNames[now.owner]+'-spawn',{zone:z.id});if(now.n<old.n&&old.owner!==null)playFX(factionNames[old.owner]+'-defeat',{zone:z.id});for(const h of now.h)if(!old.h.includes(h))playFX(h+'-arrival',{zone:z.id});if(now.b!==old.b&&now.b){const name=buildingNames[now.b[0]];playFX(name+'-raise',{zone:z.id});playFX(name+'-glow',{zone:z.id})}if(now.m>old.m){playFX('metropolis-raise',{zone:z.id});playFX('metropolis-glow',{zone:z.id})}}
 if(snap.phase==='GAME_OVER'&&FX.snap.phase!==snap.phase)playFX('victory');if(snap.market!==FX.snap.market)playFX('card-reveal');}FX.snap=snap;
}
fxWrap('renderAll',null,()=>{stateMotion();attachAmbient()});
function attachAmbient(){if(FX.reduced||R.auto)return;const targets=[['ocean-drift','.ambient-ocean'],['surf-wash','.paint-island'],['cloud-shadow','.paint-island'],['temple-incense','image[href$="building-T.webp"]'],['fire-flicker','image[href$="building-F.webp"]']];for(const [name,selector]of targets){const el=document.querySelector(selector);if(!el?.animate||el.dataset.ambient===name)continue;el.dataset.ambient=name;const frames=name==='ocean-drift'?[{opacity:.6,transform:'translateX(0px)'},{opacity:1,transform:'translateX(6px)'}]:name==='foam-sweep'?[{transform:'translateY(0px) rotate(-1deg)'},{transform:'translateY(-2px) rotate(1deg)'}]:name==='cloud-shadow'?[{filter:'brightness(1)'},{filter:'brightness(.96)'}]:[{opacity:.85},{opacity:1}];el.animate(frames,{duration:name==='cloud-shadow'?12000:4500,iterations:Infinity,direction:'alternate',easing:'ease-in-out'})}}
document.addEventListener?.('click',e=>{const b=e.target.closest?.('button');if(b)playFX('button-press',{target:b})});
document.addEventListener?.('pointerover',e=>{const c=e.target.closest?.('.myth-card');if(c&&!c.contains(e.relatedTarget))playFX('card-hover',{target:c})});
renderAll();
