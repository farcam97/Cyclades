// 100 additional movement treatments: 40 naval, 40 troop, 20 water.
const NAVAL_ACTIONS=['harbor-bob','broadside-roll','oar-pull','bow-rise','stern-dip','tack-left','tack-right','launch','wake-surge','anchor-set'];
const TROOP_ACTIONS=['ready','step','march','brace','shield-lift','spear-thrust','rally','charge','recoil','withdraw'];
const WATER_ACTIONS=['ripple','swell','shorebreak','crosscurrent','foam','wake','eddy','glint','surge','tidal'];
for(const weather of ['calm','breeze','swell','storm'])for(const action of NAVAL_ACTIONS)ANIMATIONS.push({id:ANIMATIONS.length+1,name:`ship-${weather}-${action}`,category:'naval',weather,action});
for(const stance of ['lion','scorpion','eagle','mercenary'])for(const action of TROOP_ACTIONS)ANIMATIONS.push({id:ANIMATIONS.length+1,name:`troop-${stance}-${action}`,category:'troop',stance,action});
for(const depth of ['near','far'])for(const action of WATER_ACTIONS)ANIMATIONS.push({id:ANIMATIONS.length+1,name:`water-${depth}-${action}`,category:'water',depth,action});
if(ANIMATIONS.length!==200)throw Error('Expected 200 animation treatments');
function unitMotionFrames(a){
 const w={calm:.5,breeze:1,swell:1.5,storm:2}[a.weather]||1,flip=a.stance==='eagle'?-1:1,step=a.stance==='mercenary'?5:3;
 const profiles={
 'harbor-bob':[[0,0,-1],[0,-2*w,1],[0,0,-1]],'broadside-roll':[[0,0,-3*w],[0,-w,3*w],[0,0,-3*w]],'oar-pull':[[0,0,0],[3*w,0,-1],[0,0,0]],'bow-rise':[[0,0,0],[0,-3*w,-4*w],[0,0,0]],'stern-dip':[[0,0,1],[0,2*w,4*w],[0,0,1]],'tack-left':[[0,0,0],[-5*w,-2,-8*w],[0,0,0]],'tack-right':[[0,0,0],[5*w,-2,8*w],[0,0,0]],'launch':[[0,4,0],[0,-4*w,-2],[0,0,0]],'wake-surge':[[0,0,0],[7*w,-w,-2],[0,0,0]],'anchor-set':[[0,0,-1],[0,3*w,3],[0,0,-1]],
 ready:[[0,0,-1],[0,-1,1],[0,0,-1]],step:[[0,0,0],[step,-2,-2],[0,0,0]],march:[[0,0,-2],[step*2,-3,2],[0,0,-2]],brace:[[0,0,0],[-2,2,-5],[0,0,0]],'shield-lift':[[0,0,0],[1,-3,6],[0,0,0]],'spear-thrust':[[0,0,-4],[8,-1,8],[0,0,-4]],rally:[[0,0,-2],[0,-5,3],[0,0,-2]],charge:[[0,0,-5],[12,-3,7],[0,0,-5]],recoil:[[0,0,0],[-5,3,-8],[0,0,0]],withdraw:[[0,0,0],[-9,0,3],[0,0,0]]};
 return(profiles[a.action]||profiles.ready).map(([x,y,r],i)=>({transform:`translate(${x*flip}px,${y}px) rotate(${r*flip}deg) scale(${i===1&&a.action==='brace'?.97:1})`,opacity:1}));
}
function waterMotionFrames(a){const far=a.depth==='far',d=far?5:10,k=WATER_ACTIONS.indexOf(a.action);return[{transform:`translate(0,0) scale(1) rotate(${k%3-1}deg)`,opacity:.12},{transform:`translate(${d*(k%2?-1:1)}px,${(k%4-2)*2}px) scale(${1.02+k*.006}) rotate(${(k%3-1)*-1}deg)`,opacity:far?.26:.46},{transform:`translate(${d*2}px,0) scale(1.02)`,opacity:.12}]}
const playOriginalFX=playFX;
playFX=function(name,opts={}){const a=ANIMATIONS.find(a=>a.name===name);if(!a||a.id<=100)return playOriginalFX(name,opts);FX.history.push(name);if(FX.history.length>300)FX.history.shift();if(FX.reduced||R.auto)return;
 const zone=opts.zone!==undefined?$('zone-'+opts.zone):null,selector=a.category==='naval'?'.fleet-sprite':a.category==='troop'?'.warrior-sprite':'.sea-wave';const target=opts.target||zone?.querySelector(selector)||document.querySelector(selector);if(!target?.animate)return;
 // Gallery preview targets get a matching image so motion stays identifiable.
 let actual=target,temporary=false;if(opts.preview&&document.createElement){actual=document.createElement('img');actual.src=a.category==='naval'?PAINT+'fleet-'+(a.id%3)+'.webp':a.category==='troop'?PAINT+'warrior-'+(a.id%3)+'.webp':PAINT+'coast-0.webp';actual.alt='';actual.className='motion-preview';target.appendChild(actual);temporary=true}
 const anim=actual.animate(a.category==='water'?waterMotionFrames(a):unitMotionFrames(a),{duration:a.category==='water'?2000:900,easing:'ease-in-out',iterations:opts.loop?Infinity:1});if(!opts.loop){FX.active.add(anim);anim.onfinish=anim.oncancel=()=>{FX.active.delete(anim);if(temporary)actual.remove()}}return anim;
};
function previewMotion(name,el){playFX(name,{target:el,preview:true});selectionSound('step')}
showAnimationCatalog=function(){const el=$('animation-catalog');el.hidden=!el.hidden;el.innerHTML=ANIMATIONS.map(a=>`<button onclick="previewMotion('${a.name}',this)">${a.id}. ${a.name.replaceAll('-',' ')}</button>`).join('')};
const catalogBtn=document.querySelector('button[onclick="showAnimationCatalog()"]');if(catalogBtn)catalogBtn.textContent='Preview all 200 animations';
function livingBoard(){if(FX.reduced||R.auto)return;const weather=['calm','breeze','swell','storm'][G.cycle%4];
 document.querySelectorAll?.('.sea-wave').forEach((el,i)=>playFX(`water-${i%2?'near':'far'}-${WATER_ACTIONS[i%10]}`,{target:el,loop:true}));
}
const motionRender=renderAll;renderAll=function(){motionRender();livingBoard()};
const movementMove=move;move=async function(p,type,...rest){const before=G.zones.map(z=>({id:z.id,owner:z.owner,n:z.type==='sea'?z.fleets:army(z)}));const value=await movementMove(p,type,...rest);const source=before.find(z=>z.owner===p.id&&z.n>(G.zones[z.id].type==='sea'?G.zones[z.id].fleets:army(G.zones[z.id]))),destination=G.zones.find(z=>z.owner===p.id&&(z.type==='sea'?z.fleets:army(z))>before[z.id].n);renderMapSVG();if(source&&destination){animateTravel(p.id,type,source.id,destination.id);playFX(type==='sea'?`ship-${['calm','breeze','swell','storm'][G.cycle%4]}-launch`:`troop-${['lion','scorpion','eagle'][p.id]}-march`,{zone:destination.id})}return value};
function animateTravel(pid,type,from,to){if(FX.reduced||R.auto||!document.createElement)return;const svg=$('archipelago'),rect=svg.getBoundingClientRect(),scale=Math.min(rect.width/(560/viewZoom),rect.height/(690/viewZoom)),ox=rect.left+(rect.width-560/viewZoom*scale)/2,oy=rect.top+(rect.height-690/viewZoom*scale)/2,a=G.zones[from],b=G.zones[to],el=document.createElement('img');el.className='travel-piece';el.src=PAINT+(type==='sea'?'fleet-':'warrior-')+pid+'.webp';el.style.left=ox+(a.x-viewX)*scale-24+'px';el.style.top=oy+(a.y-viewY)*scale-28+'px';$('fx-layer').appendChild(el);const anim=el.animate([{transform:'translate(0,0)',opacity:.9},{transform:`translate(${(b.x-a.x)*scale}px,${(b.y-a.y)*scale}px)`,opacity:.15}],{duration:650,easing:'ease-in-out'});FX.active.add(anim);anim.onfinish=anim.oncancel=()=>{FX.active.delete(anim);el.remove()}}
const troopRecruit=recruit;recruit=async function(p,kind,...rest){const before=G.zones.map(z=>z[kind]||0),ok=await troopRecruit(p,kind,...rest);if(ok){const z=G.zones.find(z=>(z[kind]||0)>before[z.id]);if(z){renderMapSVG();playFX(kind==='fleets'?`ship-${['calm','breeze','swell','storm'][G.cycle%4]}-anchor-set`:`troop-${kind==='mercs'?'mercenary':['lion','scorpion','eagle'][p.id]}-rally`,{zone:z.id})}}return ok};
// The global toggle and the settings panel control the same persistent preference.
toggleMotion=function(){APP.motion=!APP.motion;saveSettings();const el=$('motion-setting');if(el)el.textContent=FX.reduced?'Motion: reduced':'Motion: full';if(FX.reduced){for(const a of FX.active)a.cancel();document.getAnimations?.().forEach(a=>a.cancel())}};
renderAll();
