const DICE_FACES=[0,1,1,2,2,3];
const GOD_DATA={
ARES:{name:'Ares',icon:'⚔️',color:'#dc2626',free:'+1 Free Troop & Free Fortress',paid:'Recruit Troops (2/3/4 GP), Move Troops (1 GP)'},
POSEIDON:{name:'Poseidon',icon:'🔱',color:'#0284c7',free:'+1 Free Fleet & Free Port',paid:'Recruit Fleets (1/2/3 GP), Move Fleets (1 GP)'},
ZEUS:{name:'Zeus',icon:'⚡',color:'#7e22ce',free:'+1 Free Priestess & Free Temple',paid:'Hire Priestess (4 GP), Temples discount Creatures'},
ATHENA:{name:'Athena',icon:'🦉',color:'#64748b',free:'+1 Free Philosopher & Free University',paid:'Hire 2nd Philosopher (4 GP). 4 Philosophers = Metropolis'},
HERA:{name:'Hera',icon:'🦚',color:'#16a34a',free:'+1 Free Mercenary & Any Needed Building',paid:'Hire Mercenaries (1/3/5 GP), Recruit Hero (4 GP)'},
APOLLO:{name:'Apollo',icon:'☀️',color:'#ca8a04',free:'+2 GP & +1 Prosperity on your Land',paid:'Acts last, bids early next cycle. No Creatures or Hero actions.'}
};
const CREATURE_POOL=[
{id:'kraken',name:'Kraken',icon:'🐙',desc:'Destroy all Fleets in the enemy Sea Area with the most Fleets.'},
{id:'harpy',name:'Harpy',icon:'🦅',desc:'Destroy 1 enemy Troop in a Land Area with at least 2 Troops.'},
{id:'graeae',name:'The Graeae',icon:'👁️',desc:'Immediately collect your Prosperity income again.'},
{id:'satyr',name:'Satyr',icon:'🐐',desc:'Steal 1 Philosopher from an opponent who has one.'},
{id:'dryad',name:'Dryad',icon:'🌿',desc:'Steal 1 Priestess from an opponent who has one.'},
{id:'griffin',name:'Griffin',icon:'🦁',desc:'Steal half the Gold Pieces, rounded down, from the richest rival.'},
{id:'pegasus',name:'Pegasus',icon:'🐎',desc:'Teleport your force from one of your Land Areas to any other Land Area.'},
{id:'cyclops',name:'Cyclops',icon:'👁️‍🗨️',desc:'Gain a missing basic Building type on one of your Land Areas.'}
];
const HERO_POOL=[
{id:'ajax',name:'Ajax',mil:'Battle Strength is 2 instead of 1.',sac:'Control 5+ Land Areas to build a Metropolis.',sacType:'land5'},
{id:'helen',name:'Helen',mil:'Your Battle die roll is always at least 2.',sac:'Exchange 4 Buildings of any types for a Metropolis.',sacType:'any4b'},
{id:'odysseus',name:'Odysseus',mil:'Negates enemy Fortress defense bonuses when attacking.',sac:'Exchange 3 Buildings of the same type for a Metropolis.',sacType:'same3b'},
{id:'croesus',name:'Croesus',mil:'Battle Strength is 2; your Battle die gains +1.',sac:'Pay 12 GP to build a Metropolis.',sacType:'gold12'},
{id:'hector',name:'Hector',mil:'Destroys 1 invading Troop before battle.',sac:'Convert 2 Priestesses into 1 Philosopher.',sacType:'priest2phil'},
{id:'penthesilea',name:'Penthesilea',mil:'Wins ties in Land Battle unless both sides have this power.',sac:'Gain +2 Troops in her area and +3 GP.',sacType:'troops'}
];
let G={},B=null;
let timers=new Set();
const $=id=>document.getElementById(id);
function later(fn,ms){const id=setTimeout(()=>{timers.delete(id);fn()},ms);timers.add(id)}
function shuffle(a){a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function myAction(){return G.phase==='ACTIONS'&&G.activeBidder===0&&!B}
function lands(pid){return G.zones.filter(z=>z.type==='land'&&z.owner===pid)}
function income(pid){return G.zones.reduce((s,z)=>s+(z.owner===pid?z.pros:0),0)}
function createInitialMap(){
const rows=[
[0,'Delos North',1,115,105,'M55,80 L155,60 L170,125 L70,140 Z',[1,9,10],1,false],
[1,'Delos South',1,120,168,'M70,140 L170,125 L155,205 L65,195 Z',[0,9,10,11],1,true],
[2,'Naxos West',2,350,100,'M290,65 L395,55 L400,130 L300,135 Z',[3,9,10,12],1,true],
[3,'Naxos East',2,375,170,'M300,135 L400,130 L435,195 L325,200 Z',[2,10,12],1,false],
[4,'Milos Spire',3,245,265,'M195,225 L295,225 L310,300 L185,300 Z',[10,11,12,13],2,true],
[5,'Crete West',4,110,390,'M45,355 L155,345 L165,435 L55,430 Z',[6,11,13,14],1,false],
[6,'Crete East',4,195,415,'M155,345 L245,365 L235,455 L165,435 Z',[5,11,13,14],1,true],
[7,'Rhodes Ridge',5,375,365,'M320,330 L435,320 L445,390 L325,395 Z',[8,12,13,14],1,false],
[8,'Rhodes Port',5,380,430,'M325,395 L445,390 L425,465 L330,460 Z',[7,13,14],1,true]
];
const zones=rows.map(([id,name,island,x,y,path,adj,pros,priestIcon])=>({id,name,type:'land',island,x,y,path,adj,pros,priestIcon,owner:null,troops:0,heroes:[],bldgs:[],metro:false}));
[
[9,'North Aegean',230,65,'M165,30 L285,30 L285,110 L175,110 Z',[0,1,2,10]],
[10,'Central Cyclades Sea',238,168,'M175,120 L295,120 L295,215 L175,215 Z',[0,1,2,3,4,9,11,12]],
[11,'Myrtoan Sea',110,275,'M40,220 L175,220 L175,330 L45,330 Z',[1,4,5,6,10,13]],
[12,'Icarian Sea',385,265,'M320,215 L455,215 L455,310 L320,310 Z',[2,3,4,7,10,13]],
[13,'Cretan Sea',265,345,'M190,310 L315,310 L315,385 L250,360 Z',[4,5,6,7,8,11,12,14]],
[14,'Libyan Sea',280,490,'M120,465 L410,475 L395,525 L135,520 Z',[5,6,7,8,13]]
].forEach(([id,name,x,y,path,adj])=>zones.push({id,name,type:'sea',x,y,path,adj,pros:1,owner:null,fleets:0}));
return zones;
}
function resetGame(){
timers.forEach(clearTimeout);timers.clear();B=null;$('battle-modal').classList.remove('active');
const zones=createInitialMap();
const players=[
{id:0,name:'Sparta (You)',color:'#eab308',isAI:false,gp:7,priests:1,phils:0,god:null,bid:0},
{id:1,name:'Athena AI',color:'#ef4444',isAI:true,gp:7,priests:1,phils:0,god:null,bid:0},
{id:2,name:'Corinth AI',color:'#a855f7',isAI:true,gp:7,priests:1,phils:0,god:null,bid:0}
];
[{p:0,lands:[0,5,6],seas:[9,11]},{p:1,lands:[2,3,4],seas:[10,12]},{p:2,lands:[1,7,8],seas:[13,14]}].forEach(s=>{
s.lands.forEach((id,i)=>{zones[id].owner=s.p;zones[id].troops=i===0?2:1});
s.seas.forEach(id=>{zones[id].owner=s.p;zones[id].fleets=1});
});
G={cycle:1,phase:'OFFERINGS',players,zones,godQueue:shuffle(['ARES','POSEIDON','ZEUS','ATHENA','HERA']),openGods:[],turnOrder:[0,1,2],biddingQueue:[],activeBidder:null,lastKickedFrom:{},actionOrder:[],activePlayerIdx:0,turnState:{},creatures:[],heroes:shuffle(HERO_POOL).slice(0,3),mode:null,selectedZone:null,logs:[],apolloOrder:[]};
logMsg('🏛️ Each faction starts with 3 Land Areas, 4 Troops and 2 Fleets.');startCycle(true);
}
function logMsg(t){G.logs.unshift(`[C${G.cycle}] ${t}`);if(G.logs.length>300)G.logs.length=300;$('log-list').innerHTML=G.logs.map(l=>`<div class="log-entry">${l}</div>`).join('')}
function setPrompt(t){$('prompt-text').textContent=t}
function switchTab(tab){['map','auction','market','log'].forEach((name,i)=>{document.querySelectorAll('.nav-tab')[i].classList.toggle('active',name===tab);if(name!=='map')$(name+'-view').classList.toggle('active',name===tab)})}
function startCycle(first=false){
if(!first){G.cycle++;G.godQueue.push(G.godQueue.shift(),G.godQueue.shift())}
G.openGods=G.godQueue.slice(0,2);G.creatures=shuffle(CREATURE_POOL).slice(0,3).map((c,i)=>({...c,cost:i+2}));
G.players.forEach(p=>{p.god=null;p.bid=0;const inc=income(p.id);p.gp+=inc;logMsg(`💰 ${p.name} collects +${inc} GP Prosperity income.`)});
G.phase='OFFERINGS';G.mode=null;G.selectedZone=null;G.biddingQueue=[...G.turnOrder];G.lastKickedFrom={};G.apolloOrder=[];
checkAllMetropolises();stepBidding();
}
function getGodHolder(g){return G.players.find(p=>p.god===g)}
function stepBidding(){
if(!G.biddingQueue.length){finalizeOfferings();return}G.activeBidder=G.biddingQueue[0];const p=G.players[G.activeBidder];
if(p.isAI){setPrompt(`🤔 ${p.name} is considering an Offering…`);renderAll();later(()=>executeAIBid(p),650)}
else{switchTab('auction');setPrompt('⚡ Your turn! Bid for a God below, or choose Apollo for free.');renderAll()}
}
function placeBid(pid,gid,amount){
if(G.phase!=='OFFERINGS'||G.activeBidder!==pid||G.biddingQueue[0]!==pid)return;
const p=G.players[pid],prev=getGodHolder(gid);
if(gid!=='APOLLO'&&(!G.openGods.includes(gid)||gid===G.lastKickedFrom[pid]||!Number.isInteger(amount)||amount<(prev?prev.bid+1:1)||amount>p.gp+p.priests))return;
G.biddingQueue.shift();
if(gid==='APOLLO'){p.god=gid;p.bid=0;G.apolloOrder.push(pid);logMsg(`☀️ ${p.name} prays to Apollo for free.`);stepBidding();return}
p.god=gid;p.bid=amount;logMsg(`⚡ ${p.name} bids ${amount} GP on ${GOD_DATA[gid].name}.`);
if(prev){prev.god=null;prev.bid=0;G.lastKickedFrom[prev.id]=gid;G.biddingQueue.unshift(prev.id);logMsg(`❗ ${prev.name} was outbid and must choose another God!`)}stepBidding();
}
function executeAIBid(p){
if(G.phase!=='OFFERINGS'||G.activeBidder!==p.id)return;let choice={god:'APOLLO',bid:0,score:3};
G.openGods.forEach(gid=>{if(gid===G.lastKickedFrom[p.id])return;const holder=getGodHolder(gid),min=holder?holder.bid+1:1;
if(min>p.gp+p.priests||min>10)return;let desire=6;if(gid==='ATHENA'&&p.phils>=2)desire+=7;if(gid==='ARES'||gid==='HERA')desire+=5;if(gid==='POSEIDON'||gid==='ZEUS')desire+=4;if(desire-min>choice.score)choice={god:gid,bid:min,score:desire-min};});
for(const gid of G.openGods)if(gid!==G.lastKickedFrom[p.id]&&!getGodHolder(gid)&&p.gp+p.priests>=1&&choice.god==='APOLLO')choice={god:gid,bid:1};
placeBid(p.id,choice.god,choice.bid);
}
function finalizeOfferings(){
G.players.forEach(p=>{if(p.god!=='APOLLO'){const cost=Math.max(0,p.bid-p.priests);p.gp-=cost;logMsg(`💳 ${p.name} pays ${cost} GP for ${GOD_DATA[p.god].name}.`)}});
G.actionOrder=[];G.openGods.forEach(gid=>{const h=getGodHolder(gid);if(h)G.actionOrder.push(h.id)});G.actionOrder.push(...G.apolloOrder);
G.turnOrder=[...G.apolloOrder,...G.actionOrder.filter(id=>G.players[id].god!=='APOLLO').reverse()];G.phase='ACTIONS';G.activePlayerIdx=0;switchTab('map');startNextPlayerAction();
}
function startNextPlayerAction(){
checkAllMetropolises();if(G.activePlayerIdx>=G.actionOrder.length){endCycleCheck();return}
const p=G.players[G.actionOrder[G.activePlayerIdx]];G.activeBidder=p.id;G.mode=null;G.selectedZone=null;G.turnState={recruitedCount:0,boughtExtraCard:false,boughtCreature:false};
applyMandatoryGodBonus(p);checkAllMetropolises();renderAll();
if(p.isAI){setPrompt(`🤖 ${p.name} (${GOD_DATA[p.god].name}) is taking actions…`);later(()=>runAITurn(p),850)}else setPrompt(`🏛️ ${GOD_DATA[p.god].name} Turn: choose an action, then End Turn when ready.`);
}
function applyMandatoryGodBonus(p){
const ls=lands(p.id),ss=G.zones.filter(z=>z.type==='sea'&&z.owner===p.id);
if(p.god==='ARES'){if(ls.length){ls[0].troops++;placeBuildingOnIsland(p,'F')}logMsg(`⚔️ ${p.name} receives Ares' Troop & Fortress.`)}
else if(p.god==='POSEIDON'){placeBuildingOnIsland(p,'P');if(ss.length)ss[0].fleets++;else if(ls.length){const s=G.zones.find(z=>z.type==='sea'&&ls[0].adj.includes(z.id)&&(z.owner===null||z.owner===p.id));if(s){s.owner=p.id;s.fleets++}}logMsg(`🔱 ${p.name} receives Poseidon's Fleet & Port.`)}
else if(p.god==='ZEUS'){p.priests++;placeBuildingOnIsland(p,'T');logMsg(`⚡ ${p.name} receives a Priestess & Temple.`)}
else if(p.god==='ATHENA'){p.phils++;placeBuildingOnIsland(p,'U');logMsg(`🦉 ${p.name} receives a Philosopher & University.`)}
else if(p.god==='HERA'){if(ls.length)ls[0].troops++;const t=getMissingBuildingType(p);placeBuildingOnIsland(p,t);logMsg(`🦚 ${p.name} receives a Mercenary & Building (${t}).`)}
else{p.gp+=2;if(ls.length)ls[0].pros++;logMsg(`☀️ ${p.name} receives +2 GP and +1 Prosperity.`)}
}
function getPlayerBuildings(pid){return lands(pid).flatMap(z=>z.bldgs)}
function getMissingBuildingType(p){const s=new Set(getPlayerBuildings(p.id));return ['F','P','T','U'].find(t=>!s.has(t))||'F'}
function placeBuildingOnIsland(p,t){const ls=lands(p.id).sort((a,b)=>a.bldgs.length-b.bldgs.length);if(ls.length)ls[0].bldgs.push(t)}
function canPlaceMetro(pid){return lands(pid).some(z=>!z.metro)}
function checkAllMetropolises(){G.players.forEach(p=>{while(p.phils>=4&&canPlaceMetro(p.id)){p.phils-=4;grantMetropolis(p,'4 Philosophers')}const ls=lands(p.id);while(canPlaceMetro(p.id)&&['F','P','T','U'].every(t=>ls.some(z=>z.bldgs.includes(t)))){['F','P','T','U'].forEach(t=>{const z=ls.find(z=>z.bldgs.includes(t));z.bldgs.splice(z.bldgs.indexOf(t),1)});grantMetropolis(p,'4 different Buildings')}})}
function grantMetropolis(p,reason){const z=lands(p.id).find(z=>!z.metro);if(!z)return false;z.metro=true;p.gp+=2;z.pros++;logMsg(`🏛️ ${p.name} builds a Metropolis in ${z.name} via ${reason}! (+2 GP, +1 Prosperity)`);return true}
function countMetropolises(pid){return lands(pid).filter(z=>z.metro).length}
function cancelMode(){if(!myAction())return;G.mode=null;G.selectedZone=null;setPrompt('Choose an action or end your turn.');renderAll()}
function playerRecruitUnit(){
if(!myAction())return;const p=G.players[0],n=G.turnState.recruitedCount,costs={ARES:[2,3,4],POSEIDON:[1,2,3],HERA:[1,3,5]};
if(n>=3||!costs[p.god]||p.gp<costs[p.god][n])return;G.turnState.pendingCost=costs[p.god][n];G.mode=p.god==='POSEIDON'?'PLACE_FLEET':'PLACE_TROOP';G.selectedZone=null;
switchTab('map');setPrompt(G.mode==='PLACE_FLEET'?'Tap your Sea Area or an empty Sea Area beside your land.':'Tap your Land Area to place a Troop.');renderAll();
}
function playerBuyCard(){if(!myAction())return;const p=G.players[0];if(G.turnState.boughtExtraCard||p.gp<4||!['ZEUS','ATHENA'].includes(p.god))return;p.gp-=4;G.turnState.boughtExtraCard=true;if(p.god==='ZEUS'){p.priests++;logMsg('⚡ You hired an extra Priestess for 4 GP.')}else{p.phils++;logMsg('🦉 You hired an extra Philosopher for 4 GP.');checkAllMetropolises()}renderAll()}
function startMoveMode(type){if(!myAction()||G.players[0].gp<1)return;G.mode=type==='land'?'SELECT_LAND_FROM':'SELECT_SEA_FROM';G.selectedZone=null;switchTab('map');setPrompt(`Select a starting ${type==='land'?'Land':'Sea'} Area with your units.`);renderAll()}
function areLandsConnected(pid,fromId,toId){
const f=G.zones[fromId],t=G.zones[toId];if(f.island===t.island&&f.adj.includes(toId))return true;
const q=f.adj.filter(id=>G.zones[id].type==='sea'&&G.zones[id].owner===pid&&G.zones[id].fleets>0),seen=new Set(q);
while(q.length){const s=G.zones[q.shift()];if(s.adj.includes(toId))return true;s.adj.forEach(id=>{const n=G.zones[id];if(n.type==='sea'&&n.owner===pid&&n.fleets>0&&!seen.has(id)){seen.add(id);q.push(id)}})}return false;
}
function validFleetPlacement(z,pid){return z.type==='sea'&&(z.owner===pid||(z.owner===null&&z.adj.some(id=>G.zones[id].type==='land'&&G.zones[id].owner===pid)))}
function validSource(z,type){if(z.owner!==0||z.type!==type)return false;if(type==='sea')return z.fleets>0;if(z.troops+z.heroes.length===0)return false;return G.players[0].god==='ARES'||G.mode==='PEGASUS_FROM'||z.heroes.length>0}
function selectable(z){
if(!myAction())return false;if(G.mode==='PLACE_TROOP')return z.type==='land'&&z.owner===0;if(G.mode==='PLACE_FLEET')return validFleetPlacement(z,0);
if(G.mode==='SELECT_LAND_FROM'||G.mode==='PEGASUS_FROM')return validSource(z,'land');if(G.mode==='SELECT_SEA_FROM')return validSource(z,'sea');
if(G.mode==='SELECT_LAND_TO')return z.type==='land'&&z.id!==G.selectedZone&&areLandsConnected(0,G.selectedZone,z.id);
if(G.mode==='PEGASUS_TO')return z.type==='land'&&z.id!==G.selectedZone;
if(G.mode==='SELECT_SEA_TO')return z.type==='sea'&&G.zones[G.selectedZone].adj.includes(z.id);return false;
}
function onZoneClick(id){
if(!myAction())return;const z=G.zones[id],p=G.players[0];
if(!G.mode){setPrompt(`${z.name} · ${z.owner===null?'Unclaimed':G.players[z.owner].name} · ${z.type==='land'?z.troops+' Troops':z.fleets+' Fleets'} · Income ${z.pros} GP`);return}
if(!selectable(z)){setPrompt('Choose one of the highlighted areas, or cancel the action.');return}
if(G.mode==='PLACE_TROOP'||G.mode==='PLACE_FLEET'){if(p.gp<G.turnState.pendingCost){cancelMode();return}p.gp-=G.turnState.pendingCost;if(G.mode==='PLACE_TROOP')z.troops++;else{z.owner=0;z.fleets++}G.turnState.recruitedCount++;G.mode=null;logMsg(`🛡️ You placed a unit in ${z.name}.`);setPrompt(`Unit placed in ${z.name}.`);renderAll();return}
if(['SELECT_LAND_FROM','SELECT_SEA_FROM','PEGASUS_FROM'].includes(G.mode)){G.selectedZone=id;G.mode=G.mode.replace('FROM','TO');setPrompt(`Selected ${z.name}. Tap a highlighted destination.`);renderAll();return}
if(G.mode==='SELECT_SEA_TO')executeSeaMove(0,G.selectedZone,id);else executeLandMove(0,G.selectedZone,id,G.mode==='PEGASUS_TO');
}
function mayAttackLand(pid,z){return z.owner===null||z.owner===pid||lands(z.owner).length>1||countMetropolises(pid)+(z.metro?1:0)>=3}
function executeLandMove(pid,fromId,toId,free=false){
const p=G.players[pid],f=G.zones[fromId],t=G.zones[toId];
if(!f||!t||f.owner!==pid||f.type!=='land'||t.type!=='land'||fromId===toId||f.troops+f.heroes.length===0||(!free&&p.gp<1))return false;
if(!mayAttackLand(pid,t)){setPrompt("You cannot attack a rival's last Land Area unless taking it gives you 3 Metropolises.");return false}
if(!free)p.gp--;const units=f.troops>1?f.troops-1:f.troops,heroes=[...f.heroes];f.troops-=units;f.heroes=[];G.mode=null;G.selectedZone=null;
if(t.owner===null||t.owner===pid||t.troops+t.heroes.length===0){if(t.owner!==pid&&t.priestIcon)p.priests++;t.owner=pid;t.troops+=units;t.heroes.push(...heroes);logMsg(`🚶 ${p.name} moved ${units} Troops into ${t.name}.`);checkAllMetropolises();setPrompt(`Moved into ${t.name}.`);renderAll()}
else startBattle({type:'land',attId:pid,defId:t.owner,fromId,toId,attUnits:units,attHeroes:heroes});return true;
}
function executeSeaMove(pid,fromId,toId){
const p=G.players[pid],f=G.zones[fromId],t=G.zones[toId];if(p.gp<1||f.owner!==pid||!f.fleets||t.type!=='sea'||!f.adj.includes(toId))return;
p.gp--;const units=f.fleets;f.fleets=0;f.owner=null;G.mode=null;G.selectedZone=null;
if(t.owner===null||t.owner===pid||t.fleets===0){t.owner=pid;t.fleets+=units;logMsg(`⛵ ${p.name} sailed ${units} Fleets into ${t.name}.`);setPrompt(`Sailed into ${t.name}.`);renderAll()}
else startBattle({type:'sea',attId:pid,defId:t.owner,fromId,toId,attUnits:units,attHeroes:[]});
}
function creatureCost(p,c){return Math.max(1,c.cost-getPlayerBuildings(p.id).filter(t=>t==='T').length)}
function buyCreature(i){if(!myAction())return;const p=G.players[0],c=G.creatures[i];if(!c||p.god==='APOLLO'||G.turnState.boughtCreature||p.gp<creatureCost(p,c))return;p.gp-=creatureCost(p,c);G.turnState.boughtCreature=true;G.creatures.splice(i,1);G.mode=null;G.selectedZone=null;applyCreatureEffect(p,c);checkAllMetropolises();renderAll()}
function applyCreatureEffect(p,c){
logMsg(`🐉 ${p.name} summoned ${c.name}!`);const enemies=G.players.filter(e=>e.id!==p.id);
if(c.id==='kraken'){const s=G.zones.filter(z=>z.type==='sea'&&z.owner!==null&&z.owner!==p.id).sort((a,b)=>b.fleets-a.fleets)[0];if(s){s.fleets=0;s.owner=null;logMsg(`🐙 Kraken destroyed all Fleets in ${s.name}!`)}}
else if(c.id==='harpy'){const z=G.zones.find(z=>z.type==='land'&&z.owner!==null&&z.owner!==p.id&&z.troops>1);if(z){z.troops--;logMsg(`🦅 Harpy destroyed a Troop in ${z.name}.`)}}
else if(c.id==='graeae'){const n=income(p.id);p.gp+=n;logMsg(`👁️ The Graeae granted +${n} GP!`)}
else if(c.id==='satyr'||c.id==='dryad'){const key=c.id==='satyr'?'phils':'priests',e=enemies.find(e=>e[key]>0);if(e){e[key]--;p[key]++;logMsg(`${c.icon} ${p.name} stole a ${key==='phils'?'Philosopher':'Priestess'} from ${e.name}.`)}}
else if(c.id==='griffin'){enemies.sort((a,b)=>b.gp-a.gp);const n=Math.floor(enemies[0].gp/2);enemies[0].gp-=n;p.gp+=n;logMsg(`🦁 Griffin stole ${n} GP from ${enemies[0].name}!`)}
else if(c.id==='cyclops')placeBuildingOnIsland(p,getMissingBuildingType(p));
else if(c.id==='pegasus'){if(p.id===0){G.mode='PEGASUS_FROM';G.selectedZone=null;switchTab('map');setPrompt('🐎 Pegasus: select a starting Land Area, then any other Land Area.')}
else{const f=lands(p.id).sort((a,b)=>b.troops-a.troops)[0],t=G.zones.find(z=>z.type==='land'&&z.owner!==p.id&&mayAttackLand(p.id,z)&&z.troops+z.heroes.length===0);if(f&&t)executeLandMove(p.id,f.id,t.id,true);else logMsg('🐎 Pegasus found no safe landing for the AI.')}}
}
function recruitHero(i){if(!myAction())return;const p=G.players[0],h=G.heroes[i],ls=lands(0);if(p.god!=='HERA'||p.gp<4||!h||!ls.length)return;p.gp-=4;G.heroes.splice(i,1);ls[0].heroes.push({...h,summonedCycle:G.cycle});logMsg(`🦸 You recruited ${h.name} in ${ls[0].name}.`);renderAll()}
function sacrificeHero(zoneId,heroId){
if(!myAction()||G.players[0].god==='APOLLO')return;const p=G.players[0],z=G.zones[zoneId];if(z.owner!==0)return;
const i=z.heroes.findIndex(h=>h.id===heroId);if(i<0)return;const h=z.heroes[i];if(h.summonedCycle===G.cycle){setPrompt('A Hero cannot be sacrificed during the cycle they were recruited.');return}
const ls=lands(0),bs=getPlayerBuildings(0);if(['land5','any4b','same3b','gold12'].includes(h.sacType)&&!canPlaceMetro(0)){setPrompt('You need a Land Area without a Metropolis.');return}
let success=false,metro=false;
if(h.sacType==='land5'&&ls.length>=5){success=true;metro=true}
else if(h.sacType==='any4b'&&bs.length>=4){let n=4;ls.forEach(l=>{while(l.bldgs.length&&n>0){l.bldgs.pop();n--}});success=true;metro=true}
else if(h.sacType==='same3b'){const t=['F','P','T','U'].find(t=>bs.filter(b=>b===t).length>=3);if(t){let n=3;ls.forEach(l=>{while(l.bldgs.includes(t)&&n>0){l.bldgs.splice(l.bldgs.indexOf(t),1);n--}});success=true;metro=true}}
else if(h.sacType==='gold12'&&p.gp>=12){p.gp-=12;success=true;metro=true}
else if(h.sacType==='priest2phil'&&p.priests>=2){p.priests-=2;p.phils++;success=true}
else if(h.sacType==='troops'){z.troops+=2;p.gp+=3;success=true}
if(!success){setPrompt(`Conditions not met for ${h.name}'s sacrifice.`);return}
z.heroes.splice(i,1);logMsg(`🦸 ${h.name} was sacrificed.`);if(metro)grantMetropolis(p,`${h.name}'s sacrifice`);checkAllMetropolises();renderAll();
}
function startBattle(cfg){
B={...cfg,round:1,finished:false};const z=G.zones[B.toId];
if(B.type==='land'&&z.heroes.some(h=>h.id==='hector')&&B.attUnits>0){B.attUnits--;logMsg('🛡️ Hector destroys 1 invading Troop before battle.')}
$('battle-modal').classList.add('active');if(B.attUnits+B.attHeroes.length===0){B.finished=true;logMsg('🛡️ The invading force was destroyed before battle.')}
updateBattleModal(B.finished?'Hector destroyed the invading force.':'Ready to roll Cyclades Battle Dice: 0, 1, 1, 2, 2, 3.');
}
function battleBonuses(){
const z=G.zones[B.toId];if(B.type==='land')return {att:0,def:B.attHeroes.some(h=>h.id==='odysseus')?0:z.bldgs.filter(t=>t==='F').length};
const ports=pid=>z.adj.reduce((s,id)=>{const n=G.zones[id];return s+(n.type==='land'&&n.owner===pid?n.bldgs.filter(t=>t==='P').length:0)},0);return {att:ports(B.attId),def:ports(B.defId)};
}
function updateBattleModal(msg){
if(!B)return;const att=G.players[B.attId],def=G.players[B.defId],z=G.zones[B.toId],bonus=battleBonuses();
$('battle-title').textContent=`${B.type==='land'?'⚔️ LAND':'🔱 SEA'} BATTLE AT ${z.name.toUpperCase()}`;$('battle-subtitle').textContent=`Round ${B.round}`;
$('att-panel').innerHTML=`<div style="color:${att.color};font-weight:800;font-size:13px">${att.name}</div><div class="dice-box">${B.attUnits+B.attHeroes.length}</div><div style="font-size:11px;color:#94a3b8">Units (+${bonus.att} Bonus)</div>`;
$('def-panel').innerHTML=`<div style="color:${def.color};font-weight:800;font-size:13px">${def.name}</div><div class="dice-box">${(B.type==='land'?z.troops:z.fleets)+(z.heroes?z.heroes.length:0)}</div><div style="font-size:11px;color:#94a3b8">Units (+${bonus.def} Defense)</div>`;
$('battle-roll-summary').innerHTML=msg;const aiOnly=att.isAI&&def.isAI;
$('battle-actions').innerHTML=B.finished?`<button class="btn primary" onclick="closeBattleModal()">Continue</button>`:aiOnly?'<span style="font-size:12px">AI battle in progress…</span>':`<button class="btn primary" onclick="rollBattleRound()">🎲 Roll Battle Dice</button>${B.attId===0?'<button class="btn" onclick="retreatAttacker()">🏳️ Retreat</button>':''}`;
const battle=B,round=B.round;if(aiOnly)later(()=>{if(B!==battle)return;if(B.finished)closeBattleModal();else if(B.round===round)rollBattleRound()},650);
}
function removeAttackerUnit(){if(B.attUnits>0)B.attUnits--;else B.attHeroes.pop()}
function removeDefenderUnit(z){if(B.type==='sea'){if(z.fleets>0)z.fleets--}else if(z.troops>0)z.troops--;else z.heroes.pop()}
function rollBattleRound(){
if(!B||B.finished)return;const a=G.players[B.attId],d=G.players[B.defId],z=G.zones[B.toId],dh=z.heroes||[],bonus=battleBonuses();const has=(hs,id)=>hs.some(h=>h.id===id);
let ad=DICE_FACES[Math.floor(Math.random()*6)],dd=DICE_FACES[Math.floor(Math.random()*6)];if(has(B.attHeroes,'helen'))ad=Math.max(2,ad);if(has(dh,'helen'))dd=Math.max(2,dd);if(has(B.attHeroes,'croesus'))ad++;if(has(dh,'croesus'))dd++;
const hs=heroes=>heroes.reduce((s,h)=>s+(['ajax','croesus'].includes(h.id)?2:1),0),at=ad+B.attUnits+hs(B.attHeroes)+bonus.att,dt=dd+(B.type==='land'?z.troops:z.fleets)+hs(dh)+bonus.def;
let msg=`🎲 ${a.name}: ${ad} (Total <b>${at}</b>)<br>${d.name}: ${dd} (Total <b>${dt}</b>)<br>`;
const aw=B.type==='land'&&has(B.attHeroes,'penthesilea'),dw=B.type==='land'&&has(dh,'penthesilea');
if(at>dt||(at===dt&&aw&&!dw)){removeDefenderUnit(z);msg+=`💥 ${d.name} loses 1 unit!`}
else if(dt>at||(at===dt&&dw&&!aw)){removeAttackerUnit();msg+=`💥 ${a.name} loses 1 unit!`}
else{removeAttackerUnit();removeDefenderUnit(z);msg+='⚡ Tie! Both sides lose 1 unit.'}
const ra=B.attUnits+B.attHeroes.length,rd=(B.type==='land'?z.troops:z.fleets)+(z.heroes?z.heroes.length:0);
if(ra<=0&&rd<=0){B.finished=true;if(B.type==='sea')z.owner=null;msg+='<br>💀 Mutual annihilation!';logMsg(`⚔️ Mutual destruction at ${z.name}.`)}
else if(rd<=0){B.finished=true;z.owner=B.attId;if(B.type==='land'){z.troops=B.attUnits;z.heroes=[...B.attHeroes];if(z.priestIcon)a.priests++;if(z.metro)d.gp+=2}else z.fleets=B.attUnits;msg+=`<br>🏆 ${a.name} conquers ${z.name}!`;logMsg(`🏆 ${a.name} conquered ${z.name} from ${d.name}!`);checkAllMetropolises()}
else if(ra<=0){B.finished=true;msg+=`<br>🛡️ ${d.name} successfully defended!`;logMsg(`🛡️ ${d.name} repelled the attack at ${z.name}.`)}else B.round++;
updateBattleModal(msg);
}
function retreatAttacker(){if(!B||B.finished||B.attId!==0)return;const f=G.zones[B.fromId];if(B.type==='land'){f.troops+=B.attUnits;f.heroes.push(...B.attHeroes)}else{f.owner=B.attId;f.fleets+=B.attUnits}logMsg(`🏳️ ${G.players[B.attId].name} retreats to ${f.name}.`);B.finished=true;closeBattleModal()}
function closeBattleModal(){if(!B||!B.finished)return;const ai=G.players[B.attId].isAI;B=null;$('battle-modal').classList.remove('active');renderAll();if(ai){const pid=G.activeBidder;later(()=>{if(G.phase==='ACTIONS'&&G.activeBidder===pid)finishCurrentPlayerTurn(true)},400)}else setPrompt('Battle resolved. Choose another action or end your turn.')}
function runAITurn(p){
if(G.phase!=='ACTIONS'||G.activeBidder!==p.id||B)return;
if(p.god==='ZEUS'&&p.gp>=4){p.gp-=4;p.priests++;logMsg(`⚡ ${p.name} hired an additional Priestess.`)}
else if(p.god==='ATHENA'&&p.gp>=4){p.gp-=4;p.phils++;logMsg(`🦉 ${p.name} hired an additional Philosopher.`);checkAllMetropolises()}
else if(p.god==='POSEIDON'&&p.gp>=1){const s=G.zones.find(z=>z.type==='sea'&&z.owner===p.id);if(s){p.gp--;s.fleets++;logMsg(`🔱 ${p.name} recruited a Fleet.`)}}
else if(['ARES','HERA'].includes(p.god)&&p.gp>=(p.god==='HERA'?1:2)){const l=lands(p.id)[0];if(l){p.gp-=p.god==='HERA'?1:2;l.troops++;logMsg(`⚔️ ${p.name} recruited reinforcements in ${l.name}.`)}if(p.god==='ARES'&&p.gp>=1&&l&&l.troops>=3){const t=G.zones.find(z=>z.type==='land'&&z.owner!==p.id&&z.troops+z.heroes.length<=1&&mayAttackLand(p.id,z)&&areLandsConnected(p.id,l.id,z.id));if(t){executeLandMove(p.id,l.id,t.id);if(B)return}}}
if(p.god!=='APOLLO'&&G.creatures.length&&p.gp>=4){const i=G.creatures.findIndex(c=>creatureCost(p,c)<=p.gp);if(i>=0){const c=G.creatures[i];p.gp-=creatureCost(p,c);G.creatures.splice(i,1);applyCreatureEffect(p,c);if(B)return}}
checkAllMetropolises();renderAll();const pid=p.id;later(()=>{if(G.phase==='ACTIONS'&&G.activeBidder===pid)finishCurrentPlayerTurn(true)},500);
}
function finishCurrentPlayerTurn(ai=false){if(G.phase!=='ACTIONS'||B)return;if(!ai&&G.activeBidder!==0)return;G.mode=null;G.selectedZone=null;G.activePlayerIdx++;startNextPlayerAction()}
function endCycleCheck(){checkAllMetropolises();const cs=G.players.filter(p=>countMetropolises(p.id)>=3).sort((a,b)=>countMetropolises(b.id)-countMetropolises(a.id)||b.gp-a.gp);if(cs.length){const w=cs[0];G.phase='GAME_OVER';G.activeBidder=null;setPrompt(`🏆 VICTORY! ${w.name} rules the Cyclades with ${countMetropolises(w.id)} Metropolises and ${w.gp} GP!`);logMsg(`🏆 GAME OVER — ${w.name} wins!`);switchTab('map');renderAll()}else startCycle()}
function renderAll(){
$('cycle-label').textContent=`Cycle ${G.cycle}`;$('phase-label').textContent=G.phase.replace('_',' ');
$('factions-hud').innerHTML=G.players.map(p=>{const bs=getPlayerBuildings(p.id);return `<div class="faction-card ${G.activeBidder===p.id?'active-turn':''}"><div class="f-header"><span><span class="f-dot" style="background:${p.color}"></span>${p.name.split(' ')[0]}</span><span>${p.god?GOD_DATA[p.god].icon:'⏳'} 🏛️${countMetropolises(p.id)}/3</span></div><div class="f-stats"><span>🪙 ${p.gp}</span><span>🌿 ${p.priests}</span><span>📜 ${p.phils}/4</span></div><div class="f-bldgs">${['F','P','T','U'].map(t=>`<span class="b-badge">${t}:${bs.filter(b=>b===t).length}</span>`).join('')}</div></div>`}).join('');
renderMapSVG();renderAuctionBoard();renderMarket();renderActionButtons();
}
function renderMapSVG(){
let html='';G.zones.filter(z=>z.type==='sea').forEach(z=>{
const color=z.owner!==null?G.players[z.owner].color:'transparent',cls=(G.selectedZone===z.id?' zone-selected':'')+(selectable(z)?' selectable':'');
html+=`<g onclick="onZoneClick(${z.id})" style="cursor:pointer"><title>${z.name}</title><path d="${z.path}" class="sea-zone${cls}"/><text x="${z.x}" y="${z.y-16}" fill="#93c5fd" font-size="9" text-anchor="middle" font-weight="bold">${z.name} (+${z.pros}🪙)</text>${z.fleets?`<circle cx="${z.x}" cy="${z.y+4}" r="14" fill="${color}" stroke="#fff" stroke-width="2"/><text x="${z.x}" y="${z.y+8}" fill="#000" font-size="11" font-weight="900" text-anchor="middle">⛵${z.fleets}</text>`:''}</g>`;
});
G.zones.filter(z=>z.type==='land').forEach(z=>{
const color=z.owner!==null?G.players[z.owner].color:'#475569',landColor=['#ca8a04','#b91c1c','#7e22ce'][z.owner]||'#4d7c0f',cls=(G.selectedZone===z.id?' zone-selected':'')+(selectable(z)?' selectable':''),bs=z.bldgs.join(''),hs=z.heroes.map(h=>h.name[0]).join('');
html+=`<g onclick="onZoneClick(${z.id})" style="cursor:pointer"><title>${z.name}${bs?' · Buildings '+bs:''}</title><path d="${z.path}" class="land-shadow"/><path d="${z.path}" class="land-zone${cls}" style="fill:${landColor}"/><text x="${z.x}" y="${z.y-18}" fill="#fef9c3" font-size="9.5" font-weight="800" text-anchor="middle" style="text-shadow:0 1px 3px #000">${z.name} (+${z.pros}🪙${z.priestIcon?'🌿':''})</text><circle cx="${z.x-18}" cy="${z.y+4}" r="13" fill="${color}" stroke="#fff" stroke-width="2"/><text x="${z.x-18}" y="${z.y+8}" fill="#000" font-size="11" font-weight="900" text-anchor="middle">🛡️${z.troops}</text>`;
if(z.metro)html+=`<rect x="${z.x+2}" y="${z.y-10}" width="38" height="22" rx="5" fill="#fef08a" stroke="#ca8a04" stroke-width="2"/><text x="${z.x+21}" y="${z.y+5}" fill="#000" font-size="10" font-weight="900" text-anchor="middle">🏛️MET</text>`;
else if(bs)html+=`<rect x="${z.x+2}" y="${z.y-8}" width="38" height="18" rx="4" fill="#1e293b" stroke="#d4af37" stroke-width="1.5"/><text x="${z.x+21}" y="${z.y+4}" fill="#f8fafc" font-size="10" font-weight="bold" text-anchor="middle">${bs}</text>`;
if(hs)html+=`<circle cx="${z.x}" cy="${z.y+22}" r="10" fill="#f59e0b" stroke="#fff" stroke-width="1.5"/><text x="${z.x}" y="${z.y+26}" fill="#000" font-size="9" font-weight="900" text-anchor="middle">🦸${hs}</text>`;html+='</g>';
});$('archipelago').innerHTML=html;
}
function renderAuctionBoard(){
const p=G.players[0],my=G.phase==='OFFERINGS'&&G.activeBidder===0,max=p.gp+p.priests;
let html=G.godQueue.map((gid,i)=>{const g=GOD_DATA[gid],h=getGodHolder(gid),min=h?h.bid+1:1,can=my&&i<2&&gid!==G.lastKickedFrom[0]&&min<=max;
if(i>=2)return `<div class="god-slot facedown"><div class="god-top"><span class="god-name">🔒 ${g.icon} ${g.name}</span><span style="font-size:10px">Face-down this cycle</span></div></div>`;
return `<div class="god-slot" style="border-left:5px solid ${g.color}"><div class="god-top"><span class="god-name">${g.icon} ${g.name}</span><span style="font-size:12px;font-weight:bold;color:${h?h.color:'#94a3b8'}">${h?h.name+': '+h.bid+' GP':'Unclaimed'}</span></div><div class="god-desc"><b>Mandatory:</b> ${g.free}<br><b>Actions:</b> ${g.paid}</div>${can?`<div class="bid-controls"><button class="btn primary" onclick="placeBid(0,'${gid}',${min})">Bid ${min} GP (Net ${Math.max(0,min-p.priests)} GP)</button>${min+1<=max?`<button class="btn" onclick="placeBid(0,'${gid}',${min+1})">Bid ${min+1} GP</button>`:''}</div>`:''}</div>`;
}).join('');const ap=G.players.filter(p=>p.god==='APOLLO');
html+=`<div class="god-slot" style="border-left:5px solid #ca8a04"><div class="god-top"><span class="god-name">☀️ Apollo · Always Open</span><span style="font-size:11px;color:#94a3b8">${ap.length?ap.map(p=>p.name.split(' ')[0]).join(', '):'Free Offering'}</span></div><div class="god-desc">${GOD_DATA.APOLLO.free}<br>${GOD_DATA.APOLLO.paid}</div>${my?'<div class="bid-controls"><button class="btn primary" onclick="placeBid(0,\'APOLLO\',0)">Choose Apollo · Free</button></div>':''}</div>`;$('gods-container').innerHTML=html;
}
function renderMarket(){
const p=G.players[0],my=myAction();
$('creature-market').innerHTML=G.creatures.length?G.creatures.map((c,i)=>{const cost=creatureCost(p,c),can=my&&p.god!=='APOLLO'&&!G.turnState.boughtCreature&&p.gp>=cost;return `<div class="myth-card"><div class="mc-title"><span>${c.icon} ${c.name}</span><span>${cost}🪙</span></div><div class="mc-body">${c.desc}</div><button class="btn primary" ${can?'':'disabled'} onclick="buyCreature(${i})">Summon (${cost} GP)</button></div>`}).join(''):'<div class="help">No Creatures remain this cycle.</div>';
$('hero-market').innerHTML=G.heroes.length?G.heroes.map((h,i)=>`<div class="myth-card"><div class="mc-title"><span>🦸 ${h.name}</span><span>4🪙</span></div><div class="mc-body"><b>Military:</b> ${h.mil}<br><b>Sacrifice:</b> ${h.sac}</div><button class="btn primary" ${my&&p.god==='HERA'&&p.gp>=4?'':'disabled'} onclick="recruitHero(${i})">Recruit (Hera · 4 GP)</button></div>`).join(''):'<div class="help">All available Heroes have been recruited.</div>';
const hs=lands(0).flatMap(z=>z.heroes.map(h=>({...h,zoneId:z.id,zoneName:z.name})));
$('player-heroes').innerHTML=hs.length?hs.map(h=>`<div class="myth-card"><div class="mc-title"><span>🦸 ${h.name}</span></div><div class="mc-body"><b>${h.zoneName}</b><br>${h.sac}${h.summonedCycle===G.cycle?'<br>Available to sacrifice next cycle.':''}</div><button class="btn primary" ${my&&p.god!=='APOLLO'&&h.summonedCycle!==G.cycle?'':'disabled'} onclick="sacrificeHero(${h.zoneId},'${h.id}')">⚡ Sacrifice Hero</button></div>`).join(''):'<div class="help" style="grid-column:span 2">No active Heroes. Recruit them during a Hera turn.</div>';
}
function renderActionButtons(){
const bar=$('action-btns');if(G.phase==='GAME_OVER'){bar.innerHTML='<button class="btn primary" onclick="resetGame()">🔄 Play Again</button>';return}
if(G.phase==='OFFERINGS'){bar.innerHTML='<button class="btn" onclick="switchTab(\'auction\')">⚡ Open God Auction Board</button>';return}
if(G.activeBidder!==0){bar.innerHTML='<span style="font-size:12px;color:#94a3b8">Waiting for AI opponent…</span>';return}
const p=G.players[0],n=G.turnState.recruitedCount,btn=(label,fn,can=true,primary=false)=>`<button class="btn${primary?' primary':''}" ${can?'':'disabled'} onclick="${fn}">${label}</button>`;let out='';
if(G.mode)out+=btn('✕ Cancel selection','cancelMode()');const costs={ARES:[2,3,4],POSEIDON:[1,2,3],HERA:[1,3,5]};
if(costs[p.god]){const cost=costs[p.god][n],label=p.god==='POSEIDON'?'Fleet':p.god==='HERA'?'Mercenary':'Troop';out+=btn(n<3?`+1 ${label} (${cost}🪙)`:'Recruit limit reached','playerRecruitUnit()',n<3&&p.gp>=cost)}
if(p.god==='ARES')out+=btn('⚔️ March Troops (1🪙)',"startMoveMode('land')",p.gp>=1);
else if(p.god==='POSEIDON')out+=btn('⛵ Sail Fleets (1🪙)',"startMoveMode('sea')",p.gp>=1);
else if(['ZEUS','ATHENA'].includes(p.god))out+=btn(`+1 ${p.god==='ZEUS'?'Priestess':'Philosopher'} (4🪙)`,'playerBuyCard()',!G.turnState.boughtExtraCard&&p.gp>=4);
else if(p.god==='HERA')out+=btn('🦸 Recruit Hero (4🪙)',"switchTab('market')",p.gp>=4);
if(p.god!=='APOLLO'&&p.god!=='ARES'&&lands(0).some(z=>z.heroes.length))out+=btn('🦸 Heroic Move (1🪙)',"startMoveMode('land')",p.gp>=1);
if(p.god!=='APOLLO')out+=btn(`🐉 Myth (${G.creatures.length})`,"switchTab('market')");out+=btn('✅ End Turn','finishCurrentPlayerTurn()',true,true);bar.innerHTML=out;
}
resetGame();
