// One WebGL context and one shared mesh; visible canvases receive the rendered
// model. This avoids a context per fleet and works inside the SVG camera scene.
const Ships17=(()=>{
 let gl=null,stage=null,program=null,buffer=null,vertexCount=0,ready=false,failed=false,dirty=true,lastFrame=0,frameId=null,targets=[],scanQueued=false;
 let viewportWidth=innerWidth,viewportHeight=innerHeight;
 const atlas=document.createElement('canvas'),uniforms={},audioNodes=new Set();
 const stats={triangles:0,frames:0,draws:0,visible:0,contextLost:false,error:null};
 const moving=new Set(),routeMotion=new WeakMap();
 function shader(type,source){const value=gl.createShader(type);gl.shaderSource(value,source);gl.compileShader(value);if(!gl.getShaderParameter(value,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(value));return value}
 function initGL(){stage=document.createElement('canvas');stage.width=stage.height=192;gl=stage.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:true,preserveDrawingBuffer:true,powerPreference:'low-power'});if(!gl)throw Error('WebGL unavailable');
 const vs=shader(gl.VERTEX_SHADER,`attribute vec3 aPosition;attribute vec3 aNormal;uniform float uYaw;uniform float uBob;varying vec3 vNormal;varying float vHeight;void main(){float c=cos(uYaw),s=sin(uYaw);mat3 turn=mat3(c,s,0.,-s,c,0.,0.,0.,1.);vec3 p=turn*aPosition;vec3 n=turn*aNormal;float elevation=.58;float sy=p.z*cos(elevation)+p.y*sin(elevation);float depth=p.y*cos(elevation)-p.z*sin(elevation);gl_Position=vec4(p.x*.88,sy*.88+uBob,depth*.45,1.);vNormal=vec3(n.x,n.z*cos(elevation)+n.y*sin(elevation),n.y*cos(elevation)-n.z*sin(elevation));vHeight=aPosition.z;}`);
 const fs=shader(gl.FRAGMENT_SHADER,`precision mediump float;uniform vec3 uColor;varying vec3 vNormal;varying float vHeight;void main(){vec3 n=normalize(vNormal);float diffuse=abs(dot(n,normalize(vec3(-.6,.9,-1.2))));float light=.48+.52*diffuse;vec3 c=pow(uColor*light,vec3(.8));float edge=pow(max(0.,dot(n,normalize(vec3(.6,.8,1.)))),14.);c+=vec3(.22,.2,.16)*edge;gl_FragColor=vec4(c,1.);}`);
 program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('Ship shader link failed');gl.deleteShader(vs);gl.deleteShader(fs);gl.useProgram(program);for(const name of ['uYaw','uBob','uColor'])uniforms[name]=gl.getUniformLocation(program,name);buffer=gl.createBuffer();gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.clearColor(0,0,0,0);
 stage.addEventListener('webglcontextlost',e=>{e.preventDefault();ready=false;stats.contextLost=true;document.body.classList.remove('ships-3d-ready');cancelAnimationFrame(frameId)});
 stage.addEventListener('webglcontextrestored',()=>{stats.contextLost=false;boot()});
 }
 async function boot(){try{failed=false;initGL();const response=await fetch('assets/v17/dragon-longship.stl');if(!response.ok)throw Error('Ship model unavailable');const bytes=await response.arrayBuffer(),data=new DataView(bytes);if(bytes.byteLength<84)throw Error('Invalid ship model');const count=data.getUint32(80,true);if(count>100000||84+count*50!==bytes.byteLength)throw Error('Invalid ship model size');const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];for(let i=0;i<count;i++)for(let j=0;j<3;j++)for(let k=0;k<3;k++){const v=data.getFloat32(84+i*50+12+j*12+k*4,true);lo[k]=Math.min(lo[k],v);hi[k]=Math.max(hi[k],v)}const center=lo.map((v,i)=>(v+hi[i])/2),scale=1.85/Math.max(...hi.map((v,i)=>v-lo[i])),mesh=new Float32Array(count*18);for(let i=0;i<count;i++){const base=84+i*50,points=[0,1,2].map(j=>[0,1,2].map(k=>data.getFloat32(base+12+j*12+k*4,true))),a=points[1].map((v,k)=>v-points[0][k]),b=points[2].map((v,k)=>v-points[0][k]),n=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],len=Math.hypot(...n)||1;for(let j=0;j<3;j++){const offset=i*18+j*6;for(let k=0;k<3;k++){mesh[offset+k]=(points[j][k]-center[k])*scale;mesh[offset+3+k]=n[k]/len}}}gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,mesh,gl.STATIC_DRAW);for(const [name,offset]of [['aPosition',0],['aNormal',12]]){const at=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(at);gl.vertexAttribPointer(at,3,gl.FLOAT,false,24,offset)}vertexCount=count*3;stats.triangles=count;ready=true;dirty=true;document.body.classList.add('ships-3d-ready');scan();schedule();}catch(e){failed=true;stats.error=e.message;document.body.classList.remove('ships-3d-ready');restoreFallbacks()}}
 function color(pid){const value=G.players[pid]?.color||'#eab308';return [1,3,5].map(n=>parseInt(value.slice(n,n+2),16)/255)}
 function activeMotion(){return APP.motion&&!APP.reducedMotion&&!FX.reduced&&!APP.performanceMode}
 function drawModel(pid,yaw,bob,resolution,x,y){gl.viewport(x,y,resolution,resolution);gl.useProgram(program);gl.uniform1f(uniforms.uYaw,yaw);gl.uniform1f(uniforms.uBob,bob);gl.uniform3fv(uniforms.uColor,color(pid));gl.drawArrays(gl.TRIANGLES,0,vertexCount);stats.draws++}
 function paint(canvas,model,t,motion=false,rect=null){const ctx=canvas.getContext('2d');if(!ctx)return;const w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);ctx.save();ctx.fillStyle='#062e3b55';ctx.beginPath();ctx.ellipse(w*.5,h*.81,w*.34,h*.065,0,0,Math.PI*2);ctx.fill();if(motion&&activeMotion()){ctx.strokeStyle='#ddffffaa';ctx.lineWidth=Math.max(1,w*.012);for(let i=0;i<3;i++){const offset=((t/1700+i/3)%1)*.18;ctx.beginPath();ctx.ellipse(w*.5,h*(.82+offset),w*(.24+offset),h*.035,0,0,Math.PI);ctx.stroke()}}if(rect)ctx.drawImage(model,rect.x,rect.y,rect.q,rect.q,0,0,w,h);else ctx.drawImage(model,0,0,w,h);ctx.restore();canvas.dataset.rendered='true'}
 function visible(el){const r=el.getBoundingClientRect();return r.width>0&&r.height>0&&r.right>0&&r.bottom>0&&r.left<viewportWidth&&r.top<viewportHeight&&!!el.getClientRects().length}
 function sailingHeading(canvas,time){const route=routeMotion.get(canvas);if(!route)return Number(canvas.dataset.shipYaw||-.65);const u=Math.max(0,Math.min(1,(time-route.start)/route.duration)),e=u*u*(3-2*u),step=e*(route.points.length-1),index=Math.min(route.points.length-2,Math.floor(step)),a=route.points[index],b=route.points[index+1],angle=Math.atan2((b.y-a.y)/.55,a.x-b.x);if(!index)return angle;const previous=route.points[index-1],before=Math.atan2((a.y-previous.y)/.55,previous.x-a.x),delta=Math.atan2(Math.sin(angle-before),Math.cos(angle-before)),blend=Math.min(1,(step-index)*5);return before+delta*blend}
 function frame(t){
  frameId=null;if(!ready||document.hidden)return;
  const low=effectiveGraphics17()==='low',motion=activeMotion(),interval=1000/(low?10:24);
  if(t-lastFrame<interval){schedule();return}if(!dirty&&!motion&&!moving.size)return;
  lastFrame=t;stats.frames++;const models=new Map(),visibleTargets=[];
  for(const canvas of targets){
   if(!canvas.isConnected||!visible(canvas))continue;
   if(canvas.closest('#map-view')&&(displayedTab!=='map'||!$('welcome').hidden||B||!$('app-panel').hidden))continue;
   const pid=Number(canvas.dataset.shipPid),travel=moving.has(canvas)||canvas.dataset.shipMotion==='true',yaw=sailingHeading(canvas,t),phase=motion?Math.sin(t/2600+pid*.6):0,angle=yaw+phase*.018,bob=phase*.018,q=canvas.closest('#archipelago')?(low?64:96):(low?128:192),key=[pid,angle.toFixed(3),q].join('|');
   if(!models.has(key))models.set(key,{pid,angle,bob,q});visibleTargets.push({canvas,key,travel});
  }
  const size=Math.max(1,...[...models.values()].map(v=>v.q)),cols=Math.max(1,Math.ceil(Math.sqrt(models.size))),rows=Math.max(1,Math.ceil(models.size/cols)),width=cols*size,height=rows*size;
  if(models.size){
   if(stage.width!==width||stage.height!==height){stage.width=width;stage.height=height}
   gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);let index=0;
   for(const model of models.values()){model.x=index%cols*size;model.y=Math.floor(index/cols)*size;drawModel(model.pid,model.angle,model.bob,model.q,model.x,height-model.y-model.q);index++}
   if(atlas.width!==width||atlas.height!==height){atlas.width=width;atlas.height=height}
   const context=atlas.getContext('2d');context.clearRect(0,0,width,height);context.drawImage(stage,0,0);
   // A single GPU-to-canvas transfer per frame, shared by all visible fleets.
   for(const {canvas,key,travel}of visibleTargets)paint(canvas,atlas,t,travel,models.get(key));
  }
  stats.visible=visibleTargets.length;dirty=false;if((motion&&visibleTargets.length)||moving.size)schedule();
 }
 function schedule(){if(frameId===null&&ready&&!document.hidden)frameId=requestAnimationFrame(frame)}
 function shipCanvas(pid,classes=''){return `<canvas xmlns="http://www.w3.org/1999/xhtml" class="ship-model ${classes}" width="192" height="192" data-ship-pid="${pid}" aria-label="${htmlEscape(G.players[pid]?.name||'Faction')} 3D ship" role="img"></canvas>`}
 function svgShip(pid,x,y,w,h){return `<foreignObject class="ship-viewport" x="${x}" y="${y}" width="${w}" height="${h}" pointer-events="none">${shipCanvas(pid)}</foreignObject>`}
 function convertImages(){for(const img of document.querySelectorAll('img[src*="fleet-"]')){if(img.dataset.shipFallback||img.closest('.ship-image-wrap')||img.classList.contains('effect-figure')||img.classList.contains('travel-piece'))continue;const src=img.getAttribute('src'),faction=src.includes('owl')?OWL_FACTION17:Number(src.match(/fleet-(\d+)/)?.[1]);const pid=G.players.find(p=>p.faction===faction)?.id??faction;if(!Number.isInteger(pid)||!G.players[pid])continue;const canvas=document.createElement('canvas');for(const attr of img.attributes)if(!['src','alt','width','height'].includes(attr.name))canvas.setAttribute(attr.name,attr.value);canvas.classList.add('ship-model');canvas.dataset.shipPid=pid;canvas.width=canvas.height=192;canvas.setAttribute('role','img');canvas.setAttribute('aria-label',img.alt||G.players[pid].name+' ship');canvas.dataset.shipFallbackSrc=src;canvas.style.objectFit='contain';img.replaceWith(canvas)}}
 function restoreFallbacks(){for(const canvas of document.querySelectorAll('canvas[data-ship-fallback-src]')){const img=document.createElement('img');for(const a of canvas.attributes)if(!['width','height','role'].includes(a.name))img.setAttribute(a.name,a.value);img.src=canvas.dataset.shipFallbackSrc;img.dataset.shipFallback='true';canvas.replaceWith(img)}}
 function scan(){scanQueued=false;if(ready)convertImages();if(failed)restoreFallbacks();targets=[...document.querySelectorAll('canvas[data-ship-pid]')];dirty=true;schedule()}
 function queueScan(){if(scanQueued)return;scanQueued=true;queueMicrotask(scan)}
 const observer=new MutationObserver(queueScan);observer.observe(document.body,{childList:true,subtree:true});
 function invalidate(){dirty=true;schedule()}
 window.addEventListener('resize',()=>{viewportWidth=innerWidth;viewportHeight=innerHeight;invalidate()});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frameId);frameId=null;stopAudio()}else invalidate()});
 const cameraBefore17=flushCamera;flushCamera=function(){cameraBefore17();invalidate()};
 const mapPiecesBefore17=renderIndividualPieces;
 renderIndividualPieces=function(z){const html=mapPiecesBefore17(z);if(z.type!=='sea'||!z.fleets)return html;return html.replace(/(<g class="individual-piece fleet-piece[^>]*>)([\s\S]*?)(<\/g>)/g,(match,open,body,close)=>{const image=body.match(/<image[^>]+>/)?.[0];if(!image)return match;const attr=k=>Number(image.match(new RegExp(k+'="([^"]+)"'))?.[1]);return open+body.replace(image,image.replace('<image ','<image class="ship-fallback" ')+svgShip(z.owner,attr('x'),attr('y'),attr('width'),attr('height')))+close})};
 // Route animation is presentation only, with no extra game random draws.
 const battleSpritesBefore17=forceSprites;
 forceSprites=function(f,pid,type,side){const html=battleSpritesBefore17(f,pid,type,side);if(type!=='sea')return html;return html.replace(/<img([^>]+)>/g,(_,attributes)=>`<canvas ${attributes.replace(/src="[^"]*"/,'').replace(/alt="[^"]*"/,'')} width="192" height="192" data-ship-pid="${pid}" data-ship-fallback-src="${factionAsset(pid,'fleet')}" role="img" aria-label="${htmlEscape(G.players[pid].name)} ship"></canvas>`.replace('class="combat-figure"','class="combat-figure ship-model"'))};
 const spriteBeforeShip17=spriteCue15;
 spriteCue15=function(src,zone,pid,frames,ms=1100,kind='unit'){if(!/fleet-/.test(src))return spriteBeforeShip17(src,zone,pid,frames,ms,kind);if(R.auto||!activeMotion()||skipCPUPresentation||!G.zones[zone])return;const point=zoneScreen(zone),el=document.createElement('canvas');el.className='effect-figure ship-model cue-'+kind;el.dataset.shipPid=pid;el.width=el.height=192;el.setAttribute('aria-hidden','true');el.style.cssText=`left:${point.x-34}px;top:${point.y-48}px;width:68px;height:84px;--actor:${G.players[pid]?.color||'#fff'}`;$('fx-layer').appendChild(el);scan();return launchPresentation(el,frames,ms)};
 const tabBeforeShip17=switchTab;
 switchTab=function(...args){const result=tabBeforeShip17(...args);invalidate();return result};
 const travelBefore17=presentForceTravel;
 presentForceTravel=async function(p,from,to,force){
  if(from.type!=='sea')return travelBefore17(p,from,to,force);
  if(R.auto||skipCPUPresentation||document.hidden)return;
  playSailingSound();if(!activeMotion()||!APP.cinematics)return;
  skipCurrentCinema=false;const epoch=R.epoch,route=movementContext?.free?[from.id,to.id]:traceFleetRoute(from.id,to.id);
  if(route.length<2)return;closeSpacePopover();renderMapSVG();
  const points=route.map(zoneScreen),start=points[0],end=points.at(-1),departing=$('zone-'+from.id),animations=[];
  departing?.classList.add('force-departing');
  try{for(let i=0;i<Math.min(force.troops,4);i++){
   const el=document.createElement('canvas');el.className='ship-model sailing-ship';el.dataset.shipPid=p.id;el.width=el.height=192;el.setAttribute('aria-hidden','true');el.style.left=start.x-32+(i%2)*12+'px';el.style.top=start.y-38+Math.floor(i/2)*12+'px';el.dataset.shipYaw=String(Math.atan2((end.y-start.y)/.55,start.x-end.x));routeMotion.set(el,{points,start:performance.now()+i*35/(APP.speed||1),duration:1450/(APP.speed||1)});$('fx-layer').appendChild(el);moving.add(el);
   const animation=el.animate(points.map((point,j)=>({offset:j/(points.length-1),transform:`translate(${point.x-start.x}px,${point.y-start.y}px)`,opacity:j===points.length-1?.15:1})),{duration:1450/(APP.speed||1),delay:i*35/(APP.speed||1),easing:'ease-in-out',fill:'both'});FX.active.add(animation);animation.onfinish=animation.oncancel=()=>{FX.active.delete(animation);moving.delete(el);el.remove()};animations.push(animation)
  }scan();await cinemaPause(1500+Math.min(force.troops,4)*35);if(epoch!==R.epoch)throw Error('Movement presentation cancelled')
  }finally{departing?.classList.remove('force-departing');for(const animation of animations)animation.cancel()}
 };
 // The engine already presents committed movement before changing forces.
 // Keep the obsolete post-hoc inferred animation disabled.
 const beatBefore17=playBattleBeat;
 playBattleBeat=function(beat,side,pid){const result=beatBefore17(beat,side,pid);if(B?.type==='sea'){document.querySelectorAll(`#army-${side} canvas[data-ship-pid]`).forEach(c=>{c.dataset.shipMotion=String(!['fall','crown'].includes(beat))});if(['row','launch','ram','breakwater'].includes(beat))playSailingSound(.8);invalidate()}return result};
 let lastWater=-Infinity,noiseBuffer=null;
 function stopAudio(){for(const node of audioNodes){try{node.source.stop()}catch{}node.source.disconnect();node.filter.disconnect();node.gain.disconnect()}audioNodes.clear()}
 function playSailingSound(duration=1.5){if(!APP.sound||R.auto||skipCPUPresentation||document.hidden||soundGain('Battle')<=0||performance.now()-lastWater<650)return;lastWater=performance.now();try{foleyContext??=new(globalThis.AudioContext||globalThis.webkitAudioContext)();const ctx=foleyContext;ctx.resume?.();if(!noiseBuffer){noiseBuffer=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate);const data=noiseBuffer.getChannelData(0);let seed=7391,previous=0;for(let i=0;i<data.length;i++){seed=(seed*1664525+1013904223)>>>0;previous=previous*.92+(seed/4294967296*2-1)*.08;data[i]=previous*2}}const source=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),gain=ctx.createGain(),node={source,filter,gain};source.buffer=noiseBuffer;source.loop=true;filter.type='lowpass';filter.frequency.value=1250;source.connect(filter);filter.connect(gain);gain.connect(ctx.destination);const t=ctx.currentTime,level=soundGain('Battle')*.65;gain.gain.setValueAtTime(0,t);gain.gain.linearRampToValueAtTime(level,t+.15);gain.gain.linearRampToValueAtTime(level*.65,t+duration*.7);gain.gain.linearRampToValueAtTime(0,t+duration);audioNodes.add(node);source.onended=()=>{source.disconnect();filter.disconnect();gain.disconnect();audioNodes.delete(node)};source.start();source.stop(t+duration+.05)}catch{}}
 const skipBeforeShip17=skipCinematic;
 skipCinematic=function(){stopAudio();return skipBeforeShip17()};
 const saveSettingsBeforeShip17=saveSettings;
 saveSettings=function(){saveSettingsBeforeShip17();if(!APP.sound||soundGain('Battle')<=0)stopAudio();invalidate()};
 boot();return {stats,scan,invalidate,playSailingSound,get ready(){return ready},get failed(){return failed},get activeSounds(){return audioNodes.size}};
})();
globalThis.Ships17=Ships17;
