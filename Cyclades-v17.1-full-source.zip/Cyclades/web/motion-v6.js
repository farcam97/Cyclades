// 100 additional action sequences: 20 actions × 5 spatial choreographies.
// These are procedural multi-part effects, not 100 hand-drawn sprite animations.
const ACTION_SCENES=['march','charge','volley','shield-wall','spear-strike','rally','muster','fall','retreat','embark','rowing','ram','turn','wake','launch','anchor','sinking','shorebreak','construction','city-rise'];
const SCENE_FORMATIONS=['column','line','wedge','arc','scatter'];
for(const action of ACTION_SCENES)for(const formation of SCENE_FORMATIONS)ANIMATIONS.push({id:ANIMATIONS.length+1,name:`action-${action}-${formation}`,category:'action',action,formation});
if(ANIMATIONS.length!==300)throw Error('Expected 300 animation treatments');
let quietGodResolution=false,sceneCounter=0,lastMovingForce=null;
const quietTurn=beginTurn;beginTurn=async function(...args){quietGodResolution=true;try{return await quietTurn(...args)}finally{quietGodResolution=false}};
const scenePlayBefore=playFX;
function sceneFormation(name,i,n){const t=n===1?0:i/(n-1),a=t*Math.PI;return name==='column'?{x:(i%2)*9-5,y:(i-n/2)*10}:name==='line'?{x:(i-n/2)*12,y:0}:name==='wedge'?{x:Math.abs(i-n/2)*12-12,y:(i-n/2)*10}:name==='arc'?{x:Math.cos(a)*28,y:Math.sin(a)*18-8}:{x:Math.sin(i*2.4)*32,y:Math.cos(i*2.4)*24}}
function sceneProfile(action,i){
 const delay=i*45;
 const data={march:[-34,0,34,0,0],charge:[-45,8,42,-4,-15],volley:[-32,22,46,-24,-25],'shield-wall':[-20,0,0,0,0],'spear-strike':[-28,0,25,0,0],rally:[0,20,0,-15,0],muster:[-26,20,0,0,0],fall:[0,0,8,22,65],retreat:[20,0,-45,12,-10],embark:[-32,20,16,-8,0],rowing:[-36,0,30,0,0],ram:[-44,0,35,0,0],turn:[-22,16,20,-16,-35],wake:[0,0,-40,6,0],launch:[-32,20,25,-8,0],anchor:[0,-22,0,16,0],sinking:[0,0,0,30,22],shorebreak:[-30,0,30,12,0],construction:[0,30,0,-3,0],'city-rise':[0,35,0,-8,0]}[action];
 return{delay,frames:[{offset:0,opacity:0,transform:`translate(${data[0]}px,${data[1]}px) rotate(0deg) scale(.75)`},{offset:.18,opacity:1,transform:`translate(${data[0]*.75}px,${data[1]*.75}px) rotate(0deg) scale(1)`},{offset:.65,opacity:1,transform:`translate(${data[2]*.7}px,${data[3]*.7}px) rotate(${data[4]*.7}deg) scale(1)`},{offset:1,opacity:0,transform:`translate(${data[2]}px,${data[3]}px) rotate(${data[4]}deg) scale(${/fall|sinking/.test(action)?.45:1})`}]};
}
function actionScene(name,opts={}){const a=ANIMATIONS.find(x=>x.name===name);if(!a)return;if(FX.reduced||R.auto||!document.createElement)return;const target=opts.target||(opts.zone!==undefined?$('zone-'+opts.zone):document.querySelector('.viewport'));if(!target)return;const rect=target.getBoundingClientRect();if(!rect.width)return;FX.history.push(name);if(FX.history.length>300)FX.history.shift();const pid=opts.pid??G.zones[opts.zone]?.owner??0,n=opts.preview?5:Math.min(7,Math.max(3,opts.count||4)),cx=rect.left+rect.width/2,cy=rect.top+rect.height/2;
 const marine=['rowing','ram','turn','wake','launch','anchor','sinking','shorebreak'].includes(a.action),construction=['construction','city-rise'].includes(a.action);
 function launch(el,frames,duration,delay=0){$('fx-layer').appendChild(el);if(!el.animate){el.remove();return}const anim=el.animate(frames,{duration:duration/(APP.speed||1),delay:delay/(APP.speed||1),fill:'both',easing:'cubic-bezier(.2,.65,.3,1)'});FX.active.add(anim);anim.onfinish=anim.oncancel=()=>{el.remove();FX.active.delete(anim)}}
 for(let i=0;i<n;i++){const pos=sceneFormation(a.formation,i,n),el=document.createElement('div');el.className='action-scene-part';el.style.cssText=`left:${cx+pos.x-14}px;top:${cy+pos.y-17}px;width:28px;height:34px;`;
 const symbol=a.action==='volley'?'<path d="M1 23L25 2m-7 1 7-1-1 7M2 17l6 1-1 6" stroke="#fff1be" stroke-width="2" fill="none"/>':a.action==='spear-strike'?'<path d="M0 17h25m-6-4 6 4-6 4" stroke="#ffe6a1" stroke-width="2" fill="none"/>':a.action==='shield-wall'?'<path d="M4 6L14 2l10 4v10q-1 10-10 15Q5 26 4 16Z" fill="#b78d45" stroke="#fff0b9" stroke-width="2"/>':a.action==='anchor'?TABLETOP_ICONS.P: ['wake','shorebreak'].includes(a.action)?'<path d="M1 10q6-7 12 0t12 0M0 18q6-5 12 0t12 0" fill="none" stroke="#d7fff3" stroke-width="2"/>':construction?'<path d="M2 12h24v16H2ZM2 12l10-7 14 7M12 5v16l14 7" fill="#e8d6a2" stroke="#957144"/>':null;
 el.innerHTML=symbol?`<svg viewBox="0 0 28 34" width="28" height="34" style="color:#ead5a5">${symbol}</svg>`:`<img src="${typeof factionAsset==='function'?factionAsset(pid,marine?'fleet':'warrior'):PAINT+(marine?'fleet-':'warrior-')+pid+'.webp'}" alt="">`;
 const p=sceneProfile(a.action,i);launch(el,p.frames,750,p.delay);
 // Secondary effects tell the action: splashes, dust, impacts, masonry sparks.
 const particle=document.createElement('div');particle.className='action-scene-particle';particle.style.cssText=`left:${cx+pos.x}px;top:${cy+pos.y+12}px;border-color:${marine?'#d7fff2':construction?'#ffe7a7':'#d7b975'};`;
 const dx=/volley|spear|ram|charge/.test(a.action)?30:marine?-22:(i%2?-12:12);
 launch(particle,[{opacity:0,transform:'scale(.1)'},{opacity:.8,offset:.2,transform:'scale(.6)'},{opacity:0,transform:`translate(${dx}px,${marine?8:-15}px) scale(1.9)`}],650,p.delay+110);
 if(a.action==='rowing'){const oar=document.createElement('div');oar.className='action-oar';oar.style.cssText=`left:${cx+pos.x-8}px;top:${cy+pos.y+5}px;`;launch(oar,[{transform:'rotate(-45deg)',opacity:0},{transform:'rotate(30deg)',opacity:1,offset:.35},{transform:'translate(20px,0) rotate(-45deg)',opacity:0}],650,p.delay)}
 }
}
function actionEvent(action,opts={}){const formation=SCENE_FORMATIONS[(sceneCounter++)%5];return playFX(`action-${action}-${formation}`,opts)}
playFX=function(name,opts={}){
 if(!opts.preview&&!opts.loop&&(quietGodResolution||['SETUP','OFFERINGS','MAINTENANCE','INCOME'].includes(G.phase)))return;
 if(name.startsWith('action-'))return actionScene(name,opts);
 // Remove generic post-selection/auction bursts and all unit idle treatments.
 if(!opts.preview&&/^(bid-|tab-open|panel-rise|choice-|button-press|card-hover|card-reveal)|-(invoke|blessing)$/.test(name))return;
 if(!opts.preview&&/^ship-|^troop-/.test(name))return;
 if(!opts.preview&&/-(arrival|attack)$/.test(name))return actionEvent(name.endsWith('arrival')?'rally':'charge',opts);
 if(!opts.preview&&name==='shield-block')return actionEvent('shield-wall',opts);
 if(!opts.preview&&/-(march|sail|retreat)$/.test(name))return;
 if(!opts.preview&&/-(spawn|defeat|raise|glow)$/.test(name)){if(name.endsWith('-glow'))return;return actionEvent(name.endsWith('-spawn')?'muster':name.endsWith('-defeat')?(G.zones[opts.zone]?.type==='sea'?'sinking':'fall'):name.startsWith('metropolis')?'city-rise':'construction',opts)}
 return scenePlayBefore(name,opts);
};
// Retain gently flowing water, with no idle sway on soldiers or vessels.
attachAmbient=function(){};
const sceneForce=selectForce;selectForce=async function(p,z,...rest){const f=await sceneForce(p,z,...rest);lastMovingForce={pid:p.id,from:z.id,type:z.type,count:f.troops+f.mercs+f.heroes.length};return f};
animateTravel=function(pid,type,from,to){if(FX.reduced||R.auto||!document.createElement)return;const n=lastMovingForce?.from===from?lastMovingForce.count:1,svg=$('archipelago'),rect=svg.getBoundingClientRect(),scale=Math.min(rect.width/(560/viewZoom),rect.height/(690/viewZoom)),ox=rect.left+(rect.width-560/viewZoom*scale)/2,oy=rect.top+(rect.height-690/viewZoom*scale)/2,a=G.zones[from],b=G.zones[to];for(let i=0;i<n;i++){const el=document.createElement('img');el.className='travel-piece';el.src=PAINT+(type==='sea'?'fleet-':'warrior-')+pid+'.webp';el.style.cssText=`left:${ox+(a.x-viewX)*scale-18+(i%3)*7}px;top:${oy+(a.y-viewY)*scale-22+Math.floor(i/3)*7}px;width:36px;height:44px;`;$('fx-layer').appendChild(el);const path=previewRoute(from,to),frames=path.map((id,j)=>({transform:`translate(${(G.zones[id].x-a.x)*scale}px,${(G.zones[id].y-a.y)*scale}px)`,opacity:j===path.length-1?0:1}));const anim=el.animate(frames,{duration:900/(APP.speed||1),delay:i*45/(APP.speed||1),fill:'both',easing:'ease-in-out'});FX.active.add(anim);anim.onfinish=anim.oncancel=()=>{FX.active.delete(anim);el.remove()}}actionEvent(type==='sea'?'rowing':'march',{zone:to,pid,count:n});if(type==='sea'){actionEvent(b.x<a.x?'turn':'wake',{zone:from,pid,count:n});actionEvent('anchor',{zone:to,pid,count:3})}else if(a.island!==b.island){actionEvent('embark',{zone:from,pid,count:n});actionEvent('shorebreak',{zone:to,pid,count:3})}};
const sceneBattle=showBattle;showBattle=function(msg){sceneBattle(msg);if(B&&/prepare to roll/.test(msg))actionEvent(B.type==='sea'?'ram':B.attId===2?'volley':'spear-strike',{zone:B.toId,pid:B.attId})};
const sceneRetreat=retreatSide;retreatSide=async function(side){const pid=B?.[side+'Id'],zone=B?.toId,ok=await sceneRetreat(side);if(ok)actionEvent('retreat',{zone,pid});return ok};
const sceneRecruit=recruit;recruit=async function(p,kind,...args){const before=G.zones.map(z=>z[kind]||0),ok=await sceneRecruit(p,kind,...args);if(ok){const z=G.zones.find(z=>(z[kind]||0)>before[z.id]);if(z)actionEvent(kind==='fleets'?'launch':'muster',{zone:z.id,pid:p.id})}return ok};
showAnimationCatalog=function(){const el=$('animation-catalog');el.hidden=!el.hidden;el.innerHTML='<p>300 procedural motion treatments. The newest 100 combine action, particles and five formations. Ambient unit swaying and auction bursts are disabled during play.</p>'+ANIMATIONS.map(a=>`<button onclick="previewMotion('${a.name}',this)">${a.id}. ${a.name.replaceAll('-',' ')}</button>`).join('')};
const sceneCatalogBtn=document.querySelector('button[onclick="showAnimationCatalog()"]');if(sceneCatalogBtn)sceneCatalogBtn.textContent='Preview all 300 animations';
renderAll();
