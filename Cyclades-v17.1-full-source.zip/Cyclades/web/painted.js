// Painted presentation layer. Rules and legal-move graph remain engine-owned.
const PAINT='assets/painted/';
const islandStyles=shuffle([0,1,2,3,4,5]);
function paintedImage(name,x,y,w,h,cls=''){return `<image class="${cls}" href="${PAINT+name}.webp" x="${x}" y="${y}" width="${w}" height="${h}" preserveAspectRatio="xMidYMid meet"/>`}
function numberSeal(x,y,n,color){return `<circle cx="${x}" cy="${y}" r="10" fill="#132f36" stroke="${color}" stroke-width="2"/><text x="${x}" y="${y+4}" class="army-count">${n}</text>`}
renderMapSVG=function(){
 if(!G.players?.[0]?.protected)return;
 let s=MAP_DEFS+FACTION_DEFS+`<defs><radialGradient id="paint-sea"><stop stop-color="#159bad"/><stop offset=".7" stop-color="#097b91"/><stop offset="1" stop-color="#065367"/></radialGradient><pattern id="paint-waves" width="49" height="31" patternUnits="userSpaceOnUse"><path d="M3 14q7-3 14 0m14 13q6-2 12 0" fill="none" stroke="#8ce4d7" opacity=".15" stroke-width=".7"/></pattern>`;
 for(let i=0;i<12;i+=2){const a=G.zones[i],b=G.zones[i+1];if(!a||!b)continue;const cx=(a.x+b.x)/2,cy=(a.y+b.y)/2;s+=`<clipPath id="island-clip-${i}"><ellipse cx="${cx}" cy="${cy}" rx="99" ry="72"/></clipPath>`}s+='</defs>';
 s+=`<rect width="560" height="690" rx="6" fill="url(#paint-sea)"/><rect class="ambient-ocean" width="560" height="690" fill="url(#paint-waves)"/>`;
 // Quiet, readable sea boundaries; interactive geometry stays attached to its zone.
 for(const z of G.zones.filter(z=>z.type==='sea'))s+=`<path d="${z.path}" fill="none" stroke="#d3f6ed" stroke-opacity=".2" stroke-width="1"/>`;
 for(let i=0;i<12;i+=2){const a=G.zones[i],b=G.zones[i+1];if(!a||!b)continue;const cx=(a.x+b.x)/2,cy=(a.y+b.y)/2,art=a.artIndex??islandStyles[i/2];s+=paintedImage('island-'+art,cx-121,cy-94,242,188,'paint-island');const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len;s+=`<path d="M${cx-nx*70} ${cy-ny*70}L${cx+nx*70} ${cy+ny*70}" clip-path="url(#island-clip-${i})" fill="none" stroke="#3d543d" stroke-width="4" opacity=".45"/><path d="M${cx-nx*70} ${cy-ny*70}L${cx+nx*70} ${cy+ny*70}" clip-path="url(#island-clip-${i})" fill="none" stroke="#fff5d8" stroke-width="2" stroke-dasharray="6 2"/><text x="${cx}" y="${cy-55}" class="island-title" text-anchor="middle">${String(a.name||'').replace(/ West$/,'').toUpperCase()}</text>`}
 for(const z of G.zones){const land=z.type==='land',x=land?z.x:Math.max(39,Math.min(518,z.x)),y=z.y,col=z.owner===null?'#d6c798':G.players[z.owner].color,valid=availableZone(z.id),selected=R.inspected===z.id,clip=land?`clip-path="url(#island-clip-${z.id-z.id%2})"`:'';
 s+=`<g id="zone-${z.id}" data-zone="${z.id}" class="paint-zone ${valid?'legal-space':''} ${selected?'inspected-space':''}" role="button" tabindex="0" aria-label="${z.name}${valid?', available':''}" onclick="onZoneClick(${z.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();onZoneClick(${z.id})}"><path d="${z.path}" ${clip} class="paint-hit"/>`;
 if(land){
 if(z.troops+z.mercs){s+=paintedImage('warrior-'+z.owner,x-34,y-30,51,61,'warrior-sprite')+numberSeal(x+3,y+23,z.troops+z.mercs,col)}else{s+=`<circle cx="${x-11}" cy="${y+4}" r="12" fill="#173a32b0" stroke="${col}" stroke-width="2"/><svg x="${x-21}" y="${y-6}" width="20" height="20" viewBox="0 0 40 40" style="color:${col}">${z.owner===null?'':`<use href="#crest-${z.owner}"/>`}</svg>`}
 const building=z.metros.length?'M':z.bldgs[0];if(building)s+=paintedImage('building-'+building,x+5,y-4,38,40,'building-sprite');else s+=`<path d="m${x+14} ${y+12} 10-5 10 5-10 6Z" fill="#ecd69c" stroke="#7d6e43" stroke-width="1"/><path d="m${x+19} ${y+11} 5-3 5 3-5 3Z" fill="#958b5d"/>`;
 s+=`<rect x="${x-27}" y="${y+34}" width="53" height="16" rx="8" fill="#f6e8bc" stroke="#766b47" stroke-width=".6"/><text x="${x}" y="${y+45}" class="land-resource" text-anchor="middle">◉ ${z.pros}${z.priestIcon?'  ❧':''}</text>`;
 if(z.heroes.length)s+=`<image class="hero-token" href="assets/${z.heroes[0].id}.webp" x="${x+24}" y="${y-33}" width="29" height="34"/>`;
 }else{if(z.fleets)s+=paintedImage('fleet-'+z.owner,x-30,y-21,60,53,'fleet-sprite')+numberSeal(x+24,y+24,z.fleets,col);else if(valid)s+=`<circle class="placement-ring" cx="${x}" cy="${y+2}" r="17"/><path d="M${x-6} ${y+2}h12m-6-6v12" stroke="#fff0b1" stroke-width="2"/>`;if(z.pros)s+=`<text x="${x}" y="${y+(z.fleets?46:29)}" class="sea-resource" text-anchor="middle">◉ ${z.pros}</text>`;if(selected||valid)s+=`<text x="${x}" y="${y-27}" class="water-title" text-anchor="middle">${z.name}</text>`}
 const m=G.monsters.find(m=>m.zone===z.id);if(m)s+=`<image href="assets/${m.id==='minotaur'?'minotaur-piece':m.id}.webp" x="${x-26}" y="${y-31}" width="54" height="58"/>`;
 s+='</g>';
 }
 s+='<g id="map-fx"></g>';$('archipelago').innerHTML=s;
};
const paintedReset=resetGame;resetGame=function(){islandStyles.splice(0,6,...shuffle([0,1,2,3,4,5]));paintedReset();G.zones.filter(z=>z.type==='land').forEach(z=>z.artIndex=islandStyles[z.id>>1]);renderAll()};
document.querySelector('.map-legend').innerHTML='<span><i class="legend-dot" style="background:#eab308"></i>Lion · You</span><span><i class="legend-dot" style="background:#ef4444"></i>Scorpion</span><span><i class="legend-dot" style="background:#a855f7"></i>Eagle</span><span>3 cities to win</span>';
document.querySelector('.map-label').innerHTML='THE AEGEAN';
const paintedBattle=showBattle;showBattle=function(msg){paintedBattle(msg);for(const side of ['att','def']){const el=$(side+'-panel').querySelector('.battle-emblem');if(el)el.src=PAINT+(B.type==='sea'?'fleet-':'warrior-')+B[side+'Id']+'.webp'}};
renderAll();
