// Board-bound animation: purely presentation, with cancellation tied to the campaign epoch.
function soundPosition(id){const z=G.zones[id];return z?Math.max(-.85,Math.min(.85,((z.x-viewX)/(560/viewZoom)-.5)*1.7)):0}
function zoneScreen(id){const z=G.zones[id],r=mapEl.getBoundingClientRect(),s=Math.min(r.width/(560/viewZoom),r.height/(690/viewZoom));return {x:r.left+(r.width-560/viewZoom*s)/2+(z.x-viewX)*s,y:r.top+(r.height-690/viewZoom*s)/2+(z.y-viewY)*s,scale:s}}
function launchPresentation(el,frames,ms=900,delay=0){if(!el?.animate){el?.remove?.();return null}const a=el.animate(frames,{duration:ms/(APP.speed||1),delay:delay/(APP.speed||1),easing:'ease-in-out',fill:'both'});FX.active.add(a);a.onfinish=a.oncancel=()=>{FX.active.delete(a);el.remove?.()};return a}
async function presentForceTravel(p,from,to,f){
 if(R.auto||FX.reduced||!APP.cinematics||!document.createElement)return;
 skipCurrentCinema=false;const epoch=R.epoch,route=movementContext?.free?[from.id,to.id]:traceFleetRoute(from.id,to.id,movementContext?.hero==='jason');if(route.length<2)return;
 closeSpacePopover();renderMapSVG();const start=zoneScreen(from.id),path=route.map(zoneScreen),images=[...Array.from({length:f.troops},()=>({src:factionAsset(p.id,from.type==='sea'?'fleet':'warrior')})),...Array.from({length:f.mercs},()=>({src:PAINT+'mercenary.webp',merc:true})),...f.heroes.map(h=>({src:unitPiecePath(h.id)}))];
 const departing=$('zone-'+from.id);departing?.classList.add('force-departing');const running=[];
 for(const [i,u] of images.entries()){
  const el=document.createElement('img');el.className='travel-piece '+(u.merc?'mercenary-sprite':'');el.src=u.src;el.alt='Moving figure';el.style.cssText=`left:${start.x-18+(i%4-1.5)*9}px;top:${start.y-24+Math.floor(i/4)*9}px;width:36px;height:48px;`;$('fx-layer').appendChild(el);
  const frames=path.map((pt,j)=>({offset:j/(path.length-1),transform:`translate(${pt.x-start.x}px,${pt.y-start.y}px) scale(${from.type==='land'&&G.zones[route[j]].type==='sea'?.75:1})`,opacity:j===path.length-1?.15:1}));running.push(launchPresentation(el,frames,1050,i*15));
 }
 if(from.type==='land'&&route.some(id=>G.zones[id].type==='sea')){actionEvent('embark',{zone:from.id,pid:p.id});actionEvent('shorebreak',{zone:to.id,pid:p.id})}
 playFoley(from.type==='sea'?'splash':'march','Battle',soundPosition(from.id));
 try{await cinemaPause(1100+images.length*15);if(epoch!==R.epoch)throw Error('Movement presentation cancelled');playFoley(from.type==='sea'?'splash':'march','Battle',soundPosition(to.id))}finally{departing?.classList.remove('force-departing');for(const a of running)a?.cancel()}
}
// The old post-hoc inferred movement duplicated units and missed defeated attackers.
animateTravel=function(){};
let cameraTweenToken=0;
function animateCamera(target,ms=380){
 const token=++cameraTweenToken;if(FX.reduced||R.auto||typeof requestAnimationFrame!=='function'){viewZoom=target.zoom;viewX=target.x;viewY=target.y;applyView();return Promise.resolve()}
 const a={zoom:viewZoom,x:viewX,y:viewY},start=globalThis.performance?.now?.()||Date.now();
 return new Promise(resolve=>{function tick(now){if(token!==cameraTweenToken){resolve();return}const t=Math.min(1,Math.max(0,(now-start)/ms)),e=t*t*(3-2*t);viewZoom=a.zoom+(target.zoom-a.zoom)*e;viewX=a.x+(target.x-a.x)*e;viewY=a.y+(target.y-a.y)*e;applyView();if(t<1)requestAnimationFrame(tick);else resolve()}requestAnimationFrame(tick)});
}
mapEl.addEventListener('pointerdown',()=>cameraTweenToken++,{capture:true});
const framedBattle=battle;battle=async function(p,from,to,f,type){
 if(R.auto)return framedBattle(p,from,to,f,type);
 const epoch=R.epoch,previous={zoom:viewZoom,x:viewX,y:viewY};
 await animateCamera({zoom:2.25,x:to.x-280/2.25,y:to.y-345/2.25});
 if(epoch!==R.epoch)throw Error('Battle focus cancelled');haptic('battle');
 try{return await framedBattle(p,from,to,f,type)}finally{if(epoch===R.epoch)await animateCamera(previous)}
};
forceSprites=function(f,pid,type,side){const units=[...Array.from({length:f.troops},()=>({key:'troops',src:PAINT+(type==='sea'?'fleet-':'warrior-')+pid+'.webp',name:type==='sea'?'Fleet':'Troop'})),...Array.from({length:f.mercs},()=>({key:'mercs',src:PAINT+'warrior-'+pid+'.webp',name:'Mercenary'})),...f.heroes.map(h=>({key:h.id,src:unitPiecePath(h.id),name:h.name})),...(f.minotaur?[{key:'minotaur',src:'assets/figures/minotaur.webp',name:'Minotaur'}]:[])];return units.map((u,i)=>`<img class="combat-figure ${u.key==='mercs'?'mercenary-sprite':''}" data-casualty="${u.key}" data-combat-side="${side}" src="${u.src}" alt="${u.name}" style="--unit:${i};--count:${units.length}">`).join('')};
function strengthParts(side){const f=B[side],pid=B[side+'Id'],units=f.troops+f.mercs,heroes=f.heroes.length+(heroPower(f,'ajax',pid)?1:0)+(f.minotaur?2:0);return {units,heroes,buildings:battleStrength(f,pid,side==='def')-units-heroes}}
function battleBreakdown(side,roll=null){if(!B)return '';const shown=roll||B.lastRoll,parts=shown&&B.strengthBreakdown&&B.strengthBreakdown.round===shown.round?B.strengthBreakdown[side]:strengthParts(side),{units,heroes,buildings}=parts,pid=B[side+'Id'],die=shown?.[side==='att'?'ad':'dd'];return `<div class="strength-breakdown"><b>${G.players[pid].name}</b><span>Units ${units}</span><span>Heroes / Minotaur ${heroes}</span><span>Buildings ${buildings}</span><span>Die ${die??'—'}</span><strong>Total ${units+heroes+buildings+(die??0)}</strong></div>`}
const explainedBattle=showBattle;showBattle=function(msg){if(B&&/prepare to roll/.test(msg)&&B.lastRoll?.round!==B.round)B.lastRoll=null;explainedBattle(msg);$('battle-roll-summary').insertAdjacentHTML('afterbegin',`<div class="battle-breakdowns">${battleBreakdown('att')}${battleBreakdown('def')}</div>`)};
const totalsRound=animateBattleRound;animateBattleRound=async function(roll){if(B)B.strengthBreakdown={round:roll.round,att:strengthParts('att'),def:strengthParts('def')};const out=await totalsRound(roll);if(B)$('battle-roll-summary').innerHTML=`<div class="battle-breakdowns">${battleBreakdown('att',roll)}${battleBreakdown('def',roll)}</div>`;return out};
const CREATURE_ENTRANCES={
 charon:['ferry',-65,18,0,0],chimera:['flame',0,30,0,-8],cyclops:['forge',0,-65,0,0],dryad:['leaves',-20,25,0,0],giant:['stomp',0,-85,0,0],griffin:['swoop',-75,-70,0,0],harpy:['dive',60,-90,0,0],graeae:['vision',0,0,0,-15],pegasus:['flight',-90,-80,0,0],satyr:['leap',-50,30,0,0],sphynx:['sand',0,35,0,0],sylph:['wind',-80,-15,20,-5],cerberus:['charge',-80,5,0,0],hydra:['rise',0,65,0,0],kraken:['surface',0,85,0,0],medusa:['stone',0,0,0,0],minotaur:['rush',-75,12,0,0],polyphemus:['boulder',0,-70,0,0]
};
showEffectFigure=function(id,zone){
 if(FX.reduced||R.auto||!document.createElement||!CREATURE_ENTRANCES[id])return;
 const z=G.zones[zone]||lands(humanPid())[0];if(!z)return;const pt=zoneScreen(z.id),[kind,x,y,tx,ty]=CREATURE_ENTRANCES[id],el=document.createElement('img');el.className='effect-figure entrance-'+kind;el.src='assets/figures/'+id+'.webp';el.alt=id;el.style.cssText=`left:${pt.x-48}px;top:${pt.y-64}px;`;$('fx-layer').appendChild(el);
 launchPresentation(el,[{opacity:0,transform:`translate(${x}px,${y}px) scale(${kind==='vision'?.3:.75})`},{opacity:1,transform:`translate(${tx}px,${ty}px) scale(1)`,offset:.3},{opacity:1,transform:`translate(${tx}px,${ty-5}px) scale(1.05)`,offset:.75},{opacity:0,transform:`translate(${tx}px,${ty-20}px) scale(.95)`}],1500);
 const ring=document.createElement('div');ring.className='creature-entrance-field field-'+kind;ring.style.cssText=`left:${pt.x-45}px;top:${pt.y-18}px;`;$('fx-layer').appendChild(ring);launchPresentation(ring,[{opacity:0,transform:'scale(.1)'},{opacity:.85,transform:'scale(1)',offset:.35},{opacity:0,transform:'scale(2.2)'}],1300);
 playFoley(['surface','rise','ferry'].includes(kind)?'splash':['forge','stomp','boulder','stone'].includes(kind)?'build':'cloth','Battle',soundPosition(z.id));
};
// Persistent presence is an inspection badge, not an additional game figure.
let presenceSignature='';
const creatureMap=renderMapSVG;renderMapSVG=function(){creatureMap();const signature=PERF.mapBuilds+'|'+JSON.stringify(G.monsters);if(signature===presenceSignature)return;presenceSignature=signature;document.querySelectorAll?.('.presence-badge').forEach(el=>el.remove?.());for(const m of G.monsters){const z=G.zones[m.zone],label={medusa:'STOP',kraken:'NO FLEETS',polyphemus:'SEA BAN',hydra:'×2',cerberus:'INCOME',minotaur:'+2'}[m.id]||'EFFECT';$('zone-'+z.id)?.insertAdjacentHTML('beforeend',`<g class="presence-badge presence-${m.id}" role="button" tabindex="0" aria-label="Inspect ${m.id} effect" onclick="if(!R.pending){event.stopPropagation();showCreaturePresence(${z.id})}" onkeydown="if(!R.pending &amp;&amp; event.key==='Enter'){event.stopPropagation();showCreaturePresence(${z.id})}"><rect x="${z.x-28}" y="${z.y+43}" width="56" height="17" rx="6"/><text x="${z.x}" y="${z.y+55}" text-anchor="middle">${label}</text></g>`)} };
