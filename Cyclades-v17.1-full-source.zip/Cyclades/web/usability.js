// Controls and inspection: all commitments still run through the authoritative engine.
const APP_VERSION='17.1';
APP={stereo:true,briefings:false,tutorial:false,textSize:1,buttonSize:1,labelSize:1,...APP};
const RECRUIT_COSTS={ARES:[2,3,4],POSEIDON:[1,2,3],HERA:[1,3,5]};
let travelIntent=null,movementContext=null,forceDraft=null,forceDrag=null,cinematicMap=false;
function haptic(kind='select'){if(!APP.haptics||!globalThis.navigator?.vibrate)return;try{navigator.vibrate({select:8,confirm:[12,25,12],invalid:[35,25,35],battle:[20,40,55]}[kind]||8)}catch{}}
function recruitReason(z){
 const p=G.players[humanPid()],n=G.turnState.recruitedCount||0,kind={ARES:'troops',POSEIDON:'fleets',HERA:'mercs'}[p.god];
 if(!myAction())return 'Wait until your optional action turn.';
 if(!kind)return 'Recruitment requires Ares, Poseidon or Hera.';
 if(n>=3)return 'You have already bought all three recruits this turn.';
 if(p.gp<RECRUIT_COSTS[p.god][n])return 'You need '+RECRUIT_COSTS[p.god][n]+' gold for the next recruit.';
 if(kind==='fleets'){
  if(z.type!=='sea')return 'Fleets must be placed in a Sea Area.';
  if(seasBlocked(z))return 'A Creature prohibits Fleets in these waters.';
  if(z.owner!==null&&z.owner!==humanPid())return 'You cannot recruit into enemy waters.';
  if(!z.adj.some(id=>G.zones[id].type==='land'&&G.zones[id].owner===humanPid()))return 'Recruit beside one of your Land Areas.';
  if(fleetCount(humanPid())>=8)return 'All eight basic Fleets are already in play.';
 }else{
  if(z.type!=='land'||z.owner!==humanPid())return 'Recruit on a Land Area you control.';
  if(typeof boarBlocks==='function'&&boarBlocks(z))return 'The Boar blocks recruitment here.';
  if(kind==='troops'&&basicCount(humanPid())>=8)return 'All eight Troops are already in play.';
  if(kind==='mercs'&&mercCount()>=16)return 'The shared Mercenary reserve is empty.';
 }return '';
}
function movementReason(z){
 if(!myAction())return 'Wait until your optional action turn.';
 if(z.owner!==humanPid())return 'Choose one of your own forces.';
 if(!(z.type==='sea'?z.fleets:army(z)))return 'There are no mobile units in this area.';
 if(z.type==='land'&&medusa(z))return 'Medusa prevents this force from leaving.';
 const p=G.players[humanPid()];if(p.god==='APOLLO'&&!(z.type==='land'&&z.heroes.some(h=>h.id==='leto')))return 'Apollo requires Leto to move.';
 if(z.type==='sea'&&p.god!=='POSEIDON')return 'Sailing requires Poseidon.';
 if(z.type==='land'&&p.god!=='ARES'&&!z.heroes.length)return 'This force needs Ares or a Hero to move.';
 const cost=z.type==='land'&&p.god!=='ARES'?Math.min(...z.heroes.map(h=>h.id==='pericles'?1:(G.turnState.heroicMoves||0)+1)):1;
 return p.gp<cost?'This move needs at least '+cost+' gold.':'';
}
function explainSpaceAction(id,kind){const z=G.zones[id];if(!z)return;const why=kind==='recruit'?recruitReason(z):movementReason(z);setPrompt(why||'This action is available.');haptic(why?'invalid':'select')}
function availableMoves(z){const p=G.players[humanPid()];return z.type==='sea'?z.adj.map(id=>G.zones[id]).filter(t=>t.type==='sea'&&!seasBlocked(t)):landTargets(p,z,false,p.god!=='ARES'&&z.heroes.some(h=>h.id==='jason'))}
function unitsFor(z){return [...Array.from({length:z.type==='sea'?z.fleets:z.troops},(_,i)=>({key:'t'+i,kind:'troops',name:(z.type==='sea'?'Fleet ':'Troop ')+(i+1),src:PAINT+(z.type==='sea'?'fleet-':'warrior-')+z.owner+'.webp'})),...Array.from({length:z.mercs||0},(_,i)=>({key:'m'+i,kind:'mercs',name:'Mercenary '+(i+1),src:PAINT+'warrior-'+z.owner+'.webp'})),...(z.heroes||[]).map(h=>({key:h.id,kind:'hero',name:h.name,src:'assets/figures/'+h.id+'.webp'}))]}
function openForceFan(id){const z=G.zones[id];if(!z)return;forceDraft={zone:id,keys:unitsFor(z).map(u=>u.key)};showAppPanel('force-select');renderForceFan()}
function renderForceFan(){const z=G.zones[forceDraft.zone];$('app-panel-content').innerHTML=`<h3>${htmlEscape(z.name)} · choose figures</h3><p>Tap individual figures to include or leave them behind. Nothing moves until the final confirmation.</p><div class="selection-fan">${unitsFor(z).map((u,i)=>`<button class="fan-piece ${forceDraft.keys.includes(u.key)?'chosen':''}" aria-pressed="${forceDraft.keys.includes(u.key)}" onclick="toggleFanPiece('${u.key}')" style="--fan-angle:${(i%5-2)*3}deg"><img class="${u.kind==='mercs'?'mercenary-sprite':''}" src="${u.src}" alt=""><span>${u.name}</span></button>`).join('')}</div><p>${forceDraft.keys.length} selected</p>${btn('Choose destination',`moveChosenForce(${z.id})`,!movementReason(z)&&forceDraft.keys.length>0,true)}${btn('Why unavailable?',`explainSpaceAction(${z.id},'move')`)}<p>Heroic moves still require the selected leading Hero.</p>`}
function toggleFanPiece(key){if(!forceDraft)return;const i=forceDraft.keys.indexOf(key);if(i<0)forceDraft.keys.push(key);else forceDraft.keys.splice(i,1);haptic();renderForceFan()}
function moveChosenForce(id){if(movementReason(G.zones[id])||!forceDraft?.keys.length)return;closeAppPanel();closeSpacePopover();travelIntent={from:id,to:null,keys:[...forceDraft.keys]};userCommand(async p=>{try{await move(p,G.zones[id].type)}finally{travelIntent=null;movementContext=null}})}
document.body.insertAdjacentHTML('beforeend','<section id="space-popover" class="space-popover" hidden aria-label="Space actions"></section>');
function closeSpacePopover(){const el=$('space-popover');if(el)el.hidden=true}
function showSpacePopover(id,message=''){if(message)setPrompt(message)}
function recruitFromSpace(id){if(recruitReason(G.zones[id]))return explainSpaceAction(id,'recruit');closeSpacePopover();haptic('confirm');recruitAt(id)}
const touchZoneClick=onZoneClick;onZoneClick=function(id){const wasDragged=dragged,wasPending=!!R.pending;touchZoneClick(id);if(!wasDragged&&!wasPending&&!R.pending&&myAction()){haptic()}};
function screenBoardPoint(x,y){const r=mapEl.getBoundingClientRect(),s=Math.min(r.width/(560/viewZoom),r.height/(690/viewZoom));if(!(s>0))return null;return {x:viewX+(x-r.left-(r.width-560/viewZoom*s)/2)/s,y:viewY+(y-r.top-(r.height-690/viewZoom*s)/2)/s}}
function markDestinations(ids=[]){document.querySelectorAll?.('[data-zone]').forEach(el=>{const id=Number(el.dataset.zone),z=G.zones[id];el.classList.toggle('move-friendly',ids.includes(id)&&z?.owner===0);el.classList.toggle('move-empty',ids.includes(id)&&z?.owner===null);el.classList.toggle('move-enemy',ids.includes(id)&&z?.owner!==null&&z?.owner!==0)})}
function cancelForceDrag(){if(!forceDrag)return;forceDrag=null;markDestinations();$('drag-hint')?.remove?.();suppressMapClickUntil=Date.now()+400}
const controlTab=switchTab;switchTab=function(tab){closeSpacePopover();cancelForceDrag();if(cinematicMap&&tab!=='map'){cinematicMap=false;document.body.classList.remove('cinematic-map');$('cinematic-map-toggle')?.setAttribute('aria-pressed','false')}return controlTab(tab)};
// Route selection can skip redundant prompts, never the engine's legality check or force confirmation.
const usabilityAsk=ask;ask=function(pid,title,options,extra=''){
 if(human(pid)&&travelIntent){const source=/^(Choose the Sea Area to sail from|Choose a force to move)$/.test(title),dest=/^(Choose adjacent waters|Choose the destination)$/.test(title),id=source?travelIntent.from:dest?travelIntent.to:null;
  if(id!==null&&id!==undefined&&options.some(o=>o.value===id)){if(source)routeSource=id;if(dest)routeDestination=id;return Promise.resolve(id)}
 }
 const result=usabilityAsk(pid,title,options,extra);
 if(human(pid)&&R.pending&&title==='Choose the force to move'&&travelIntent?.keys&&movementContext){const draft=travelIntent.keys,z=G.zones[movementContext.from];$('force-t').value=draft.filter(k=>/^t\d+$/.test(k)).length;if(z.type==='land')$('force-m').value=draft.filter(k=>/^m\d+$/.test(k)).length;for(const h of z.heroes||[])if(!$('force-'+h.id).disabled)$('force-'+h.id).checked=draft.includes(h.id)}
 return result;
};
function movementCost(p,hero,free=false){return free?0:hero?(hero.id==='pericles'?1:(G.turnState.heroicMoves||0)+1):1}
const reviewedForce=selectForce;selectForce=async function(p,z,hero=null){if(!movementContext||movementContext.from!==z.id)movementContext={from:z.id,to:routeDestination,cost:movementCost(p,hero),hero:hero?.id};return reviewedForce(p,z,hero)};
function traceFleetRoute(from,to,enemy=false){
 const a=G.zones[from];if(!a)return[];if(a.adj.includes(to))return[from,to];const queue=[[from]],seen=new Set([from]);
 while(queue.length){const path=queue.shift(),z=G.zones[path.at(-1)];for(const id of z.adj){if(id===to)return[...path,id];const n=G.zones[id];if(n.type==='sea'&&n.fleets>0&&(enemy||n.owner===a.owner)&&!seasBlocked(n)&&!seen.has(id)){seen.add(id);queue.push([...path,id])}}}return [];
}
const usabilityMap=renderMapSVG;renderMapSVG=function(){usabilityMap();const opts=R.choiceMap?R.pending?.options||[]:[];markDestinations(opts.map(o=>o.zone).filter(id=>id!==undefined));

};
function showCreaturePresence(id){closeSpacePopover();showAppPanel('presence');const z=G.zones[id];$('app-panel-content').innerHTML=`<h3>${z.name} · Creature effects</h3>`+minis(z).map(m=>{const c=CREATURES.find(c=>c.id===m.id);return `<article class="building-detail"><img src="assets/figures/${m.id}.webp" alt="${c.name}"><div><h4>${c.name}</h4><p>${c.desc}</p><p>Controlled by ${G.players[m.owner].name}</p></div></article>`}).join('')}
function toggleCinematicMap(){cinematicMap=!cinematicMap;document.body.classList.toggle('cinematic-map',cinematicMap);if(cinematicMap)switchTab('map');$('cinematic-map-toggle').textContent=cinematicMap?'Show controls':'Cinematic map'}
document.querySelector('.map-tools')?.insertAdjacentHTML('beforeend','<button id="cinematic-map-toggle" class="cinematic-toggle" onclick="toggleCinematicMap()" aria-label="Toggle cinematic map">Cinematic map</button>');
function applyReadability(){if(document.documentElement?.style){document.documentElement.style.setProperty('--app-text',Math.max(.85,Math.min(1.4,APP.textSize)));document.documentElement.style.setProperty('--app-buttons',Math.max(1,Math.min(1.5,APP.buttonSize)));document.documentElement.style.setProperty('--map-labels',Math.max(.8,Math.min(1.5,APP.labelSize)))}}
const detailCamera=flushCamera;flushCamera=function(){detailCamera();applyReadability()};
const readableSettings=saveSettings;saveSettings=function(){readableSettings();applyReadability()};
const usabilityTools=showAppPanel;showAppPanel=function(tab='settings'){closeSpacePopover();usabilityTools(tab);if(tab==='settings')$('app-panel-content').insertAdjacentHTML('beforeend',`<h3>Comfort and controls</h3>${settingCheck('haptics','Selection / confirmation vibration')}${settingCheck('stereo','Positional stereo sound')}${[['textSize','Text size',.85,1.4],['buttonSize','Button size',1,1.5],['labelSize','Map label size',.8,1.5]].map(([key,label,min,max])=>`<label class="setting-row"><span>${label}</span><input type="range" aria-label="${label}" min="${min}" max="${max}" step=".05" value="${APP[key]}" oninput="APP.${key}=Number(this.value);saveSettings()"></label>`).join('')}`)};
const confirmedDecision=answerDecision;answerDecision=function(i){haptic('confirm');return confirmedDecision(i)};
applyReadability();

function setMovementContext(p,z,to,hero,free){routeSource=z.id;routeDestination=to;movementContext={from:z.id,to,cost:movementCost(p,hero,free),hero:hero?.id,free}}

mapEl.addEventListener('lostpointercapture',e=>{if(forceDrag?.pointer===e.pointerId)cancelForceDrag()},{capture:true});
globalThis.addEventListener?.('resize',cancelForceDrag);
document.addEventListener?.('visibilitychange',()=>{if(document.hidden)cancelForceDrag()});
let lastHapticTime=0;
const distinctHaptic=haptic;haptic=function(kind='select'){const now=Date.now();if(kind==='select'&&now-lastHapticTime<40)return;lastHapticTime=now;distinctHaptic(kind)};
const tactileSelection=selectionSound;selectionSound=function(kind='tap'){haptic(kind==='error'?'invalid':kind==='confirm'?'confirm':'select');return tactileSelection(kind)};

