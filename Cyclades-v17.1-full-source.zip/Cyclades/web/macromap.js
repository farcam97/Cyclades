// Ten reference-inspired macro faces. Six are selected; coast contours define actual land.
const MACRO_FACES=Array.from({length:10},(_,id)=>({id,art:id%6,split:id>=6&&id<=8,axis:id===2||id===9?'y':'x',flip:id%3===1}));
function pointIn(poly,x,y){let yes=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a[1]>y)!==(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])yes=!yes}return yes}
function clipPoly(poly,a,b,k){const out=[];poly.forEach((p,i)=>{const q=poly[(i+1)%poly.length],f=p[0]*a+p[1]*b-k,g=q[0]*a+q[1]*b-k;if(f<=1e-7)out.push(p);if((f<0)!==(g<0)){const t=f/(f-g);out.push([p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])])}});return out}
function polyPath(poly){return 'M'+poly.map(p=>p.map(n=>n.toFixed(2)).join(',')).join('L')+'Z'}
function segmentDistance(p,a,b){const x=b[0]-a[0],y=b[1]-a[1],t=Math.max(0,Math.min(1,((p[0]-a[0])*x+(p[1]-a[1])*y)/(x*x+y*y||1)));return Math.hypot(p[0]-a[0]-t*x,p[1]-a[1]-t*y)}
function innerPoint(poly){const xs=poly.map(p=>p[0]),ys=poly.map(p=>p[1]),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2;let best=[cx,cy],score=-1;for(let y=Math.min(...ys)+4;y<Math.max(...ys);y+=6)for(let x=Math.min(...xs)+4;x<Math.max(...xs);x+=6)if(pointIn(poly,x,y)){const d=Math.min(...poly.map((a,i)=>segmentDistance([x,y],a,poly[(i+1)%poly.length])))-Math.hypot(cx-x,cy-y)*.12;if(d>score){score=d;best=[x,y]}}return best}
function macroShape(art,x,y,w,h,flip,island,regions){const polygon=COASTS[art].map(([u,v])=>[x+(flip?1-u:u)*w,y+v*h]);return{art,artSet:"v6",x,y,w,h,flip,island,regions,polygon,path:polyPath(polygon)}}
makeRandomMap=function(){
 const tileCount=globalThis.campaignTileCount||6,rows=tileCount/2,faces=shuffle(MACRO_FACES).slice(0,tileCount),names=shuffle(['Delos','Naxos','Milos','Paros','Crete','Rhodes','Andros','Ios','Kos','Samos']),landsOut=[],shapes=[];
 faces.forEach((f,t)=>{const ox=t%2*280,oy=Math.floor(t/2)*230,ids=[t*2,t*2+1];let ps=[];
 if(f.split){for(let k=0;k<2;k++){const sh=macroShape((f.art+k*2)%6,ox+22+k*125,oy+40+(k===0?0:24),110,145,f.flip,t*2+k,[ids[k]]);shapes.push(sh);ps.push(sh.polygon)}}
 else{const sh=macroShape(f.art,ox+28,oy+30,224,175,f.flip,t*2,ids);shapes.push(sh);const a=f.axis==='x'?1:0,b=f.axis==='y'?1:0,k=f.axis==='x'?ox+140:oy+118;ps=[clipPoly(sh.polygon,a,b,k),clipPoly(sh.polygon,-a,-b,-k)]}
 ps.forEach((polygon,k)=>{const [x,y]=innerPoint(polygon);landsOut.push({id:ids[k],name:names[t]+' '+(f.split?(k?'Islet':'Shore'):f.axis==='x'?(k?'East':'West'):(k?'South':'North')),type:'land',island:f.split?t*2+k:t*2,tile:t,face:f.id,x,y,polygon,path:polyPath(polygon),adj:[],pros:1+(f.id===4&&k===0?1:0),priestIcon:(f.id+k)%3===0,capacity:1,coastSeed:f.id,artIndex:f.art})});
 });
 const points=[];for(let r=0;r<rows;r++)for(let c=0;c<3;c++)points.push([24+256*c,115+230*r]);for(let r=0;r<rows+1;r++)for(let c=0;c<2;c++)points.push([140+280*c,12+226*r]);
 const seas=points.map(([x,y],i)=>{let polygon=[[5,5],[555,5],[555,rows*230-5],[5,rows*230-5]];points.forEach(([u,v],j)=>{if(i!==j)polygon=clipPoly(polygon,2*(u-x),2*(v-y),u*u+v*v-x*x-y*y)});return {name:'Sea '+(i+1),type:'sea',id:tileCount*2+i,x,y,polygon,path:polyPath(polygon),adj:[],pros:(i+faces[i%tileCount].id)%2,priestIcon:false}});
 const out=[...landsOut,...seas],landAt=(x,y)=>landsOut.find(z=>pointIn(z.polygon,x,y)),connect=(a,b)=>{if(a===b)return;if(!out[a].adj.includes(b))out[a].adj.push(b);if(!out[b].adj.includes(a))out[b].adj.push(a)};
 for(let t=0;t<tileCount;t++)if(!faces[t].split)connect(t*2,t*2+1);
 for(const sh of shapes)for(let i=0;i<sh.polygon.length;i++){const a=sh.polygon[i],b=sh.polygon[(i+1)%sh.polygon.length];for(const f of [.25,.5,.75]){const p=[a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f];const land=sh.regions.map(id=>out[id]).find(z=>z.polygon.some((v,j)=>segmentDistance(p,v,z.polygon[(j+1)%z.polygon.length])<.15)),sea=seas.find(z=>pointIn(z.polygon,...p));if(land&&sea)connect(land.id,sea.id)}}
 for(let i=0;i<seas.length;i++)for(let j=i+1;j<seas.length;j++){const common=seas[i].polygon.filter(a=>seas[j].polygon.some(b=>Math.hypot(a[0]-b[0],a[1]-b[1])<.01));if(common.length<2)continue;const [a,b]=common;for(let k=1;k<20;k++){const x=a[0]+(b[0]-a[0])*k/20,y=a[1]+(b[1]-a[1])*k/20;if(!landAt(x,y)){connect(seas[i].id,seas[j].id);break}}}
 // Keep rendered ships clear of shores while retaining the exact sea-cell topology.
 for(const sea of seas){let best=[sea.x,sea.y],score=-Infinity;for(let dy=-40;dy<=40;dy+=20)for(let dx=-40;dx<=40;dx+=20){const x=sea.x+dx,y=sea.y+dy;if(x<29||x>531||y<29||y>rows*230-35||!pointIn(sea.polygon,x,y)||landAt(x,y))continue;const distance=Math.min(...shapes.flatMap(sh=>sh.polygon.map((a,i)=>segmentDistance([x,y],a,sh.polygon[(i+1)%sh.polygon.length])))),value=distance-Math.hypot(dx,dy)*.4;if(value>score){score=value;best=[x,y]}}[sea.x,sea.y]=best;}
 // Metadata is copied onto a zone so saves retain the exact map artwork and geometry.
 const sy=690/(rows*230);for(const z of out){z.y*=sy;z.polygon=z.polygon.map(([x,y])=>[x,y*sy]);z.path=polyPath(z.polygon)}for(const sh of shapes){sh.y*=sy;sh.h*=sy;sh.polygon=sh.polygon.map(([x,y])=>[x,y*sy]);sh.path=polyPath(sh.polygon)}out[0].macroShapes=shapes;out[0].macroFaces=faces.map(f=>f.id);return out;
};
function mapZoneAt(x,y){return G.zones.find(z=>z.type==='land'&&pointIn(z.polygon,x,y))||G.zones.find(z=>z.type==='sea'&&pointIn(z.polygon,x,y))}
