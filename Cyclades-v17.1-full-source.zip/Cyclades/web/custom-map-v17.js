// Three-player campaigns use the user's single continuous illustrated board.
// Existing campaigns and all other player counts retain their original geometry.
const mapBeforeCustom17=makeRandomMap;
function makeThreePlayerMap17(){const map=globalThis.CYCLADES_MAP_3P17,zones=JSON.parse(JSON.stringify(map.regions));Object.assign(zones[0],{customMap17:map.id,boardFrame:{...map.frame},macroShapes:JSON.parse(JSON.stringify(map.macroShapes)),macroFaces:[]});return zones}
makeRandomMap=function(){return setupConfig.count===3?makeThreePlayerMap17():mapBeforeCustom17()};
const mapHitBefore17=mapZoneAt;
mapZoneAt=function(x,y){return G.zones?.[0]?.customMap17?(G.zones.find(z=>z.type==='land'&&tileContainsV14(z,x,y))||G.zones.find(z=>z.type==='sea'&&tileContainsV14(z,x,y))):mapHitBefore17(x,y)};
const setupCustomBefore17=setupHTML;
setupHTML=function(){let html=setupCustomBefore17();if(setupConfig.count===3)html=html.replace(/<label>Map shape[\s\S]*?<\/label>/,'').replace(/<label>Tile selection[\s\S]*?<\/label>/,'').replace('6 tiles','Custom three-player board');return html};
