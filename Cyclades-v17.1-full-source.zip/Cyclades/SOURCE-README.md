# Cyclades: Legendary Edition — source export

This archive contains the published static game, artwork, sound assets, JavaScript engine and verification scripts. The browser executes the JavaScript directly: there is no bundler or compilation step.

## Run locally

With Python 3 installed, open a terminal in this folder and run:

    python3 -m http.server 8000 --directory dist

Open http://localhost:8000 in your browser. Serve over HTTP rather than opening index.html as a file so audio and browser storage work consistently.

The entry point is `dist/index.html`. Script order is significant. `rules.js` supplies the rule engine; `campaign-v11.js` adds configurable campaigns and teams; `streamlined-v12.js` owns the latest interface, bidding modes, camera following and incremental SVG updates. Older files contain presentation layers overridden by later files. `dist/assets` includes the complete artwork and sound collection.

## Verification

Requires Node.js. Run from this folder:

    node tests/rules-cases.cjs
    node tests/integration-v11.cjs
    node tests/streamlined-v12.cjs
    node tests/campaign-v11.cjs
    node tests/setup-v11.cjs
    node tests/ui-v11.cjs

These use a simulated DOM for engine and event-contract checks. They are not a browser rendering benchmark. Older historical test files may assert superseded interface behavior.

## Current limitations

The board still uses the adapted land shapes with the correct player-count tile totals. Exact printed ten-face geometry/site counts require readable source images. Hero figures match the app's current card portraits; unseen lower-body details are inferred. Android touch performance, sound and fullscreen still require real-device verification.

Saves and preferences reside in the browser; existing saves can be exported/imported in Settings → Campaign. This ZIP contains source and assets, not your private browser saves. The `.openai/hosting.json` file identifies the existing hosted Site; remove that identifier before registering an independent Site.

Version 13 adds the offline Android project in `android/`, economic charts, reserves, camera transforms, UI polish and the rule fixes documented in `POLISH-V13.md`. Entry point remains `dist/index.html`. Run `node tests/polish-v13.cjs` for the new regressions. See `android/build.sh` and `POLISH-V13.md` for Android build/signing requirements.
