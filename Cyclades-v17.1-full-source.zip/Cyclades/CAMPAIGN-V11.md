# Campaign v11

Implemented the requested subset of proposal items: 3, 5, 6, 8, 10, 14, 15, 17, 18, 19, 21, 22, 24, 27, 28 and 30. Reused and narrowed the prior local interaction work; omitted drag movement, added tutorials, recovery history and other unselected proposal features.

- Setup chooses 2–6 participants, faction roster, optional four-player teams, and each computer faction's Easy/Medium/Hard setting. Two-player uses four factions/two controllers; six-player uses three pairs. Teammates share a treasury, reserve each other's outstanding bids, combine economic building sets, cannot attack or stop on each other's regions, and win as teams. Shared-treasury accessors are restored on load/cancellation.
- Original 3-player adapted board now scales to 6/8/10 tiles for 3/4/5–6 players, eight for two-player. **Exact official tile art/topology is NOT implemented.** Original uploads and official publisher sources are too small to verify all ten faces. Setup and Chronicle disclose the adapted board. Higher-resolution tile scans are required before tracing sites/borders; image generation must never infer rules geometry.
- Easy selects varied legal options; Medium scores economy and opportunities; Hard prioritizes near-complete metropolis routes, military opportunities and spending reserves, and uses more legal paid actions. No AI reads another team's private treasury or future draws. Zeus's private peek is not exposed through opponent narration.
- Slower opponent decisions have captions and camera focus, with adjustable action pauses; battles preserve actual dice results and side colors.
- Separate Heroes/Creatures bottom destinations show the available markets in grids; powers are available on tap. Chronicle moved to Settings.
- Forced singleton building removals happen first; duplicate types require highlighted map choices.
- Building shading is color-mapped to white Metropolis, purple Temple, teal Port, red-orange Fortress and light-gray University with a moderate dark outline.
- All six faction identities have matching map, battle, picker and travel assets. Missing Snake, Ox and Fish were generated from miniature references using the built-in image tool, then cropped to transparent sprites. Their original atlas is not required at runtime.

Validation: 32 existing rules checks; complete simulated games at all five participant counts; 40 mixed-difficulty randomized setups; targeted team gold, reservations, allied attack, economic conversion, save/import, rendering purity, identity, two-faction control and UI handler checks. Static SVG map inspected. No supported browser-control skill is available in this environment, so browser/physical-phone layout, audio and gesture feel remain unverified.
