# Cyclades v16

This release updates the main build and preserves its game state format.

## Changes

- Explicit faction identity for turn highlights and narration; faction and chosen god shown together. Snake uses orange throughout.
- Numeric dice. Battle decisions stay on the battle screen; a brief faction winner emblem replaces the completion box.
- Conservative optional fast resolution (default on): strict strength advantage beyond all die results, no active creatures or battle heroes, normal rules still execute. Any meaningful human retreat/casualty choice pauses automatic presentation.
- Hero recruitment and construction identify the hero/building. Creature narration records chosen targets, exchanges and nested creature use; Dryad steals a Priestess, Satyr a Philosopher.
- Separate Charybdis whirlpool figure; 20 scenic Maelstrom card illustrations; 32 building-combination land battle scenes.
- Circular action art with readable plaques. Two-column roster wraps long names. Alphabetical reference shows excluded characters dimmed but readable.
- Consistent horizontal offering tokens, ordinary buildings 20% smaller, slightly transparent hero/mercenary bases, cached placement avoiding building/token locations. All unit layers draw above terrain, offerings, buildings and borders.
- One-finger pointer capture and two-finger pinch. Selected sea source is reused; single ships skip force choice. Map opens immediately after bidding.
- Red spending feedback follows the income visibility option. Priestess and Philosopher acquisition has distinct original sound/light effects.
- Performance mode removes decorative effects and camera tweening; unchanged board markup and placement are cached.
- Website, full source archive and signed offline Android APK provided together. Same Android application identity and signer as the earlier APK.

## Validation and limits

Tests cover engine/team/save regressions, 2–6 player Maelstrom campaigns, tall/wide geometry and dense placements in every region, gesture coordinate math, sea battles, selected-source movement, single-ship choice, inline battle decisions, conservative battle proof, reference asset paths and all 32 background masks. Image decoding and APK signature/package validation are separate final checks.

No browser automation or physical Android device is available here. These tests do not certify real-device frame rate, touch feel, or visual clipping. Finite map space can still create overlap with very large forces; numbered unit view remains available. Mid-action process termination restores the previous completed-action checkpoint. Puzzle-fitting tiles remain deferred.

## Build

The source archive includes all shipped assets, generated art masters, tests, audio generators and Android source. Run the Node scripts under tests for engine checks. android/build.sh requires Android build-tools/platform 35 and the existing signing materials supplied through environment variables; signing secrets are deliberately excluded from the source archive.
