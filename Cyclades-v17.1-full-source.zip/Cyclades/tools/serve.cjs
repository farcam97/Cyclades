const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..', process.env.CYCLADES_WEB_ROOT||'web');
const mime = {'.html':'text/html','.js':'text/javascript','.css':'text/css','.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.stl':'application/octet-stream','.svg':'image/svg+xml','.wav':'audio/wav','.json':'application/json','.webmanifest':'application/manifest+json'};
http.createServer((req,res)=>{
 let file;
 try { file=path.resolve(root, '.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname)); } catch {res.writeHead(400).end();return;}
 if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
 if(file===root)file=path.join(root,'index.html');
 fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end();return;}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff'}).end(data);});
}).listen(Number(process.env.CYCLADES_PORT)||4173,'127.0.0.1');
