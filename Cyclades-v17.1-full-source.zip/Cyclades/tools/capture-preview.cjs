const{chromium}=require('playwright');
(async()=>{const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 const p=await b.newPage({viewport:{width:390,height:844}});await p.goto('http://127.0.0.1:4174');await p.waitForTimeout(4700);await p.screenshot({path:'artifacts/intro-cinematic-v16.2.png'});
 await p.evaluate(()=>{skipIntro();APP.sound=false;APP.motion=false;APP.cinematics=false;APP.performanceMode=true;updatePreference('darkTheme',true);setupConfig.spectator=true;startConfiguredGame();R.auto=true});
 await p.waitForFunction(()=>G.phase==='OFFERINGS'&&!R.busy);
 await p.evaluate(()=>{timers.forEach(clearTimeout);timers.clear();R.auto=false;G.config.spectator=false;G.players[0].controller=0;G.activeBidder=0;document.getElementById('welcome').hidden=true;document.body.classList.remove('title-active');switchTab('map');renderAll();setPrompt('Make your offering.');});
 await p.screenshot({path:'artifacts/phone-map-v16.2.png'});
 await p.evaluate(()=>showAppPanel('settings'));await p.screenshot({path:'artifacts/phone-settings-v16.2.png'});await b.close();
})().catch(e=>{console.error(e);process.exitCode=1});
