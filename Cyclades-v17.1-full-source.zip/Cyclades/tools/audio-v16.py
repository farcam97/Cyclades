"""Original short achievement motifs, generated deterministically."""
from pathlib import Path
import math,struct,wave
out=Path(__file__).resolve().parents[1]/'dist/assets/audio';rate=22050
for name,notes,duration,spacing in [('priestess-holy',[523.25,659.25,783.99,1046.5],1.45,.11),('philosopher-insight',[392,493.88,587.33,783.99],.9,.14)]:
 samples=[]
 for i in range(int(rate*duration)):
  t=i/rate;v=0
  for j,f in enumerate(notes):
   u=t-j*spacing
   if u>=0:v+=(math.sin(2*math.pi*f*u)+.18*math.sin(2*math.pi*f*2.003*u))*min(1,u/.025)*math.exp(-u*(2.7 if name=='priestess-holy' else 6))*.23
  samples.append(v*min(1,(duration-t)*6))
 with wave.open(str(out/(name+'.wav')),'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(b''.join(struct.pack('<h',int(max(-1,min(1,x))*24000)) for x in samples))
