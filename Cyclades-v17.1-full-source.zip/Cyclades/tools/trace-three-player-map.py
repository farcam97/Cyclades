#!/usr/bin/env python3
"""Regenerate the three-player board geometry from its supplied artwork.
Optional authoring dependencies: numpy, scipy, opencv-python-headless.
The app and Android build use the generated data and do not run this script.
"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
(ROOT/'artifacts/map-tracing').mkdir(parents=True,exist_ok=True)
(ROOT/'tools/map-data').mkdir(parents=True,exist_ok=True)
import sys,json
import cv2,numpy as np
from scipy import ndimage as nd
im=cv2.imread(str(ROOT/'web/assets/v17/map-three-player.jpg'));rgb=im[:,:,::-1].astype(float);r,g,b=rgb.transpose(2,0,1)
land=((r>b*.93)&(g>b*.75))|((g>b*1.04)&(r>b*.45))|((r>b*.8)&(g>b*.87)&(r>65))
land=nd.binary_closing(land,iterations=3);land=nd.binary_fill_holes(land)
land=nd.binary_opening(land,iterations=2)
land[240:688,:20]=True
labels,n=nd.label(land);sizes=np.bincount(labels.ravel());land=np.isin(labels,np.where(sizes>1900)[0][1:])
# Preserve the inland borders visible in the supplied image.
rivers=[[(475,50),(493,75),(491,104),(497,128),(502,151),(510,174),(515,198),(518,220)],[(345,615),(335,632),(329,651),(329,676),(309,687),(286,697),(260,710)],[(329,676),(342,701),(364,687),(381,697),(397,717),(420,727),(445,744)],[(220,748),(237,765),(245,783),(265,798),(288,807),(318,813)],[(800,767),(833,767),(856,776),(882,778),(909,770),(938,762),(972,767),(1003,761),(1046,755),(1085,753)],[(438,995),(468,1001),(490,1016),(503,1043),(516,1067),(535,1082),(558,1092),(581,1108),(600,1125),(618,1125),(639,1113),(653,1111),(664,1118),(690,1130)]]
for pts in rivers:
 cv2.polylines(land.view(np.uint8),[np.array(pts)],False,0,5)
labels,n=nd.label(land);sizes=np.bincount(labels.ravel());regions=[]
out=im.copy()
for k in range(1,n+1):
 if sizes[k]<1900:continue
 mask=(labels==k).astype('uint8');cnt=max(cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[0],key=cv2.contourArea);poly=cv2.approxPolyDP(cnt,1.3,True).reshape(-1,2)
 dist=nd.distance_transform_edt(mask);y,x=np.unravel_index(np.argmax(dist),dist.shape)
 regions.append({'key':k,'center':[int(x),int(y)],'area':int(sizes[k]),'polygon':poly.tolist()})
 cv2.polylines(out,[poly],True,(255,0,255),2);cv2.putText(out,str(len(regions)-1),(x,y),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,0),4);cv2.putText(out,str(len(regions)-1),(x,y),cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),2)
print([(i,v['center'],v['area'])for i,v in enumerate(regions)])
cv2.imwrite(str(ROOT/'artifacts/map-land-trace.png'),out)
np.save(str(ROOT/'artifacts/map-tracing/land-labels.npy'),labels);json.dump(regions,open(str(ROOT/'artifacts/map-tracing/land-regions.json'),'w'))
physical=nd.binary_fill_holes(land.copy())
# Close the narrow land district dividers for the sea topology only.
for pts in rivers:cv2.polylines(physical.view(np.uint8),[np.array(pts)],False,1,7)
# Keep restored dividers within their actual island footprint.
original=((r>b*.93)&(g>b*.75))|((g>b*1.04)&(r>b*.45))|((r>b*.8)&(g>b*.87)&(r>65));original=nd.binary_fill_holes(nd.binary_closing(original,iterations=3));original=nd.binary_opening(original,iterations=2);original[240:688,:20]=True
labs,num=nd.label(original);sz=np.bincount(labs.ravel());physical=np.isin(labs,np.where(sz>1900)[0][1:])
river_mask=np.zeros(physical.shape,np.uint8)
for pts in rivers:cv2.polylines(river_mask,[np.array(pts)],False,1,9)
physical|=(river_mask>0)&(nd.distance_transform_edt(~physical)<7)
physical[:3]=physical[3];physical[-4:]=physical[-5];physical[:,:3]=physical[:,3,None];physical[:,-4:]=physical[:,-5,None]
foam=[
 [(0,166),(49,200),(100,207),(145,194),(173,202),(200,194),(223,205),(250,218),(284,219),(314,215),(342,229),(380,213)],
 [(250,218),(275,238),(303,245),(319,261),(326,286),(346,298),(381,297),(405,316),(432,341),(448,365),(457,389)],
 [(457,389),(437,404),(423,397),(409,393),(389,365),(378,341),(365,330),(350,333),(331,346),(321,371),(317,401),(334,443),(344,478),(368,486),(394,469),(410,444),(435,417),(457,389)],
 [(457,389),(485,420),(513,428),(535,442),(556,448),(568,469),(583,498)],
 [(488,337),(508,303),(523,304),(550,312),(562,316),(581,305),(603,310),(630,343)],
 [(630,343),(649,330),(666,322),(687,321),(706,309),(737,333)],
 [(737,333),(766,316),(787,300),(802,283),(817,259),(824,237),(847,221),(880,212),(911,210),(946,198),(972,190),(1004,171),(1046,148),(1097,120)],
 [(630,343),(633,371),(632,389),(620,404),(611,428),(610,452),(601,481),(583,498)],
 [(737,333),(727,355),(720,381),(706,403),(701,427),(693,447),(695,476),(702,506),(717,534),(733,558)],
 [(583,498),(600,512),(609,530),(620,558)],
 [(620,691),(634,730),(638,770)],
 [(638,770),(625,786),(610,789),(596,802)],
 [(638,770),(647,797),(667,788),(687,803),(703,815)],
 [(596,802),(580,787),(569,767),(550,756),(531,764),(516,760),(500,749),(465,725)],
 [(596,802),(616,826),(624,852),(627,887),(636,923),(649,963),(651,991)],
 [(607,997),(651,991),(671,987),(686,981),(713,975)],
 [(883,847),(872,870),(863,883),(859,904),(851,926),(849,946),(840,959),(830,973),(824,980)],
 [(996,450),(983,478),(968,497),(955,510),(934,519),(929,542),(924,568),(913,587),(911,610)],
 [(850,519),(847,555),(840,580),(827,605),(812,630),(796,651)],
 [(106,681),(99,710),(101,742),(103,780),(117,806),(125,835),(151,868)],
 [(218,960),(207,980),(189,1008),(171,1035),(155,1054),(126,1091),(105,1119),(71,1142),(37,1163),(0,1176)],
 [(315,898),(347,881),(367,858),(395,850),(416,833),(444,824),(466,811)]
]
sea=~physical
for pts in foam:cv2.polylines(sea.view(np.uint8),[np.array(pts)],False,0,4)
sl,n=nd.label(sea)
# Forest patches clipped by the image frame are land, not enclosed sea zones.
for k in range(1,n+1):
 mask=sl==k
 if mask.sum()>1500:
  mean=rgb[mask].mean(axis=0)
  if mean[1]>mean[2]*1.08 or mean[0]>mean[2]*.82:physical[mask]=True
sea=~physical
for pts in foam:cv2.polylines(sea.view(np.uint8),[np.array(pts)],False,0,4)
sl,n=nd.label(sea);ss=np.bincount(sl.ravel());keep=[k for k in range(1,n+1)if ss[k]>1500]
# Fill divider strokes from the nearest playable zone, retaining strict boundaries.
landlabels=np.zeros(land.shape,np.int32)
for i,reg in enumerate(regions):landlabels[labels==reg['key']]=i+1
inds=nd.distance_transform_edt(landlabels==0,return_distances=False,return_indices=True);landlabels=np.where(physical,landlabels[tuple(inds)],0)
sealabels=np.zeros(land.shape,np.int32)
for i,k in enumerate(keep):sealabels[sl==k]=len(regions)+i+1
inds=nd.distance_transform_edt(sealabels==0,return_distances=False,return_indices=True);sealabels=np.where(~physical,sealabels[tuple(inds)],0)
full=landlabels+sealabels;allregions=[];out=im.copy()
for k in range(1,len(regions)+len(keep)+1):
 mask=(full==k).astype('uint8');cnts,h=cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE);outer=max((i for i,v in enumerate(h[0])if v[3]<0),key=lambda i:cv2.contourArea(cnts[i]));poly=cv2.approxPolyDP(cnts[outer],1.7,True).reshape(-1,2);holes=[cv2.approxPolyDP(cnts[i],1.7,True).reshape(-1,2).tolist()for i,v in enumerate(h[0])if v[3]==outer and cv2.contourArea(cnts[i])>100];dist=nd.distance_transform_edt(np.pad(mask,1))[1:-1,1:-1];y,x=np.unravel_index(np.argmax(dist),dist.shape)
 allregions.append({'id':k-1,'type':'land'if k<=len(regions)else'sea','center':[int(x),int(y)],'polygon':poly.tolist(),'holes':holes,'area':int(mask.sum())})
 color=(255,0,255)if k<=len(regions)else(20,255,255);cv2.polylines(out,[poly],True,color,1);cv2.putText(out,str(k-1),(x,y),cv2.FONT_HERSHEY_SIMPLEX,.8,(0,0,0),4);cv2.putText(out,str(k-1),(x,y),cv2.FONT_HERSHEY_SIMPLEX,.8,(255,255,255),2)
print('LAND',len(regions),'SEA',len(keep),'TOTAL',len(allregions));print([(reg['id'],reg['center'],reg['area'])for reg in allregions])
cv2.imwrite(str(ROOT/'artifacts/map-topology-trace.png'),out);json.dump(allregions,open(str(ROOT/'artifacts/map-tracing/all-map-regions.json'),'w'));np.save(str(ROOT/'artifacts/map-tracing/map-zones.npy'),full)

json.dump({'rivers':rivers,'foam':foam},open(str(ROOT/'artifacts/map-tracing/map-divider-lines.json'),'w'))
import json,numpy as np,hashlib
from pathlib import Path
root=ROOT;regions=json.load(open(str(ROOT/'artifacts/map-tracing/all-map-regions.json')));labels=np.load(str(ROOT/'artifacts/map-tracing/map-zones.npy'));scale=560/1097
points=lambda p:[round(p[0]*scale,3),round(p[1]*scale,3)]
pointobj=lambda p:dict(zip(['x','y'],points(p)))
sites={0:[(563,177)],1:[(408,149),(409,249),(479,254)],2:[(940,312)],3:[(7,261),(213,451),(147,654)],4:[(477,519),(388,624)],5:[],6:[],7:[(857,669),(975,624),(1029,735)],8:[(308,709)],9:[(188,831),(295,879),(203,947)],10:[(855,846)],11:[(507,818),(467,954),(630,1046)],12:[(1017,1049)],13:[(386,1198),(599,1203)]}
resources=[(553,92,1),(991,430,1),(63,606,1),(458,679,1),(393,777,1),(934,820,1),(478,1177,1),(886,1153,1),(48,1050,1),(169,1195,1),(352,384,2),(601,633,2)]
churches=[(474,153),(961,691),(569,1025)]
names=['Northern Cape','Northern Sanctuary','Eastern Cape','Western Reach','Central Heights','Offering Isle','Spine Isle','Eastern Fields','Central Fields','Western Farms','Southern Shore','Southern Sanctuary','Volcanic Cape','Southern Mountains']
islands=[0,0,1,2,2,3,4,5,2,2,5,6,7,6]
# Count actual shared edges: a meeting at a corner is not a connection.
adj={};
for a,b in [(labels[:,:-1],labels[:,1:]),(labels[:-1,:],labels[1:,:])]:
 mask=a!=b
 pairs=np.sort(np.stack([a[mask],b[mask]],1),axis=1)
 keys,counts=np.unique(pairs,axis=0,return_counts=True)
 for (x,y),n in zip(keys,counts):adj[(int(x)-1,int(y)-1)]=adj.get((int(x)-1,int(y)-1),0)+int(n)
# Same-type adjacency must follow a drawn divider; corner-only contact never
# creates a move. Coastal land-to-sea contacts come from the traced coastline.
adj={key:n for key,n in adj.items()if (key[0]<14)!=(key[1]<14)}
lines=json.load(open(str(ROOT/'artifacts/map-tracing/map-divider-lines.json')))
for kind in ['rivers','foam']:
 for line in lines[kind]:
  for a,b in zip(line,line[1:]):
   dx=b[0]-a[0];dy=b[1]-a[1];length=float(np.hypot(dx,dy))
   if not length:continue
   for u in np.linspace(.2,.8,max(3,int(length/5))):
    x=a[0]+dx*u;y=a[1]+dy*u;nx=-dy/length*6;ny=dx/length*6
    pos=[(int(round(y+ny)),int(round(x+nx))),(int(round(y-ny)),int(round(x-nx)))]
    if any(not(0<=v<1280 and 0<=w<1097)for v,w in pos):continue
    pair=sorted(int(labels[v,w])-1 for v,w in pos)
    if pair[0]==pair[1]or kind=='foam'and pair[0]<14 or kind=='rivers'and pair[1]>=14:continue
    key=tuple(pair);adj[key]=max(25,adj.get(key,0))
for reg in regions:
 i=reg['id'];poly=[points(p)for p in reg['polygon']];holes=[[points(p)for p in h]for h in reg['holes']];center=points(reg['center']);ps=[(*p,reg['id'])for p in sites.get(i,[])]
 for x,y,_ in ps:
  if labels[y,x]-1!=i:print('SITE OUTSIDE',i,x,y,'belongs',labels[y,x]-1)
 reg.clear();reg.update({'id':i,'name':names[i]if i<14 else 'Sea '+str(i-13),'type':'land'if i<14 else'sea','x':center[0],'y':center[1],'polygon':poly,'holes':holes,'path':' '.join('M'+' L'.join(f'{x},{y}'for x,y in p)+' Z'for p in [poly,*holes]),'adj':sorted(b if a==i else a for (a,b),n in adj.items()if n>=20 and i in (a,b)),'island':islands[i]if i<14 else None,'tileArtV14':True,'pros':0,'printedPros':0,'priestIcon':False,'capacity':len(ps),'buildingSites':[pointobj(p[:2])for p in ps],'printedHorns':[]})
for x,y,n in resources:
 i=int(labels[y,x])-1;reg=regions[i];reg['pros']+=n;reg['printedPros']+=n;reg['printedHorns'].append({**pointobj((x,y)),'n':n});print('RESOURCE',x,y,n,'zone',i)
for x,y in churches:
 i=int(labels[y,x])-1;regions[i]['priestIcon']=True;regions[i]['churchSite']=pointobj((x,y));print('CHURCH',x,y,'zone',i)
frame={'width':560,'height':round(1280*scale,3)};groups=[]
for island in range(8):
 members=[r for r in regions if r['island']==island];groups.append({'path':' '.join(r['path']for r in members),'polygon':members[0]['polygon'],'regions':[r['id']for r in members],'island':island})
meta={'id':'three-player-v1','sourceSha256':hashlib.sha256((root/'web/assets/v17/map-three-player.jpg').read_bytes()).hexdigest(),'frame':frame,'macroShapes':groups,'regions':regions}
(root/'tools/map-data/three-player-map.json').write_text(json.dumps(meta,indent=2)+'\n')
(root/'web/map-three-player-data-v17.js').write_text('// Traced from the user-supplied three-player board. Generated static geometry.\nglobalThis.CYCLADES_MAP_3P17='+json.dumps(meta,separators=(',',':'))+';\n'+'''function validateCustomMapGeometry17(state){
 const map=globalThis.CYCLADES_MAP_3P17;
 if(state.players.length!==3||state.zones[0].customMap17!==map.id||state.zones.length!==map.regions.length||state.zones[0].tileLayoutV14)throw Error('Invalid three-player board.');
 const fields=['id','name','type','x','y','polygon','holes','path','adj','island','capacity','buildingSites','printedPros','printedHorns','priestIcon','churchSite'];
 for(let i=0;i<map.regions.length;i++)for(const key of fields)if(JSON.stringify(state.zones[i][key])!==JSON.stringify(map.regions[i][key]))throw Error('Three-player board geometry does not match the supplied map.');
 if(JSON.stringify(state.zones[0].boardFrame)!==JSON.stringify(map.frame)||JSON.stringify(state.zones[0].macroShapes)!==JSON.stringify(map.macroShapes))throw Error('Invalid three-player board frame.');
}
''')
print('map',len(regions),'vertices',max(len(r['polygon'])for r in regions),'sites',sum(r['capacity']for r in regions),'offerings',sum(r['pros']for r in regions))
print('adjacency',[(r['id'],r['adj'])for r in regions])
