const {chromium}=require('playwright');const fs=require('node:fs');
const median=xs=>{const a=[...xs].sort((a,b)=>a-b);return a[Math.floor(a.length/2)]};
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 const samples={original:[],updated:[]};
 // Alternate versions to reduce systematic ordering effects; every navigation gets a fresh context/cache.
 for(let run=0;run<9;run++)for(const name of run%2?['updated','original']:['original','updated']){
  const context=await browser.newContext({viewport:{width:390,height:844},reducedMotion:'reduce'});
  await context.addInitScript(()=>{let seed=934847;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)|0;return (seed>>>0)/4294967296};try{localStorage.setItem('cyclades-settings-v5',JSON.stringify({sound:false,motion:false,cinematics:false}))}catch{}});
  const page=await context.newPage();await page.goto(name==='original'?'http://127.0.0.1:4175':'http://127.0.0.1:4174');
  const navigation=await page.evaluate(()=>{const n=performance.getEntriesByType('navigation')[0];return {domReadyMs:n.domContentLoadedEventEnd,loadMs:n.loadEventEnd}});
  await page.evaluate(()=>{skipIntro();startConfiguredGame();R.epoch++;timers.forEach(clearTimeout);timers.clear();R.pending=null;R.busy=false;B=null;G.phase='ACTIONS';G.activeBidder=0;G.actionOrder=[0,1,2];G.activePlayerIdx=0;G.players[0].god='ARES';APP.sound=false;APP.motion=false;APP.cinematics=false;document.getElementById('welcome').hidden=true;document.body.classList.remove('title-active');switchTab('map');renderAll()});
  await page.waitForTimeout(100);
  const timing=await page.evaluate(()=>{
   // CPU-only measurements; paints are deliberately not presented as frame-rate measurements.
   const measure=fn=>{const start=performance.now();fn();return performance.now()-start};
   const unchangedMapMs=measure(()=>{for(let i=0;i<500;i++)renderMapSVG()});
   const changedMapMs=measure(()=>{const z=G.zones.find(z=>z.type==='land');for(let i=0;i<60;i++){z.pros=1+i%3;renderMapSVG()}});
   const updatedHudMs=measure(()=>{for(let i=0;i<60;i++){G.players[0].gp=20+i;renderAll()}});
   return {unchangedMapMs,changedMapMs,updatedHudMs};
  });
  if(run>=2)samples[name].push({...navigation,...timing});await context.close();
 }
 const medians=Object.fromEntries(Object.entries(samples).map(([name,runs])=>[name,Object.fromEntries(Object.keys(runs[0]).map(k=>[k,Number(median(runs.map(x=>x[k])).toFixed(2))]))]));
 const result={environment:'Headless system Chromium on this cloud machine; 390x844 viewport; seven measured runs/version after two warmups; fresh browser cache per run; fixed random seed; reduced motion and sound disabled.',limitations:'Local HTTP and CPU microbenchmarks; not Android/WebView, FPS, GPU, battery, device startup or network-download measurements. Navigation figures include scheduler and local-server variability. No external performance claim is implied.',medians,samples};
 fs.writeFileSync('artifacts/performance-comparison.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(medians,null,2));await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1});
