"""Install pinned Android SDK packages using Google's published archive checksums."""
from pathlib import Path
import hashlib, os, urllib.request, zipfile, shutil
sdk = Path(os.environ.get('ANDROID_SDK_ROOT', '/workspace/.tools/android-sdk')).resolve()
sdk.mkdir(parents=True, exist_ok=True)
packages = [
 ('platform-35_r02.zip', '0bb560a90a7a2cbd0dd8348224d518b638fe7949', 'platforms', 'android-35', 'android-35'),
 ('build-tools_r35_linux.zip', '2cfaa0bbb2336e9ec18ed3ecea84fa2e2af607bc', 'build-tools', 'android-15', '35.0.0'),
]
for archive, expected, group, prefix, target in packages:
    download = sdk / archive
    if not download.exists():
        temporary = download.with_suffix('.download')
        urllib.request.urlretrieve('https://dl.google.com/android/repository/' + archive, temporary)
        temporary.rename(download)
    # SHA-1 is the checksum algorithm supplied in Google's HTTPS SDK repository metadata.
    if hashlib.sha1(download.read_bytes()).hexdigest() != expected:
        raise SystemExit('Archive checksum mismatch: ' + archive)
    destination = sdk / group / target
    if destination.exists():
        print('Verified archive; package already present:', destination)
        continue
    destination.mkdir(parents=True)
    with zipfile.ZipFile(download) as bundle:
        for member in bundle.infolist():
            relative = Path(member.filename).relative_to(prefix)
            output = destination / relative
            if not output.resolve().is_relative_to(destination.resolve()):
                raise SystemExit('Unsafe SDK archive path')
            if member.is_dir():
                output.mkdir(parents=True, exist_ok=True)
            else:
                output.parent.mkdir(parents=True, exist_ok=True)
                with bundle.open(member) as source, output.open('wb') as sink:
                    shutil.copyfileobj(source, sink)
                mode = (member.external_attr >> 16) & 0o777
                if mode:
                    output.chmod(mode)
    print('Installed verified package:', destination)
