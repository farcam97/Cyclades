"""Deterministic original synthesized Foley; no sampled copyrighted recordings."""
from pathlib import Path
import math, struct, wave, random
out=Path(__file__).resolve().parents[1]/'dist/assets/audio'
rate=22050
heroes=['ajax','helen','odysseus','croesus','hector','penthesilea','pandora','perseus','jason','achilles','antigone','heracles','hippolyta','leto','penelope','pericles']
def save(name,samples):
 peak=max(1,max(abs(x) for x in samples));data=b''.join(struct.pack('<h',int(max(-1,min(1,x/peak)) *24000)) for x in samples)
 with wave.open(str(out/(name+'.wav')),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(data)
rng=random.Random(15)
samples=[]
for i in range(int(rate*.48)):
 t=i/rate;env=min(1,t/.025)*math.exp(-t*7)*(1-min(1,max(0,(t-.35)/.13)))
 # Voiced military exertion: falling fundamental, two formant-like harmonics and breath.
 phase=2*math.pi*(120*t-42*t*t)
 value=(math.sin(phase)+.5*math.sin(phase*5)+.25*math.sin(phase*9)+rng.uniform(-.15,.15))*env
 samples.append(value)
save('recruit-grunt',samples)
for j,name in enumerate(heroes):
 samples=[];notes=[1,1.25+(j%3)*.08,1.5+(j%4)*.06];base=180+j*19
 for i in range(int(rate*.95)):
  t=i/rate;v=0
  for k,n in enumerate(notes):
   u=t-k*(.12+(j%3)*.025)
   if u>=0:
    e=min(1,u/.015)*math.exp(-u*(5+j%4));f=base*n;v+=e*(math.sin(2*math.pi*f*u)+(.1+j%5*.07)*math.sin(2*math.pi*f*2*u))*.5
  samples.append(v)
 save('hero-'+name,samples)
samples=[]
for i in range(int(rate*5.5)):
 t=i/rate;v=0
 for k,f in enumerate([146.83,174.61,220,293.66,349.23,440]):
  u=t-k*.6
  if u>=0:v+=(math.sin(2*math.pi*f*u)+.18*math.sin(2*math.pi*f*3*u))*min(1,u/.09)*math.exp(-u*1.1)*.24
 samples.append(v*min(1,max(0,5.5-t)))
save('intro-theme',samples)
print('Created grunt, 16 distinct hero cues, and original intro theme')
