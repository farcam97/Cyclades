const {spawnSync}=require('node:child_process');
const fs=require('node:fs');
const tests=['features-v16.cjs','rules-cases.cjs','targeted-v16.cjs','interaction-v16.cjs','integration-v16.cjs','campaign-v16.cjs','expansion-campaign-v16.cjs','board-reconciliation-v14.cjs','performance-tests.cjs'];
const results=[];
for(const file of tests){const r=spawnSync(process.execPath,['tests/'+file],{encoding:'utf8',timeout:120000});fs.mkdirSync('artifacts/original-tests',{recursive:true});fs.writeFileSync('artifacts/original-tests/'+file+'.log',r.stdout+'\n'+r.stderr);results.push({test:file,exitCode:r.status,error:r.error?.message});console.log(file,r.status===0?'PASS':'FAIL');}
fs.writeFileSync('artifacts/original-tests/summary.json',JSON.stringify(results,null,2)+'\n');process.exitCode=results.some(r=>r.exitCode!==0)?1:0;
