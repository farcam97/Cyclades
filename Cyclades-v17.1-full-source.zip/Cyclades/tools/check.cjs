const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'../web');
for(const f of fs.readdirSync(root))if(f.endsWith('.js'))new vm.Script(fs.readFileSync(path.join(root,f),'utf8'),{filename:f});
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');for(const m of html.matchAll(/(?:src|href)="([^"?#]+)(?:[^\"]*)"/g)){if(!fs.existsSync(path.join(root,m[1])))throw Error('Missing entry asset: '+m[1])}
console.log('All JavaScript parses; entry-page assets exist.');
