# Version 13

Implemented proposal 17 (end-game economic charts) and 21 (public reserves), plus the requested HUD, camera, recruitment, market, faction, effects, and rule-flow changes.

## Rules review
Reviewed all 18 Creatures and 9 Heroes against the supplied English manual. Corrected Apollo defensive Hero powers, individual Temple usage and replacement tracking, Metropolis free-site priority, protection-Hero choice, and Perseus sacrifice eligibility. Automatic discounts consume only discounts needed for a purchase. Fourth-building placement is skipped when a free site legally exists; the full-site replacement decision remains mandatory. Polyphemus movement was correct; displacement/destruction now has visible feedback.

The manual does not explicitly settle Hector/Pandora ordering, Croesus/Helen, or conflicting tie powers. Existing deterministic resolutions remain interpretations. Mercenary artwork follows the verified gray/double-axe cues; the supplied references do not establish an exact sculpt. Exact printed tile-face reconstruction still needs readable scans.

## Performance
Camera coordinates remain fixed; a single existing SVG group receives pan/zoom transforms. The board retains unchanged nodes and images. Removed ambient wave animation and made figure scale uniform. Card thumbnails use 360px WebP and stable market markup. CPU choices no longer narrate imperative decision dialogs; completed actions have paced, concise text. A skip control bypasses subsequent CPU presentation while preserving resolution.

## Validation
Completed full automated games for 2, 3, 4, 5, and 6 players; 40 randomized setup checks; 32 existing targeted rule cases; 8 new v13 cases; save/team integration; UI handler checks; actual generated SVG node identity tests; three camera/cache stress runs. Static board image assets resolve and render. APK signature and packaging verified. Browser GPU performance, touch/fullscreen layout, and Android device behavior require real-device testing; no emulator or browser runtime was available in this workspace. The missing-image attachment was not present, so its specific reproduction remains unverified.

## Android
Offline WebView package, Android 8/API26 minimum, target API35. Includes local save storage, JSON import/export through Android's document picker, fullscreen handling, and bundled artwork/audio. Website and APK saves are separate: export/import to transfer.

Build with Java17 JDK, Android platform35/build-tools35.0.0. Set ANDROID_SDK_ROOT, CYCLADES_KEYSTORE, CYCLADES_KEY_PASSWORD, then run android/build.sh. This delivery is signed with a test key. Production release/update signing should use your own retained key. Installing a build signed with another key requires uninstalling the previous app; export saves first.
