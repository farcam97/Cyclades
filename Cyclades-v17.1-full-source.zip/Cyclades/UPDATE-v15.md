# Cyclades 15 — presentation and interaction update

Updates the existing main build. The separate puzzle tile prototype and NES version are untouched.

## Implemented

- Single pointer handler, anchored pinch/wheel zoom, 1×–3.5× limits, stable SVG scene, gesture click suppression, explicit wide/tall coordinate frame and resize cancellation.
- Selection fills remain translucent without animations; frontier paths explicitly have no fill.
- Wider temporary map layout, player-count tile quantities, retained per-art building capacities and symmetric adjacency. Puzzle-fitting remains deferred.
- Compact setup with Maelstrom first, roster selection, faction/difficulty controls, fine/exponential bidding, and all-computer games. Setup navigation excludes Reference/Campaign.
- Spectator pause/resume, next narrated action, speed controls, optional AI intent summaries; actual Poseidon naval and Ares land attack planning.
- Compact tap-away character powers, including military/sacrificial abilities. Movement/recruit actions use matching icons and prices; unavailable actions explain why.
- New round faction art, exact supplied temple app icon and End turn art, matching action icons, offering artwork, and three land/one ocean battlefield illustrations.
- Full-body Maelstrom figures based on the existing character artwork, reused in borderless shop card illustrations with engine-generated power text. Each expansion character has a distinct motion/motif.
- Correct actor/faction references for recruitment, movement, combat, effects and income. Income floats attach to the current faction's actual HUD position.
- Troop recruitment arrival/grunt, 16 individual hero sound cues, offering drop/coin effects, creature target camera and paced public effect explanation, turn emblems and faction-tinted larger captions.
- Grouped Boar troop/mercenary displacement. Normal troops/ships no longer have round bases; special figures retain them.
- Separate hero/creature/intro/interface/combat sound controls, explicit reduced motion, skippable original gods-and-war intro, title New game/Continue controls.
- Safe action checkpoints for spectators as well as human games; live pending choices survive backgrounding. Human placement confirmation retains its Back control before commitment.

## Verification

Three focused passes: engine/regression campaigns; targeted geometry, gesture and battle/interaction checks; artwork/asset and source validation. Scripts are in tests/*v15.cjs. Generated artwork has individual prompt provenance under the asset documentation.

No browser automation capability or physical Android device is available in this environment. DOM-contract/coordinate tests cannot prove GPU frame rate, real touch behavior or screen clipping. A device run remains necessary.

## Explicit limits

If the browser/OS kills the process during an unfinished action, loading returns to the previous safe completed-action checkpoint. Live JavaScript promises are not serialized. Backgrounding without process termination retains the pending choice.

The printed offering symbols are covered by new opaque-backed token overlays; underlying source tile artwork remains intact. Building-site counts are unchanged.

The military grunt, hero cues and intro music are original synthesized audio, not recorded voice performances. Art masters are retained separately from compact shipped assets.
