#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-/workspace/.tools/android-sdk}"
python3 tools/setup-android.py
npm run build
key_dir="${CYCLADES_PREVIEW_KEY_DIR:-/workspace/.keys}"
mkdir -p "$key_dir"
export CYCLADES_KEYSTORE="$key_dir/cyclades-preview.jks"
# Publicly known test password; never use this test identity for a production release.
unset CYCLADES_SIGNING_KEY CYCLADES_SIGNING_CERT
export CYCLADES_KEY_PASSWORD=android
if [[ ! -f "$CYCLADES_KEYSTORE" ]]; then
 keytool -genkeypair -keystore "$CYCLADES_KEYSTORE" -storepass:env CYCLADES_KEY_PASSWORD -keypass:env CYCLADES_KEY_PASSWORD -alias preview -keyalg RSA -keysize 2048 -validity 3650 -dname 'CN=Cyclades Local Preview'
fi
CYCLADES_PREVIEW=1 bash android/build.sh
mkdir -p artifacts
cp "${CYCLADES_BUILD_DIR:-/tmp/cyclades-android-build}/Cyclades-v16.2.apk" artifacts/Cyclades-v16.2-preview.apk
