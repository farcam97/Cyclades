#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT}"
if [[ -n "${CYCLADES_SIGNING_KEY:-}" ]]; then
 : "${CYCLADES_SIGNING_CERT:?Set CYCLADES_SIGNING_CERT}"
else
 : "${CYCLADES_KEYSTORE:?Set CYCLADES_KEYSTORE}"
 : "${CYCLADES_KEY_PASSWORD:?Set CYCLADES_KEY_PASSWORD}"
fi
BT="$ANDROID_SDK_ROOT/build-tools/35.0.0"
JAR="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
OUT="${CYCLADES_BUILD_DIR:-/tmp/cyclades-android-build}"
mkdir -p "$OUT"
# Clear only generated class/dex directories so removed classes cannot leak into a build.
python3 - "$OUT" <<'PY'
from pathlib import Path
import sys,shutil
root=Path(sys.argv[1]).resolve()
if root in [Path('/'),Path('/workspace'),Path('/tmp')]:raise SystemExit('Use a dedicated build directory')
for name in ['classes','dex']:
 p=root/name
 if p.exists():shutil.rmtree(p)
 p.mkdir()
PY
manifest="android/AndroidManifest.xml"
if [[ "${CYCLADES_PREVIEW:-0}" == 1 ]]; then
 python3 - "$OUT/AndroidManifest.xml" <<'PY'
import sys,xml.etree.ElementTree as E
ns='http://schemas.android.com/apk/res/android';E.register_namespace('android',ns)
tree=E.parse('android/AndroidManifest.xml');root=tree.getroot();root.set('package','com.aegean.cyclades.preview');root.find('application').set('{'+ns+'}label','Cyclades Preview');tree.write(sys.argv[1],encoding='utf-8',xml_declaration=True)
PY
 manifest="$OUT/AndroidManifest.xml"
fi
"$BT/aapt2" compile --dir android/res -o "$OUT/resources.zip"
"$BT/aapt2" link -o "$OUT/base.apk" --manifest "$manifest" -I "$JAR" -A dist "$OUT/resources.zip" --min-sdk-version 26 --target-sdk-version 35
java com.sun.tools.javac.Main -source 8 -target 8 -classpath "$JAR" -d "$OUT/classes" android/src/com/aegean/cyclades/MainActivity.java
find "$OUT/classes" -name '*.class' -print0 | xargs -0 "$BT/d8" --lib "$JAR" --min-api 26 --output "$OUT/dex"
cp "$OUT/base.apk" "$OUT/unsigned.apk"
(cd "$OUT/dex" && zip -q "$OUT/unsigned.apk" classes.dex)
"$BT/zipalign" -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"
APK="$OUT/Cyclades-v16.2.apk"
if [[ -n "${CYCLADES_SIGNING_KEY:-}" ]]; then
 "$BT/apksigner" sign --key "$CYCLADES_SIGNING_KEY" --cert "$CYCLADES_SIGNING_CERT" --out "$APK" "$OUT/aligned.apk"
else
 "$BT/apksigner" sign --ks "$CYCLADES_KEYSTORE" --ks-pass env:CYCLADES_KEY_PASSWORD --out "$APK" "$OUT/aligned.apk"
fi
"$BT/zipalign" -c 4 "$APK"
"$BT/apksigner" verify --verbose "$APK"
printf '%s\n' "$APK"
