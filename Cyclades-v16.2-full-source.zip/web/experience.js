// Coast-accurate macro tiles, readable piece placement and direct-touch interaction.
const APP_DEFAULTS={sound:true,volume:.18,motion:true,cinematics:true,intensity:1,sfxUI:.8,sfxBattle:1,sfxAmbient:0,haptics:false,labels:true,tileEdges:false,contrast:false,speed:1,confirmMap:true};
let APP={...APP_DEFAULTS};try{APP={...APP, ...JSON.parse(localStorage.getItem('cyclades-settings-v5')||'{}')}}catch{}
function saveSettings(){try{localStorage.setItem('cyclades-settings-v5',JSON.stringify(APP))}catch{}FX.reduced=!APP.motion||!!globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;document.body.classList.toggle('reduced-motion',FX.reduced);document.body.classList.toggle('high-contrast-map',APP.contrast);if(FX.reduced){for(const a of FX.active)a.cancel();document.getAnimations?.().forEach(a=>a.cancel())}renderAll()}
const macroPreviousRender=renderMapSVG;
renderMapSVG=function(){
 if(!G.zones?.[0]?.macroShapes){macroPreviousRender();return}
 const shapes=G.zones[0].macroShapes;

 let s=MAP_DEFS+FACTION_DEFS+`<defs><radialGradient id="macro-water"><stop stop-color="#20abc0"/><stop offset=".7" stop-color="#118da3"/><stop offset="1" stop-color="#08697e"/></radialGradient><mask id="water-only"><rect width="560" height="690" fill="white"/>${shapes.map(sh=>`<path d="${sh.path}" fill="black"/>`).join('')}</mask><clipPath id="water-clip"><path d="M0 0H560V690H0Z ${shapes.map(sh=>sh.path).join(' ')}" clip-rule="evenodd"/></clipPath></defs><rect width="560" height="690" fill="url(#macro-water)"/><g mask="url(#water-only)" class="living-sea">`;
 for(let i=0;i<12;i++){const x=(i*137)%550,y=(i*83)%675;s+=`<path class="sea-wave wave-${i%10}" d="M${x} ${y}q10-5 20 0t20 0" fill="none" stroke="#c4fff1" stroke-width="${i%3===0?1.3:.7}" opacity=".22" style="--wave-delay:${-(i%7)}s"/>`}s+='</g>';
 for(const z of G.zones.filter(z=>z.type==='sea')){const anchor=seaDisplayAnchor(z),x=anchor.x,y=anchor.y,valid=availableZone(z.id),selected=R.inspected===z.id,col=z.owner===null?'#e9d494':G.players[z.owner].color;
 s+=`<g id="zone-${z.id}" data-zone="${z.id}" style="--owner-color:${col}" class="paint-zone sea-space ${valid?'legal-space':''} ${selected?'inspected-space':''}" role="button" tabindex="0" aria-label="${z.type==='sea'?'Water space':'Land space'}${valid?', available':''}" onclick="onZoneClick(${z.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();onZoneClick(${z.id})}"><path class="sea-frontier" d="${z.path}" mask="url(#water-only)"/><path class="paint-hit" d="${z.path}" mask="url(#water-only)"/>`;
 s+=renderIndividualPieces(z,x,y);if(!z.fleets&&valid)s+=`<circle class="placement-ring" cx="${x}" cy="${y}" r="18"/>`;s+=prosperityStrip(z,anchor.resource.x,anchor.resource.y);if(APP.labels&&(selected||valid))s+=`<text x="${x}" y="${y-29}" class="water-title" text-anchor="middle">${z.name}</text>`;s+='</g>';
 }
 for(const [shapeIndex,sh] of shapes.entries()){s+=`<path class="coast-surf" d="${sh.path}" fill="none" stroke="#ddfff0" stroke-width="5" opacity=".6"/><path d="${sh.path}" transform="translate(0 2)" fill="#876441" stroke="#164f59" stroke-width="2"/>`;s+=`<defs><clipPath id="coast-cut-${shapeIndex}"><path d="${sh.path}"/></clipPath></defs><g clip-path="url(#coast-cut-${shapeIndex})"><image class="macro-island" href="assets/painted/coast-${sh.artSet?sh.artSet+'-':''}${sh.art}.webp" x="${sh.x}" y="${sh.y}" width="${sh.w}" height="${sh.h}" preserveAspectRatio="none" ${sh.flip?`transform="translate(${2*sh.x+sh.w} 0) scale(-1 1)"`:''}/></g>`}
 if(APP.tileEdges)for(let i=0;i<(G.tileCount||6);i++)s+=`<rect x="${i%2*280+2}" y="${Math.floor(i/2)*1380/(G.tileCount||6)+2}" width="276" height="${1380/(G.tileCount||6)-4}" rx="6" fill="none" stroke="#e1e7d8" opacity=".55" stroke-dasharray="4 5"/><text x="${i%2*280+12}" y="${Math.floor(i/2)*1380/(G.tileCount||6)+17}" class="tile-label">TILE ${G.zones[i*2].face+1}</text>`;
 for(const z of G.zones.filter(z=>z.type==='land')){const x=z.x,y=z.y,col=z.owner===null?'#b6a77a':G.players[z.owner].color,valid=availableZone(z.id),selected=R.inspected===z.id;
 s+=`<g id="zone-${z.id}" data-zone="${z.id}" style="--owner-color:${col}" class="paint-zone land-space ${valid?'legal-space':''} ${selected?'inspected-space':''}" role="button" tabindex="0" aria-label="${z.type==='sea'?'Water space':'Land space'}${valid?', available':''}" onclick="onZoneClick(${z.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();onZoneClick(${z.id})}"><path class="land-frontier" d="${z.path}"/><path class="paint-hit" d="${z.path}"/>`;
 if(APP.labels)s+=`<text x="${x}" y="${y-31}" class="territory-label" text-anchor="middle">${z.name}</text>`;
 s+=renderIndividualPieces(z,x,y);
 const site=sitePosition(z),building=z.metros.length?'M':z.bldgs[0];if(building)s+=paintedImage('building-'+building,site.x-18,site.y-19,36,38,'building-sprite');else s+=`<path d="M${site.x-10} ${site.y}l10-7 10 7-10 7Z" fill="#ede1bc" stroke="#766641"/><path d="m${site.x-4} ${site.y-1} 4-3 4 3-4 3Z" fill="#9c9165"/>`;
 s+=prosperityStrip(z,x,y+31);
 s+='</g>';
 }
 s+='<g id="map-fx"></g>';if(typeof reconcileBoard==='function')reconcileBoard(s);else $('archipelago').innerHTML=s;
};
// Layered soft mallet/plucked-string transients. Starts only after a user gesture.
let audioContext=null,lastSoundAt=0;
function selectionSound(kind='tap'){
 if(!APP.sound||APP.volume<=0||!globalThis.AudioContext&&!globalThis.webkitAudioContext)return;
 try{audioContext??=new(globalThis.AudioContext||globalThis.webkitAudioContext)();if(audioContext.state==='suspended')audioContext.resume();const now=audioContext.currentTime;if(now-lastSoundAt<.035)return;lastSoundAt=now;
 const base={tap:330,confirm:523,back:294,error:146,map:392,tab:440,step:494}[kind]||330;
 const mix=audioContext.createGain();mix.gain.value=APP.volume*.35;mix.connect(audioContext.destination);
 const delay=audioContext.createDelay(.4),echo=audioContext.createGain();delay.delayTime.value=.085;echo.gain.value=.16;mix.connect(delay);delay.connect(echo);echo.connect(audioContext.destination);
 [1,2,3.01,4.18].forEach((h,i)=>{const osc=audioContext.createOscillator(),g=audioContext.createGain();osc.type=i===0?'triangle':'sine';osc.frequency.setValueAtTime(base*h,now);osc.frequency.exponentialRampToValueAtTime(base*h*.998,now+.25);g.gain.setValueAtTime(.0001,now);g.gain.exponentialRampToValueAtTime(.38/(1+i*i),now+.008);g.gain.exponentialRampToValueAtTime(.0001,now+.12+.09/(i+1));osc.connect(g);g.connect(mix);osc.start(now);osc.stop(now+.3)});
 const buffer=audioContext.createBuffer(1,Math.ceil(audioContext.sampleRate*.06),audioContext.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*Math.pow(1-i/data.length,4)*.07;
 const noise=audioContext.createBufferSource(),filter=audioContext.createBiquadFilter();noise.buffer=buffer;filter.type='lowpass';filter.frequency.value=kind==='map'?900:1600;noise.connect(filter);filter.connect(mix);noise.start(now);noise.onended=()=>setTimeout(()=>{mix.disconnect();delay.disconnect();echo.disconnect();filter.disconnect()},450);
 }catch{}
}
document.addEventListener?.('click',e=>{const target=e.target.closest?.('button,.nav-tab,input,select,[role="button"]');if(target&&!target.disabled)selectionSound(target.classList.contains('nav-tab')?'tab':target.classList.contains('primary')?'confirm':'tap')});
document.addEventListener?.('change',e=>{if(e.target.matches?.('input,select'))selectionSound('step')});
// Starting from a selected force skips the redundant source-selection prompt.
function canMoveHere(z){const p=G.players[humanPid()];return myAction()&&z.owner===humanPid()&&p.gp>=1&&(z.type==='sea'?p.god==='POSEIDON'&&z.fleets>0:!medusa(z)&&army(z)>0&&(p.god==='ARES'||p.god!=='APOLLO'&&z.heroes.length))}
let preferredSource=null;
const directAsk=ask;ask=function(pid,title,options,extra=''){if(human(pid)&&preferredSource!==null&&/^(Choose the Sea Area to sail from|Choose a force to move)$/.test(title)){const id=preferredSource;preferredSource=null;if(options.some(o=>o.value===id))return Promise.resolve(id)}return directAsk(pid,title,options,extra)};
function moveFromHere(id){const z=G.zones[id];if(!z||!canMoveHere(z))return;preferredSource=id;startMoveMode(z.type==='sea'?'sea':'land')}
function focusZone(id){const z=G.zones[id];if(!z)return;viewZoom=2;viewX=z.x-140;viewY=z.y-172.5;applyView()}
const controlsBefore=renderActionButtons;renderActionButtons=function(){controlsBefore();if(R.inspected!==null&&!R.pending){const z=G.zones[R.inspected];if(z&&myAction()){$('action-btns').insertAdjacentHTML('afterbegin',`${canMoveHere(z)?btn(z.type==='sea'?'Sail from here':'Move this force',`moveFromHere(${z.id})`,true,true):''}`)}}};
// An uncommitted optional action can be backed out without changing the rules or spending resources.
const checkpoints=[];const commandBefore=userCommand;userCommand=function(fn){if(myAction()){checkpoints.length=0;checkpoints.push(JSON.stringify(G))}return commandBefore(fn)};
function cancelOptionalAction(){if(!checkpoints.length||!R.pending||B)return;const snapshot=checkpoints.pop(),pending=R.pending;R.epoch++;R.pending=null;R.choiceMap=false;R.busy=false;preferredSource=null;pending.reject(new Error('Action cancelled'));timers.forEach(clearTimeout);timers.clear();G=JSON.parse(snapshot);$('decision').classList.remove('active');setPrompt('Action cancelled. Choose another action.');renderAll()}
const actionControls=renderActionButtons;renderActionButtons=function(){actionControls();if(canCancelOptional())$('action-btns').insertAdjacentHTML('beforeend',btn('Cancel action','cancelOptionalAction()'))};
const finalClick=onZoneClick;onZoneClick=function(id){if(dragged){dragged=false;return}selectionSound('map');finalClick(id);renderMapSVG()};
// Press-and-hold focuses a space; two fingers always navigate. Pointer capture prevents stuck gestures.
let pressTimer=null,pressStart=null,suppressMapClickUntil=0;
const mapEl=$('archipelago');
// Unified pointer handler in interface-v15 owns capture and gesture cancellation.
// Focal wheel zoom is installed by performance.js.
// Stepper buttons replace precision typing for moving troop/ship counts.
const forceAsk=ask;ask=function(pid,title,options,extra=''){if(extra.includes('force-form'))extra=extra.replace(/(<input id="(force-[tm])"[^>]+>)/g,(all,input,id)=>`<div class="force-stepper"><button type="button" onclick="stepForce('${id}',-1)" aria-label="Remove one">−</button>${input}<button type="button" onclick="stepForce('${id}',1)" aria-label="Add one">+</button></div>`);const result=forceAsk(pid,title,options,extra);if(canCancelOptional())$('decision-options').insertAdjacentHTML('beforeend',btn('Cancel action','cancelOptionalAction()'));return result};
function stepForce(id,d){const el=$(id);el.value=Math.max(Number(el.min),Math.min(Number(el.max),Number(el.value)+d));selectionSound('step')}
function canCancelOptional(){return checkpoints.length>0&&R.pending&&!B&&JSON.stringify(G)===checkpoints[0]}
const safeCancel=cancelOptionalAction;cancelOptionalAction=function(){if(canCancelOptional())safeCancel()};
// 1. Local completed-action checkpoints, with schema and phase validation on restore.
const SAVE_KEY='cyclades-campaign-v5';let saveNotice='No checkpoint yet',lastSavedState='';
function validSave(s){const g=s?.state;return !!(s?.version===5&&g&&Array.isArray(g.players)&&[3,4,5,6].includes(g.players.length)&&Array.isArray(g.zones)&&g.zones.length>=29&&g.zones[0]?.macroShapes&&['OFFERINGS','ACTIONS','GAME_OVER'].includes(g.phase)&&g.players.every(p=>p&&Number.isFinite(p.gp)&&p.gp>=0)&&g.zones.every((z,i)=>z&&z.id===i&&Array.isArray(z.adj)&&z.adj.every(n=>Number.isInteger(n)&&n>=0&&n<g.zones.length)))}

function readSave(){try{const s=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');return validSave(s)?s:null}catch{return null}}
function checkpointGame(){if(R.auto||R.busy||R.pending||B||!G.zones?.[0]?.macroShapes||G.phase!=='GAME_OVER'&&(!['ACTIONS','OFFERINGS'].includes(G.phase)||!human(G.activeBidder)))return false;const data=JSON.stringify(G);if(data===lastSavedState)return true;try{localStorage.setItem(SAVE_KEY,JSON.stringify({version:5,savedAt:Date.now(),state:G}));lastSavedState=data;saveNotice='Saved · Cycle '+G.cycle;return true}catch{saveNotice='Saving unavailable in this browser';return false}}
function resumeCampaign(){const saved=readSave();if(!saved){saveNotice='No compatible saved campaign';showAppPanel('save');return false}R.epoch++;if(R.pending){const p=R.pending;R.pending=null;p.reject(new Error('Restoring saved campaign'))}timers.forEach(clearTimeout);timers.clear();R.busy=false;R.choiceMap=false;R.inspected=null;B=null;checkpoints.length=0;preferredSource=null;FX.snap=null;G=JSON.parse(JSON.stringify(saved.state));$('decision').classList.remove('active');$('battle-modal').classList.remove('active');$('welcome').hidden=true;closeAppPanel();resetMapView();switchTab(G.phase==='OFFERINGS'?'auction':'map');setPrompt(G.phase==='OFFERINGS'?'Campaign resumed. Make your offering.':G.phase==='GAME_OVER'?'Completed campaign restored.':'Campaign resumed at your last completed action.');renderAll();if(G.phase==='OFFERINGS')advanceBid();return true}
// 2. A compact turn checklist identifies the current decision and available actions.
function checklistText(){if(R.pending)return R.pending.title+' · '+R.pending.options.filter(o=>o.zone!==undefined).length+' map choices';if(G.phase==='SETUP')return 'Found your faction → place fleets → distribute troops';if(G.phase==='OFFERINGS')return human(G.activeBidder)?'Your offering → gods resolve → take your actions':'Opponent is making an offering';if(G.phase==='GAME_OVER')return 'Campaign complete';const p=active();if(p?.id!==0)return(p?.name||'Opponent')+' is resolving actions';const steps=[];if(['ARES','POSEIDON','HERA'].includes(p.god))steps.push((G.turnState.recruitedCount||0)+'/3 paid recruits');if(['ATHENA','ZEUS'].includes(p.god))steps.push(G.turnState.boughtExtraCard?'Extra card bought':'Extra card available');if(p.god==='HERA')steps.push(G.turnState.hiredHero?'Hero recruited':'Hero available');steps.push(p.god==='APOLLO'?'Apollo resolved':'Optional actions');steps.push('End turn when ready');return steps.join(' · ')}
// 3. Searchable reference built from the same text the engine displays.
const REFERENCE_TOPICS=[
 ['Map and movement','Land and sea areas are adjacent when they share a border. Connected land areas form an island. Troops cross water using a connected chain of your fleets. White borders show the areas; Tile Edges shows which macro tile they came from.'],
 ['Touch controls','Tap a glowing space to place a unit or choose a destination. Tap your force, then Move this force or Sail from here. Pinch with two fingers to zoom; drag to pan when zoomed. Hold a space to focus. Stepper buttons choose force size. Cancel is available only before an optional action changes the game.'],
 ['Hidden gold','Your treasury is visible to you. Opponent treasuries stay hidden until the game ends. Offers, cards and units remain public.'],
 ['Construction','Each marked construction site holds a basic Building or Metropolis. If all sites are occupied, the engine offers the legal replacement choices. Fortress, Port, Temple and University are the four basic types.'],
 ['Metropolises','Four Philosophers or one of each basic Building type can develop a Metropolis. Heroes may provide another route. Conquest transfers cities. The goal in this three-player game is three Metropolises; end-of-cycle comparisons and tie-breaks are resolved by the engine.'],
 ['Saving','Completed-action checkpoints are stored in this browser. Setup, battles and multi-step choices are not saved halfway through. Resume returns to the most recent completed-action checkpoint. Clearing browser data removes the save.'],
 ['Sound and motion','Selection sounds use layered plucked strings, wood and bronze tones after a user interaction. Sound volume, motion, map labels, tile seams and high-contrast borders can be changed in Settings. The system reduced-motion preference is respected.']
];
// Read-only walkthrough of existing controls and rules; it never changes a campaign.
const QUICK_GUIDE=[
 ['Your next decision','The message above the action buttons tells you what the game is waiting for. During setup, choose glowing areas on the map. During a turn, available actions depend on your god, gold and pieces.','assets/cards/cover.webp'],
 ['Offer to a god','Open Gods, review each god’s free actions and offer gold for the actions you need. A higher offer can displace another bidder. Keep enough gold for your planned actions; Priestesses reduce the amount paid. Apollo provides an economic alternative.','assets/cards/zeus.webp'],
 ['Read and navigate the board','Faction emblems and borders identify ownership. Tap a region to inspect it. Drag to pan and pinch to zoom; the compass fits the board. With a keyboard, focus a region and press Enter or Space. Arrow keys pan; + and − zoom.','assets/tiles-v14/tile-1.webp'],
 ['Move and build deliberately','Select your own force and a movement action, then follow the source, quantity and destination choices. Connected fleets can carry land forces across water. Review the highlighted destination before confirming. Battles and creatures can change which moves are legal.','assets/v15/actions/move-fleet.webp'],
 ['Grow and finish your turn','Philosophers, sets of Buildings, Hero sacrifices and conquest can produce Metropolises. Use a card’s powers panel to read its conditions. When your actions are complete, choose End turn; the engine checks victory at the appropriate cycle boundary.','assets/painted/building-M.webp'],
 ['Keep a recoverable campaign','Completed actions create local checkpoints. Settings → Campaign lets you resume, export or import one. Export a copy before moving devices. Mid-battle and unfinished decisions return to the previous completed-action checkpoint after a restart.','assets/ui-v14/app-icon.webp']
];
function showQuickGuide(step=0){
 step=Math.max(0,Math.min(QUICK_GUIDE.length-1,Number(step)||0));
 showAppPanel('guide');
 $('app-panel-title').textContent='How to play';
 const [title,text,image]=QUICK_GUIDE[step];
 $('app-panel-content').innerHTML=`<article class="quick-guide"><p class="guide-progress">Step ${step+1} of ${QUICK_GUIDE.length}</p><img src="${image}" alt=""><h3 tabindex="-1" id="guide-heading">${title}</h3><p>${text}</p><nav aria-label="Guide pages">${step?btn('Previous',`showQuickGuide(${step-1})`):''}${step<QUICK_GUIDE.length-1?btn('Next',`showQuickGuide(${step+1})`,true,true):btn('Return to game','closeAppPanel()',true,true)}</nav></article>`;
 $('guide-heading').focus();
}
function referenceEntries(){return [...REFERENCE_TOPICS,...CREATURES.map(c=>[c.name,c.desc]),...HEROES.map(h=>[h.name,h.mil+' Sacrifice: '+h.sac]),...Object.values(GOD_DATA).map(g=>[g.name,g.free+'. '+g.paid]) ]}
function searchReference(q=''){const entries=referenceEntries().filter(e=>e.join(' ').toLowerCase().includes(q.toLowerCase()));$('reference-results').innerHTML=entries.length?entries.map(([title,body])=>`<article class="reference-entry"><h3>${htmlEscape(title)}</h3><p>${htmlEscape(body)}</p></article>`).join(''):'<p>No matching entry.</p>'}
// 4. One settings panel for sound, motion and map readability; preferences persist locally.
document.body.insertAdjacentHTML('beforeend','<div id="app-panel" class="app-panel" hidden role="dialog" aria-modal="true" aria-labelledby="app-panel-title"><section class="app-panel-box"><header><button class="btn utility-action panel-close" onclick="closeAppPanel()" aria-label="Close tools">✕</button><h2 id="app-panel-title">Campaign tools</h2></header><nav><button onclick="showAppPanel(\'settings\')">Settings</button><button onclick="showAppPanel(\'reference\')">Reference</button><button onclick="showAppPanel(\'save\')">Campaign</button></nav><div id="app-panel-content"></div></section></div>');
document.querySelector('.cycle-meta').insertAdjacentHTML('beforeend','<button class="top-control" onclick="showAppPanel(\'settings\')" aria-label="Open app settings">⚙</button>');
document.querySelector('.action-bar').insertAdjacentHTML('afterbegin','<div id="turn-checklist" class="turn-checklist"></div>');
function settingCheck(key,label){return `<label class="setting-row"><span>${label}</span><input type="checkbox" ${APP[key]?'checked':''} onchange="APP.${key}=this.checked;saveSettings()"></label>`}
function showAppPanel(tab='settings'){$('app-panel').hidden=false;let html='';if(tab==='settings')html=settingCheck('sound','Tactile selection sounds')+`<label class="setting-row"><span>Sound volume</span><input aria-label="Sound volume" type="range" min="0" max=".6" step=".02" value="${APP.volume}" oninput="APP.volume=Number(this.value);saveSettings()" onchange="selectionSound('confirm')"></label>`+settingCheck('motion','Animations and living sea')+settingCheck('tileEdges','Show macro tile edges')+settingCheck('contrast','High-contrast borders')+'<p class="panel-note">System reduced-motion preference takes precedence. Sound begins after your first selection.</p>';else if(tab==='reference')html='<input id="reference-search" class="reference-search" type="search" placeholder="Search gods, heroes, creatures, controls…" aria-label="Search rules reference" oninput="searchReference(this.value)"><div id="reference-results"></div>';else{const s=readSave();html=`<h3>${s?'Saved campaign · Cycle '+s.state.cycle:'No saved campaign yet'}</h3><p>${s?'Last checkpoint: '+new Date(s.savedAt).toLocaleString():'Your first checkpoint is saved after setup, when you can make an offering.'}</p><p class="panel-note">Saves stay in this browser. Unfinished choices return to the previous completed-action checkpoint.</p><button class="btn primary" onclick="resumeCampaign()" ${s?'':'disabled'}>Resume saved campaign</button><button class="btn" onclick="checkpointGame();showAppPanel('save')" ${R.busy||R.pending||B?'disabled':''}>Save checkpoint now</button><p>${saveNotice}</p>`}$('app-panel-content').innerHTML=html;if(tab==='reference'){searchReference();$('reference-search').focus()}selectionSound('tab')}
function closeAppPanel(){$('app-panel').hidden=true}
// Keep keyboard focus inside visible modal panels and restore the invoking control.
let panelInvoker=null;
const panelNode=$('app-panel');
const panelObserver=typeof MutationObserver==='function'?new MutationObserver(records=>{
 if(!records.some(r=>r.attributeName==='hidden'))return;
 if(panelNode.hidden){if(panelInvoker?.isConnected)panelInvoker.focus();panelInvoker=null;return}
 if(!panelInvoker)panelInvoker=document.activeElement;
 if(!panelNode.contains(document.activeElement))panelNode.querySelector('button,input,select,[tabindex="0"]')?.focus();
}):null;
panelObserver?.observe(panelNode,{attributes:true,attributeFilter:['hidden']});
document.addEventListener?.('keydown',e=>{
 if(panelNode.hidden)return;
 if(e.key==='Escape'){e.preventDefault();closeAppPanel();return}
 if(e.key!=='Tab')return;
 const controls=[...panelNode.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea,[tabindex="0"]')].filter(el=>el.getClientRects().length&&el.getAttribute('aria-disabled')!=='true');
 const first=controls[0],last=controls.at(-1);if(!first)return;
 if(e.shiftKey&&(!panelNode.contains(document.activeElement)||document.activeElement===first)){e.preventDefault();last.focus()}
 else if(!e.shiftKey&&(!panelNode.contains(document.activeElement)||document.activeElement===last)){e.preventDefault();first.focus()}
});
$('prompt-text').setAttribute('role','status');
$('prompt-text').setAttribute('aria-live','polite');

const experienceRender=renderAll;renderAll=function(){experienceRender();$('turn-checklist').textContent=checklistText();checkpointGame()};
if(readSave())$('welcome').querySelector('.welcome-box')?.insertAdjacentHTML('beforeend','<button class="btn primary" onclick="resumeCampaign()" style="margin-top:12px">Resume saved campaign</button>');
FX.reduced=!APP.motion||!!globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
renderAll();
// Buttons and pinch share one zoom range and preserve the current viewport center.
zoomMap=function(delta){const cx=viewX+280/viewZoom,cy=viewY+345/viewZoom;viewZoom=Math.max(1,Math.min(3.5,viewZoom+delta));viewX=cx-280/viewZoom;viewY=cy-345/viewZoom;applyView()};
