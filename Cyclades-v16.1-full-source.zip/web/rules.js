/* Three-player rules engine, reconciled to the supplied Legendary Edition manual.
   The archipelago is custom: one construction site per land area; geometry is not an official tile scan. */
const R={epoch:0,busy:false,pending:null,inspected:null,choiceMap:false,auto:false};
const TYPES=['F','P','T','U'],BN={F:'Fortress',P:'Port',T:'Temple',U:'University'};
const HERO_RULES={
 ajax:['Strength 2.','Control 7 Land Areas to build a Metropolis.'],
 helen:['Your Battle die is exactly 2.','Exchange 2 Buildings of one type and 2 of another for a Metropolis.'],
 odysseus:['Ignore enemy Fortresses in battle.','Exchange 3 identical basic Buildings for a Metropolis.'],
 croesus:['Pay 1 gold per Battle die reroll; repeat as desired.','Pay 15 gold to build a Metropolis.'],
 hector:['Choose one invading Troop or Mercenary to destroy before battle.','Exchange pairs of Priestesses for Philosophers; repeat during this sacrifice.'],
 penthesilea:['Win ties in land battle.','When you build a Metropolis, sacrifice her to keep it protected on her card.'],
 pandora:['Enemy Mercenaries in her battle join your force.','Use the sacrifice power of a Hero on the available track.'],
 perseus:['A Troop casualty may retreat instead; Perseus cannot escape his own destruction.','Move any force between two Land Areas for free, respecting Medusa.'],
 jason:['Use enemy Fleets during his Heroic Move, but not for retreat.','Have all 8 of your Fleets in play to build a Metropolis.']
};
const HEROES=Object.entries(HERO_RULES).map(([id,[mil,sac]])=>({id,name:id[0].toUpperCase()+id.slice(1),mil,sac}));
const CREATURES=[
 ['charon','Charon','Swap one of your Heroes with a Hero on the available track.'],['chimera','Chimera','Play a discarded Creature for free. Then shuffle the Creature deck and discard pile together.'],
 ['cyclops','Cyclops','Exchange one of your basic Buildings for another from the reserve.'],['dryad','Dryad','Steal one Priestess from a player of your choice.'],['giant','Giant','Take all Mercenaries from one Land Area and distribute them over your lands.'],['griffin','Griffin','Steal half the gold, rounded down, from a player you choose.'],['harpy','Harpy','Destroy one Troop or Mercenary in any Land Area; never a Hero.'],['graeae','The Graeae','Repeat an Income phase for yourself.'],['pegasus','Pegasus','Move all or part of a force between any two Land Areas for free. Medusa still blocks movement.'],['satyr','Satyr','Steal one Philosopher from a player you choose.'],['sphynx','Sphynx','Draw 3 Creatures, discard 2, and play the third for free.'],['sylph','Sylph','Swap the Fleets in any two occupied Sea Areas.'],
 ['cerberus','Cerberus','Its controller receives this Land Area’s income, instead of its landowner.','land'],['hydra','Hydra','Double the income of its Land or Sea Area for that area’s recipient.','any'],['kraken','Kraken','Destroy all Fleets in its Sea Area and prohibit all Fleets from entering.','sea'],['medusa','Medusa','No Troop, Mercenary or Hero may enter or leave its Land Area.','land'],['minotaur','Minotaur','Strength 2 defending your Land Area. Can be chosen as a casualty; cannot retreat.','owned'],['polyphemus','Polyphemus','Adjacent Sea Areas are forbidden to all Fleets. Relocate Fleets there, or destroy any that cannot move.','land']
].map(([id,name,desc,mini])=>({id,name,desc,mini}));
GOD_DATA.APOLLO.free='+2 gold; place 1 land and 1 sea Prosperity token';GOD_DATA.APOLLO.paid='Acts last; first to offer next cycle. No Creatures or Hero actions.';
GOD_DATA.ZEUS.paid='1 Priestess for 4 gold; inspect the deck’s top Creature once, then optionally play it for 1 gold.';
GOD_DATA.HERA.paid='Mercenaries: 1/3/5 gold. Recruit ONE Hero for 4 gold.';
const htmlEscape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
const active=()=>G.players[G.activeBidder];
function maximumOffer(p){const reserved=G.players.filter(q=>q.id!==p.id&&q.team!==undefined&&q.team===p.team).reduce((n,q)=>n+Math.max(0,(q.bid||0)-q.priests),0);return Math.max(0,p.gp-reserved)+p.priests}
function humanPid(){const p=G.players?.[G.activeBidder];return p?.controller===0?p.id:0}
const human=pid=>!R.auto&&(G.players?.[pid]?.controller===0||G.players?.[pid]?.controller===undefined&&pid===0);
const army=z=>(z.troops||0)+(z.mercs||0)+(z.heroes?.length||0);
const minis=z=>G.monsters.filter(m=>m.zone===z.id);
const medusa=z=>minis(z).some(m=>m.id==='medusa');
const minotaur=(z,pid)=>minis(z).find(m=>m.id==='minotaur'&&m.owner===pid);
const forceSize=f=>f.troops+f.mercs+f.heroes.length+(f.minotaur?1:0);
const basicCount=pid=>lands(pid).reduce((n,z)=>n+z.troops,0)+(B&&!B.transferred&&B.attId===pid?B.att.troops:0);
const fleetCount=pid=>G.zones.reduce((n,z)=>n+(z.type==='sea'&&z.owner===pid?z.fleets:0),0)+(B&&!B.transferred&&B.type==='sea'&&B.attId===pid?B.att.troops:0);
const mercCount=()=>G.zones.reduce((n,z)=>n+(z.mercs||0),0)+(B&&!B.transferred?B.att.mercs:0);
const buildingCount=t=>G.zones.reduce((n,z)=>n+(z.bldgs||[]).filter(b=>b===t).length,0);
const freeSites=z=>z.capacity-z.bldgs.length-z.metros.length;
const buildingPower=(pid,t)=>lands(pid).reduce((s,z)=>s+z.bldgs.filter(b=>b===t).length+z.metros.length,0);
countMetropolises=pid=>lands(pid).reduce((n,z)=>n+(z.metros?.length||(z.metro?1:0)),0)+(G.players[pid].protected?.length||0);
getPlayerBuildings=pid=>lands(pid).flatMap(z=>z.bldgs);
getMissingBuildingType=p=>TYPES.find(t=>!getPlayerBuildings(p.id).includes(t));
myAction=()=>G.phase==='ACTIONS'&&human(G.activeBidder)&&!R.busy&&!B;
function supplyCard(p,key,n=1){const available=20-G.players.reduce((s,q)=>s+q[key],0),take=Math.max(0,Math.min(n,available));p[key]+=take;return take}
function seasBlocked(z){return G.monsters.some(m=>m.id==='kraken'&&m.zone===z.id||m.id==='polyphemus'&&G.zones[m.zone].adj.includes(z.id))}
function areaIncome(z){return z.pros*(minis(z).some(m=>m.id==='hydra')?2:1)}
function incomeRecipient(z){const c=minis(z).find(m=>m.id==='cerberus');return c?c.owner:z.owner}
income=pid=>G.zones.reduce((n,z)=>n+(incomeRecipient(z)===pid?areaIncome(z):0),0);
logMsg=function(s){G.logs.unshift(`[C${G.cycle}] ${cleanText(s)}`);G.logs=G.logs.slice(0,200);if($('log-list'))$('log-list').innerHTML=G.logs.map(l=>`<div class="log-entry">${l}</div>`).join('')};
function optsAreas(zs){return zs.map(z=>({value:z.id,zone:z.id,label:z.name,detail:z.type==='land'?`${z.owner===null?'Neutral':G.players[z.owner].name} · ${z.troops} troops · ${z.mercs} mercenaries · ${z.heroes.length} heroes · ${z.metros.length} cities`:`${z.fleets} fleets · ${z.pros} prosperity`,score:(z.owner===null?8:0)+z.pros+(z.priestIcon?2:0)}))}
function btn(label,code,ok=true,primary=false){return `<button class="btn ${primary?'primary':''}" onclick="${code}" ${ok?'':'disabled'}>${label}</button>`}
document.body.insertAdjacentHTML('beforeend','<div class="decision-backdrop" id="decision" role="dialog" aria-modal="true"><div class="decision-box"><div class="eyebrow">Your decision</div><h2 id="decision-title"></h2><div id="decision-extra"></div><div id="decision-options"></div><button class="btn" id="decision-map" onclick="chooseOnMap()">Choose on the map</button></div></div>');
function ask(pid,title,options,extra=''){
 if(!options.length){if(human(pid))setPrompt('No legal options: '+title);return Promise.resolve(null);}
 if(!human(pid))return Promise.resolve([...options].sort((a,b)=>(b.score||0)-(a.score||0))[0].value);
 const epoch=R.epoch;
 return new Promise((resolve,reject)=>{R.pending={title,options,resolve,reject,epoch};$('decision-title').textContent=title;$('decision-extra').innerHTML=extra;$('decision-options').innerHTML=options.map((o,i)=>`<button class="decision-option" onclick="answerDecision(${i})">${o.image?`<img src="${typeof decisionImage==='function'?decisionImage(o.image):'assets/'+o.image+'.webp'}" alt="">`:''}<span>${o.label}<small>${o.detail||''}</small></span></button>`).join('');$('decision-map').hidden=!options.some(o=>o.zone!==undefined);if(options.some(o=>o.zone!==undefined)){chooseOnMap()}else{$('decision').classList.add('active');renderAll()}});
}
function answerDecision(i){const p=R.pending;if(!p||!p.options[i])return;R.pending=null;R.choiceMap=false;$('decision').classList.remove('active');p.resolve(p.options[i].value)}
function chooseOnMap(){if(!R.pending)return;R.choiceMap=true;$('decision').classList.remove('active');switchTab('map');setPrompt(R.pending.title);renderAll()}
function showDecision(){if(R.pending){R.choiceMap=false;$('decision').classList.add('active')}}
async function runFlow(fn){if(R.busy)return;const e=R.epoch;R.busy=true;try{await fn()}catch(err){if(e===R.epoch){console.error(err);setPrompt('That action could not complete. Please start a new game.')}}finally{if(e===R.epoch){R.busy=false;renderAll()}}}
function discardCreature(c){if(!c)return;G.discard.push(c);if(c.id==='chimera'){G.deck=shuffle([...G.deck,...G.discard]);G.discard=[];logMsg('Chimera reshuffles the Creature deck and discard pile.')}}
function drawCreature(){return G.deck.shift()||null}
async function gainIncome(p){const n=income(p.id);p.gp+=n;logMsg(p.id===0?`You collect ${n} gold in income.`:`${p.name} collects income behind its screen.`)}
async function bonus(p,type){
 if(type==='gold'){p.gp+=3;logMsg(`${p.name} receives the three-gold Metropolis bonus.`)}
 if(type==='priest')supplyCard(p,'priests');
 if(type==='prosperity'){const zs=G.zones.filter(z=>z.owner===p.id);const id=await ask(p.id,'Place the Metropolis Prosperity bonus',optsAreas(zs));if(id!==null)G.zones[id].pros++}
 if(type==='troops')for(let i=0;i<2&&basicCount(p.id)<8;i++){const id=await ask(p.id,'Place a bonus Troop',optsAreas(lands(p.id)));if(id!==null)G.zones[id].troops++}
 if(type==='fleets')for(let i=0;i<2&&fleetCount(p.id)<8;i++){const id=await ask(p.id,'Place a bonus Fleet in waters you control',optsAreas(G.zones.filter(z=>z.type==='sea'&&z.owner===p.id&&!seasBlocked(z))));if(id!==null)G.zones[id].fleets++}
}
function canBuildMetro(p){return G.metroDeck.length&&(lands(p.id).some(z=>freeSites(z)>0||z.bldgs.length)||(G.phase==='ACTIONS'&&p.god!=='APOLLO'&&lands(p.id).some(z=>z.heroes.some(h=>h.summonedCycle<G.cycle&&(h.id==='penthesilea'||h.id==='pandora'&&G.heroes.some(g=>g.id==='penthesilea'))))))}
async function constructMetro(p){
 if(!G.metroDeck.length){logMsg('No Metropolis tokens remain.');return}
 const free=lands(p.id).filter(z=>freeSites(z)>0),sites=free.length?free:lands(p.id).filter(z=>z.bldgs.length);
 const ph=lands(p.id).flatMap(z=>z.heroes.filter(h=>(h.id==='penthesilea'||h.id==='pandora'&&G.heroes.some(q=>q.id==='penthesilea'))&&h.summonedCycle<G.cycle).map(h=>({z,h})));
 const choices=optsAreas(sites);if(p.god!=='APOLLO'&&G.phase==='ACTIONS'&&ph.length)choices.unshift({value:'protected',label:'Protect with '+ph[0].h.name,detail:'Protect this Metropolis on her card, beyond enemy conquest.',score:15});
 const id=await ask(p.id,'Place your new Metropolis',choices);if(id===null)return;
 if(id==='protected'&&ph.length>1){const selected=await ask(p.id,'Choose the protecting Hero',ph.map((q,i)=>({value:i,label:q.h.name,image:q.h.id})));if(selected===null)return;ph.unshift(ph.splice(selected,1)[0])}const type=G.metroDeck.shift();
 if(id==='protected'){ph[0].z.heroes.splice(ph[0].z.heroes.indexOf(ph[0].h),1);p.protected.push(type)}else{const z=G.zones[id];if(freeSites(z)<=0){const t=await ask(p.id,'Remove a Building to make room',z.bldgs.map((b,i)=>({value:i,label:BN[b]})));if(t!==null&&t>=0){z.bldgs.splice(t,1);z.templeUses?.splice(t,1)}}z.metros.push(type);z.metro=true}
 logMsg(`${p.name} builds a Metropolis. Bonus: ${{gold:'3 gold',priest:'a Priestess',prosperity:'a Prosperity token',troops:'two Troops',fleets:'two Fleets'}[type]}.`);await bonus(p,type);
}
async function settle(p){
 while(canBuildMetro(p)){
 if(p.phils>=4){p.phils-=4;await constructMetro(p);continue}
 if(TYPES.every(t=>getPlayerBuildings(p.id).includes(t))){for(const t of TYPES)await removeBuildings(p,t,1);await constructMetro(p);continue}break;
 }
}
checkAllMetropolises=function(){};
async function build(p,t,optional=true){
 if(!t||buildingCount(t)>=10)return;const ls=lands(p.id),free=ls.filter(z=>freeSites(z)>0);
 let options=optsAreas(free.length?free:ls.filter(z=>z.bldgs.length));if(!free.length&&optional)options.push({value:'skip',label:'Forgo the Building',score:-10});
 const id=await ask(p.id,`Place your ${BN[t]}`,options);if(id===null||id==='skip')return;const z=G.zones[id];
 if(freeSites(z)<=0){const i=await ask(p.id,'Choose a basic Building to replace',z.bldgs.map((b,i)=>({value:i,label:BN[b]})));if(i!==null&&i>=0){z.bldgs.splice(i,1);z.templeUses?.splice(i,1)}}z.bldgs.push(t);logMsg(`${p.name} builds a ${BN[t]} in ${z.name}.`);await settle(p);
}
async function recruit(p,kind,cost=0,at=null){
 if(p.gp<cost)return false;if(kind==='troops'&&basicCount(p.id)>=8||kind==='fleets'&&fleetCount(p.id)>=8||kind==='mercs'&&mercCount()>=16)return false;
 const zs=kind==='fleets'?G.zones.filter(z=>z.type==='sea'&&!seasBlocked(z)&&(z.owner===null||z.owner===p.id)&&z.adj.some(id=>G.zones[id].type==='land'&&G.zones[id].owner===p.id)):lands(p.id).filter(z=>typeof boarBlocks!=='function'||!boarBlocks(z));
 const id=at!==null?(zs.some(z=>z.id===at)?at:null):await ask(p.id,`Place ${kind==='fleets'?'a Fleet':kind==='mercs'?'a Mercenary':'a Troop'}${cost?' · '+cost+' gold':''}`,optsAreas(zs));if(id===null)return false;
 spendGold(p,cost);G.zones[id][kind]++;G.zones[id].owner=p.id;logMsg(`${p.name} recruits a ${kind==='fleets'?'ship':kind==='mercs'?'mercenary':'troop'}.`);if(typeof recruitedFeedback15==='function')await recruitedFeedback15(p,kind,G.zones[id]);return true;
}
async function mandatory(p){
 if(p.god==='APOLLO'){p.gp+=2;for(const type of ['land','sea']){const id=await ask(p.id,`Apollo: place 1 ${type} Prosperity token`,optsAreas(G.zones.filter(z=>z.type===type&&z.owner===p.id)));if(id!==null)G.zones[id].pros++}logMsg(`${p.name} receives Apollo’s favor.`);return}
 let t={ARES:'F',POSEIDON:'P',ZEUS:'T',ATHENA:'U'}[p.god];
 if(p.god==='HERA')t=await ask(p.id,'Hera: choose a basic Building you do not own',TYPES.filter(t=>!getPlayerBuildings(p.id).includes(t)&&buildingCount(t)<10).map(t=>({value:t,label:BN[t],image:'painted/building-'+t})));
 await build(p,t);
 if(p.god==='ARES')await recruit(p,'troops');if(p.god==='POSEIDON')await recruit(p,'fleets');if(p.god==='HERA')await recruit(p,'mercs');
 if(p.god==='ZEUS')supplyCard(p,'priests');if(p.god==='ATHENA'){supplyCard(p,'phils');await settle(p)}
}
function connected(pid,from,to,enemy=false){
 const a=G.zones[from],b=G.zones[to];if(a.adj.includes(to)&&a.type===b.type)return true;
 const q=a.adj.filter(id=>{const z=G.zones[id];return z.type==='sea'&&z.fleets>0&&(enemy||z.owner===pid)&&!seasBlocked(z)}),seen=new Set(q);
 while(q.length){const z=G.zones[q.shift()];if(z.adj.includes(to))return true;for(const id of z.adj){const n=G.zones[id];if(n.type==='sea'&&n.fleets>0&&(enemy||n.owner===pid)&&!seasBlocked(n)&&!seen.has(id)){seen.add(id);q.push(id)}}}return false;
}
areLandsConnected=(pid,a,b)=>connected(pid,a,b);
function canAttack(pid,z){const incoming=[...getPlayerBuildings(pid),...z.bldgs],sets=Math.min(...TYPES.map(t=>incoming.filter(b=>b===t).length));return z.owner===null||z.owner===pid||lands(z.owner).length>1||countMetropolises(pid)+z.metros.length+sets>=3}
function landTargets(p,z,free=false,jason=false){return G.zones.filter(t=>t.type==='land'&&t.id!==z.id&&!medusa(t)&&canAttack(p.id,t)&&(free||connected(p.id,z.id,t.id,jason)))}
async function selectForce(p,z,hero=null){
 const f={troops:z.type==='sea'?z.fleets:z.troops,mercs:z.mercs||0,heroes:[...(z.heroes||[])],minotaur:null};
 if(!human(p.id))return f;
 let extra=`<div class="force-form"><label>${z.type==='sea'?'Fleets':'Troops'}<input id="force-t" type="number" min="0" max="${f.troops}" value="${f.troops}"></label>`;
 if(z.type==='land'){extra+=`<label>Mercenaries<input id="force-m" type="number" min="0" max="${f.mercs}" value="${f.mercs}"></label>`;for(const h of f.heroes)extra+=`<label class="hero-check"><input id="force-${h.id}" type="checkbox" checked ${h===hero?'disabled':''}>${h.name}</label>`}extra+='</div>';
 for(;;){const res=await ask(p.id,'Choose the force to move',[{value:'go',label:'Confirm this force'}],extra);const ft=$('force-t'),fm=$('force-m');const t=ft?Number(ft.value):f.troops,m=(z.type==='land'&&fm)?Number(fm.value):0,hs=f.heroes.filter(h=>{const el=$('force-'+h.id);return el?el.checked:true});if(Number.isInteger(t)&&t>=0&&t<=f.troops&&Number.isInteger(m)&&m>=0&&m<=f.mercs&&t+m+hs.length>0&&(!hero||hs.includes(hero)))return {troops:t,mercs:m,heroes:hs,minotaur:null};if(res===null||!ft)return f;}
}
async function takeLand(p,z,previous){
 z.owner=p.id;if(previous!==p.id&&z.priestIcon)supplyCard(p,'priests');
 if(previous!==null&&previous!==p.id){if(!lands(previous).length)G.eliminatedThisCycle=true}
 await settle(p);
}
async function move(p,type,free=false){
 if(type==='sea'){
 const from=await ask(p.id,'Choose the Sea Area to sail from',optsAreas(G.zones.filter(z=>z.type==='sea'&&z.owner===p.id&&z.fleets)));
 if(from===null)return;const fz=G.zones[from],to=await ask(p.id,'Choose adjacent waters',optsAreas(typeof seaTargets==='function'?seaTargets(p,fz):fz.adj.map(id=>G.zones[id]).filter(z=>z.type==='sea'&&!seasBlocked(z))));if(to===null)return;const seaCost=typeof connectedRoute==='function'?connectedRoute(p.id,from,to,false,'sea').length-1:1;if(p.gp<seaCost)return;
 setMovementContext(p,fz,to,null,free);const f=await selectForce(p,fz);await presentForceTravel(p,fz,G.zones[to],f);spendGold(p,seaCost);fz.fleets-=f.troops;if(!fz.fleets)fz.owner=null;const tz=G.zones[to];
 if(tz.owner!==null&&tz.owner!==p.id&&tz.fleets)await battle(p,fz,tz,f,'sea');else{tz.owner=p.id;tz.fleets+=f.troops}return;
 }
 const zs=lands(p.id).filter(z=>army(z)>0&&!medusa(z)&&(free||p.god==='ARES'||z.heroes.length)&&(typeof creatureEffectDepth==='undefined'||!creatureEffectDepth||z.troops+z.mercs+z.heroes.filter(h=>h.id!=='penelope').length>0));
 const from=await ask(p.id,'Choose a force to move',optsAreas(zs).map(o=>({...o,score:army(G.zones[o.value])*3})));if(from===null)return;const fz=G.zones[from];let hero=null;
 if(!free&&p.god!=='ARES'){const id=await ask(p.id,'Choose the Hero leading this move',fz.heroes.filter(h=>p.god!=='APOLLO'||h.id==='leto').map(h=>({value:h.id,label:h.name,detail:`Move cost: ${(h.id==='pericles'?1:(G.turnState.heroicMoves||0)+1)} gold`,image:h.id})));hero=fz.heroes.find(h=>h.id===id);if(!hero)return}
 let cost=free?0:hero?(hero.id==='pericles'?1:(G.turnState.heroicMoves||0)+1):1;if(cost>p.gp)return;
 const targets=landTargets(p,fz,free,hero?.id==='jason');const to=await ask(p.id,'Choose the destination',optsAreas(targets).map(o=>({...o,score:o.score+(G.zones[o.value].owner!==p.id?5:0)-army(G.zones[o.value])*2})));
 if(to===null)return;if(!free&&typeof connectedRoute==='function'){const moves=Math.max(1,connectedRoute(p.id,from,to,hero?.id==='jason').filter(id=>G.zones[id].type==='land').length-1);cost=hero?(hero.id==='pericles'?moves:moves*(G.turnState.heroicMoves||0)+moves*(moves+1)/2):moves;if(p.gp<cost){setPrompt('Not enough gold for this route.');return}}setMovementContext(p,fz,to,hero,free);const f=await selectForce(p,fz,hero);if(hero&&f.heroes.some(h=>h.id==='pericles'))cost=Math.max(1,connectedRoute(p.id,from,to,hero.id==='jason').filter(id=>G.zones[id].type==='land').length-1);if(typeof heraclesRoute==='function')await heraclesRoute(f,free?[from,to]:connectedRoute(p.id,from,to,hero?.id==='jason'));await presentForceTravel(p,fz,G.zones[to],f);spendGold(p,cost);if(hero)G.turnState.heroicMoves=(G.turnState.heroicMoves||0)+Math.max(1,connectedRoute(p.id,from,to,hero.id==='jason').filter(id=>G.zones[id].type==='land').length-1);
 fz.troops-=f.troops;fz.mercs-=f.mercs;fz.heroes=fz.heroes.filter(h=>!f.heroes.includes(h));const tz=G.zones[to];
 if(tz.owner!==null&&tz.owner!==p.id&&(army(tz)||minotaur(tz,tz.owner)))await battle(p,fz,tz,f,'land');else{const prev=tz.owner;tz.troops+=f.troops;tz.mercs+=f.mercs;tz.heroes.push(...f.heroes);await takeLand(p,tz,prev)}
 logMsg(`${p.name} moves from ${fz.name} to ${tz.name}.`);
}
function heroPower(f,id,pid){return f.heroes.some(h=>h.id===id)}
function battleForce(z,pid,type){return {troops:type==='sea'?z.fleets:z.troops,mercs:z.mercs||0,heroes:[...(z.heroes||[])],minotaur:type==='land'?minotaur(z,pid):null}}
function syncDef(){const z=G.zones[B.toId];if(B.type==='sea')z.fleets=B.def.troops;else{z.troops=B.def.troops;z.mercs=B.def.mercs;z.heroes=[...B.def.heroes]}}
function battleStrength(f,pid,defender){let n=f.troops+f.mercs+f.heroes.length+(f.minotaur?2:0);if(heroPower(f,'ajax',pid))n++;const z=G.zones[B.toId];if(B.type==='sea')n+=z.adj.reduce((s,id)=>{const l=G.zones[id];return s+(l.type==='land'&&l.owner===pid?l.bldgs.filter(b=>b==='P').length+l.metros.length:0)},0);else if(defender&&!heroPower(B.att,'odysseus',B.attId))n+=z.bldgs.filter(b=>b==='F').length+z.metros.length;return n}
function retreatAreas(pid){const z=G.zones[B.toId];return G.zones.filter(t=>t.id!==z.id&&t.type===z.type&&(t.owner===null||t.owner===pid)&&(z.type==='sea'?z.adj.includes(t.id)&&!seasBlocked(t):!medusa(t)&&connected(pid,z.id,t.id)))}
function showBattle(msg){
 $('battle-modal').classList.add('active');$('battle-title').textContent=`${B.type==='land'?'Land':'Sea'} battle · ${G.zones[B.toId].name}`;$('battle-subtitle').textContent=`Round ${B.round}`;
 ['att','def'].forEach(side=>{const pid=B[side+'Id'],p=G.players[pid],f=B[side];$(side+'-panel').innerHTML=`<img class="battle-emblem" src="assets/${(p.god||'ARES').toLowerCase()}.webp" alt=""><div style="color:${p.color}">${p.name}</div><div class="dice-box">${battleStrength(f,pid,side==='def')}</div><small>${forceSize(f)} units · strength before dice</small>`});$('battle-roll-summary').textContent=msg;$('battle-actions').innerHTML='<small>Resolve the decisions shown above.</small>';
}
async function battleDie(pid,f){let d=heroPower(f,'helen',pid)?2:DICE_FACES[Math.floor(Math.random()*6)];if(heroPower(f,'croesus',pid)){let tries=0;while(G.players[pid].gp>0){const v=await ask(pid,`Croesus: your die shows ${d}`,[{value:'keep',label:`Keep ${d}`,score:d>=2||tries>=2?5:0},{value:'roll',label:'Pay 1 gold to reroll',score:d<2&&tries<2?4:-1}]);if(v!=='roll')break;spendGold(G.players[pid],1);tries++;d=heroPower(f,'helen',pid)?2:DICE_FACES[Math.floor(Math.random()*6)]}}return d}
async function removeCasualty(side){
 const f=B[side],pid=B[side+'Id'];let choices=[];
 if(f.troops)choices.push({value:'troops',label:B.type==='sea'?'Lose a Fleet':'Lose a Troop',score:5});if(f.mercs)choices.push({value:'mercs',label:'Lose a Mercenary',score:6});for(const h of f.heroes)choices.push({value:h.id,label:'Lose '+h.name,image:h.id,score:0});if(f.minotaur)choices.push({value:'minotaur',label:'Destroy the Minotaur',score:-1});
 const v=await ask(pid,'Choose your battle casualty',choices);if(!v)return;B.report?.losses[side].push(v);
 if(['troops','mercs'].includes(v)){
  let retreat=null;if(B.type==='land'&&heroPower(f,'perseus',pid)){const rs=retreatAreas(pid);if(rs.length)retreat=await ask(pid,'Perseus: retreat this casualty instead?', [...optsAreas(rs),{value:null,label:'Remove the casualty',score:-1}]);}
  f[v]--;if(retreat!==null){B.report?.events.push('Perseus saves a '+v+' casualty by retreating it.');const z=G.zones[retreat];z[v]++;if(z.owner===null){z.owner=pid;if(z.priestIcon)supplyCard(G.players[pid],'priests')}}
 }else if(v==='minotaur'){removeMonster(f.minotaur);f.minotaur=null}else{f.heroes=f.heroes.filter(h=>h.id!==v);logMsg(`${G.players[pid].name} loses ${HEROES.find(h=>h.id===v).name}.`)}syncDef();
}
async function retreatSide(side){
 const f=B[side],pid=B[side+'Id'],options=retreatAreas(pid);if(!options.length||forceSize(f)===(f.minotaur?1:0))return false;
 const enemy=B[side==='att'?'def':'att'];const want=forceSize(f)<forceSize(enemy)&&forceSize(f)<3;
 const id=await ask(pid,`${side==='def'?'Defender':'Attacker'}: retreat or continue?`,[{value:null,label:'Continue the battle',score:want?0:20},...optsAreas(options).map(o=>({...o,score:want?15:0}))]);if(id===null)return false;
 const z=G.zones[id];if(B.type==='sea')z.fleets+=f.troops;else{z.troops+=f.troops;z.mercs+=f.mercs;z.heroes.push(...f.heroes)}if(z.owner===null){z.owner=pid;if(z.priestIcon)supplyCard(G.players[pid],'priests')}B.report?.retreats.push(G.players[pid].name+' → '+z.name);f.troops=0;f.mercs=0;f.heroes=[];syncDef();logMsg(`${G.players[pid].name} retreats to ${z.name}.`);return true;
}
async function battle(p,from,to,f,type){
 B={type,fromId:from.id,toId:to.id,attId:p.id,defId:to.owner,att:f,def:battleForce(to,to.owner,type),round:1};
 B.report={place:to.name,type,att:p.name,def:G.players[B.defId].name,rounds:[],losses:{att:[],def:[]},retreats:[],events:[]};
 const defender=G.players[B.defId];
 if(type==='land'){
  if(heroPower(B.att,'pandora',B.attId)){B.att.mercs+=B.def.mercs;B.def.mercs=0}
  let hectorFirst=false;if(heroPower(B.def,'pandora',B.defId)&&heroPower(B.def,'hector',B.defId))hectorFirst=await ask(B.defId,'Choose your defensive Hero order',[{value:false,label:'Pandora, then Hector'},{value:true,label:'Hector, then Pandora'}]);
  if(!hectorFirst&&heroPower(B.def,'pandora',B.defId)){B.def.mercs+=B.att.mercs;B.att.mercs=0}
  if(heroPower(B.def,'hector',B.defId)&&(B.att.troops||B.att.mercs)){const options=[];if(B.att.troops)options.push({value:'troops',label:'Destroy an invading Troop'});if(B.att.mercs)options.push({value:'mercs',label:'Destroy an invading Mercenary'});const t=await ask(B.defId,'Hector strikes before battle',options);B.att[t]--;if(typeof geryonDeath==='function')geryonDeath();B.report.losses.att.push(t);B.report.events.push('Hector destroys an invading '+t+' before the first roll.');}
  if(hectorFirst){B.def.mercs+=B.att.mercs;B.att.mercs=0}
  syncDef();
 }
 while(forceSize(B.att)&&forceSize(B.def)){
  showBattle('Both armies prepare to roll.');if(human(B.attId)||human(B.defId))await ask(humanPid(),'Battle round '+B.round,[{value:'roll',label:'Roll battle dice'}]);
  const ad=await battleDie(B.attId,B.att),dd=await battleDie(B.defId,B.def),at=ad+battleStrength(B.att,B.attId,false),dt=dd+battleStrength(B.def,B.defId,true);
  B.report.rounds.push({round:B.round,ad,dd,at,dt});
  if(typeof animateBattleRound==='function')await animateBattleRound({round:B.round,ad,dd,at,dt});
  showBattle(`${p.name}: ${ad} + army = ${at}. ${defender.name}: ${dd} + army = ${dt}.`);
  const pa=heroPower(B.att,'penthesilea',B.attId),pd=heroPower(B.def,'penthesilea',B.defId);
  if(at>dt||at===dt&&pa&&!pd)await removeCasualty('def');else if(dt>at||dt===at&&pd&&!pa)await removeCasualty('att');else{await removeCasualty('att');await removeCasualty('def')}
  if(!forceSize(B.att)||!forceSize(B.def))break;
  B.forcedRetreat=at>dt&&heroPower(B.att,'achilles',B.attId)?'def':dt>at&&heroPower(B.def,'achilles',B.defId)?'att':null;const rd=await retreatSide('def');if(rd&&!forceSize(B.def))break;const ra=await retreatSide('att');if(ra&&!forceSize(B.att))break;B.round++;
 }
 const attWon=forceSize(B.att)>0&&!forceSize(B.def);syncDef();
 if(attWon){if(type==='sea'){to.owner=p.id;to.fleets=B.att.troops}else{to.troops=B.att.troops;to.mercs=B.att.mercs;to.heroes=[...B.att.heroes];B.transferred=true;await takeLand(p,to,B.defId)}logMsg(`${p.name} conquers ${to.name}.`)}else if(!forceSize(B.def)&&type==='sea')to.owner=null;
 const msg=attWon?`${p.name} takes ${to.name}.`:forceSize(B.def)?`${defender.name} holds ${to.name}.`:'Both forces are gone. The land control token remains; empty seas are unclaimed.';
 B.report.result=msg;B.report.winner=attWon?B.attId:forceSize(B.def)?B.defId:null;if(typeof animateBattleOutcome==='function')await animateBattleOutcome(attWon);G.lastBattle=JSON.parse(JSON.stringify(B.report));showBattle(msg);B=null;$('battle-modal').classList.remove('active');
}
function removeMonster(m){G.monsters=G.monsters.filter(x=>x!==m);discardCreature(CREATURES.find(c=>c.id===m.id))}
function monsterValid(c,z,pid,m=null){return (c.mini==='any'||c.mini==='owned'&&z.type==='land'&&z.owner===pid||c.mini===z.type)&&!G.monsters.some(x=>x!==m&&x.zone===z.id)}
async function activateMonster(m){
 const z=G.zones[m.zone];if(m.id==='kraken'){z.fleets=0;z.owner=null;logMsg(`The Kraken destroys every Fleet in ${z.name}.`)}
 if(m.id==='polyphemus'){
 while(true){const sources=z.adj.map(id=>G.zones[id]).filter(s=>s.type==='sea'&&s.fleets);if(!sources.length)break;
 const from=await ask(m.owner,'Polyphemus: choose which Fleet to displace next',optsAreas(sources)),s=G.zones[from];const targets=s.adj.map(id=>G.zones[id]).filter(t=>t.type==='sea'&&!seasBlocked(t)&&(t.owner===null||t.owner===s.owner));
 if(!targets.length){logMsg('Polyphemus destroys stranded Fleets.');s.fleets=0;s.owner=null;renderAll();if(!human(m.owner)&&!R.auto)await observation('Polyphemus destroys stranded Fleets.',s.id);continue}const to=await ask(m.owner,`Move a Fleet out of ${s.name}`,optsAreas(targets));G.zones[to].owner=s.owner;G.zones[to].fleets++;s.fleets--;if(!s.fleets)s.owner=null;logMsg('Polyphemus pushes a Fleet away.');renderAll();if(!human(m.owner)&&!R.auto)await observation('Polyphemus pushes a Fleet away.',to);
 }
 }
}
async function playCreature(p,c){
 if(!c)return;logMsg(`${p.name} calls upon ${c.name}.`);
 if(c.mini){const id=await ask(p.id,`Place ${c.name}`,optsAreas(G.zones.filter(z=>monsterValid(c,z,p.id))));if(id===null){discardCreature(c);return}const m={id:c.id,owner:p.id,zone:id};G.monsters.push(m);await activateMonster(m);return}
 if(c.id==='graeae')await gainIncome(p);
 if(c.id==='dryad'||c.id==='satyr'||c.id==='griffin'){
 const key=c.id==='dryad'?'priests':c.id==='satyr'?'phils':'gp';const candidates=G.players.filter(q=>q.id!==p.id&&!(key==='gp'&&typeof allied==='function'&&allied(p.id,q.id))&&(key==='gp'||q[key]>0));
 const id=await ask(p.id,'Choose the player affected',candidates.map(q=>({value:q.id,label:q.name,detail:key==='gp'?'Gold is hidden behind their screen.':`${q[key]} ${key==='phils'?'Philosophers':'Priestesses'}`,score:countMetropolises(q.id)})));
 if(id!==null){const q=G.players[id],n=key==='gp'?Math.floor(q.gp/2):1;q[key]-=n;p[key]+=n;if(key!=='gp'&&typeof cardGain16==='function')cardGain16(p,key,n);logMsg(key==='gp'?(p.id===0||q.id===0?`Griffin transfers ${n} gold from ${q.name} to ${p.name}.`:'Griffin transfers hidden gold between rivals.'):`${p.name} takes a ${key==='phils'?'Philosopher':'Priestess'} from ${q.name}.`)}
 }
 if(c.id==='harpy'){
 const id=await ask(p.id,'Harpy: choose a Troop to destroy',optsAreas(G.zones.filter(z=>z.type==='land'&&z.troops+z.mercs>0)).map(o=>({...o,score:G.zones[o.value].owner!==p.id?10:0})));
 if(id!==null){const z=G.zones[id];const choices=[];if(z.troops)choices.push({value:'troops',label:'Destroy a Troop'});if(z.mercs)choices.push({value:'mercs',label:'Destroy a Mercenary'});z[await ask(p.id,'Choose the troop type',choices)]--;if(typeof geryonDeath==='function')geryonDeath();}
 }
 if(c.id==='cyclops'){
 const choices=lands(p.id).filter(z=>typeof chironProtects!=='function'||!chironProtects(z)).flatMap(z=>z.bldgs.map((b,i)=>({value:{id:z.id,i},label:`${BN[b]} · ${z.name}`}))),v=await ask(p.id,'Cyclops: choose a Building to exchange',choices);
 if(v!==null){const z=G.zones[v.id],t=await ask(p.id,'Choose its replacement',TYPES.filter(t=>t!==z.bldgs[v.i]&&buildingCount(t)<10).map(t=>({value:t,label:BN[t],score:!getPlayerBuildings(p.id).includes(t)?3:0})));if(t){z.bldgs[v.i]=t;if(z.templeUses)z.templeUses[v.i]=false}}
 }
 if(c.id==='giant'){
 const id=await ask(p.id,'Giant: take Mercenaries from a Land Area',optsAreas(G.zones.filter(z=>z.type==='land'&&z.mercs)).map(o=>({...o,score:G.zones[o.value].owner!==p.id?10:0})));
 if(id!==null){let n=G.zones[id].mercs;G.zones[id].mercs=0;while(n--){const to=await ask(p.id,'Distribute a stolen Mercenary',optsAreas(lands(p.id)));if(to!==null)G.zones[to].mercs++}}
 }
 if(c.id==='pegasus')await move(p,'land',true);
 if(c.id==='sylph'){
 const zs=G.zones.filter(z=>z.type==='sea'&&z.fleets),a=await ask(p.id,'Sylph: select the first occupied Sea Area',optsAreas(zs));if(a!==null){const b=await ask(p.id,'Select the second occupied Sea Area',optsAreas(zs.filter(z=>z.id!==a)));if(b!==null){[G.zones[a].owner,G.zones[b].owner]=[G.zones[b].owner,G.zones[a].owner];[G.zones[a].fleets,G.zones[b].fleets]=[G.zones[b].fleets,G.zones[a].fleets]}}
 }
 if(c.id==='charon'){
 const hs=lands(p.id).flatMap(z=>z.heroes.map(h=>({value:{zone:z.id,id:h.id},label:h.name,image:h.id}))),a=G.heroes.length?await ask(p.id,'Charon: choose your Hero to exchange',hs):null;
 if(a){const b=await ask(p.id,'Choose a Hero from the track',G.heroes.map((h,i)=>({value:i,label:h.name,image:h.id})));if(b!==null){const z=G.zones[a.zone],i=z.heroes.findIndex(h=>h.id===a.id),old=z.heroes[i];if(typeof discardHeroCaptures==='function')discardHeroCaptures(old);z.heroes[i]={...G.heroes[b],summonedCycle:G.cycle};G.heroes[b]=HEROES.find(h=>h.id===old.id)}}
 }
 if(c.id==='chimera'){
 const i=await ask(p.id,'Chimera: play a Creature from the discard pile',G.discard.map((d,i)=>({value:i,label:d.name,image:d.id==='minotaur'?'minotaur-piece':d.id})));if(i!==null){const d=G.discard.splice(i,1)[0];await playCreature(p,d)}
 }
 if(c.id==='sphynx'){
 const cs=[drawCreature(),drawCreature(),drawCreature()].filter(Boolean),i=await ask(p.id,'Sphynx: play one of these Creatures',cs.map((d,i)=>({value:i,label:d.name,detail:d.desc,image:d.id==='minotaur'?'minotaur-piece':d.id})));
 cs.forEach((d,j)=>{if(j!==i)discardCreature(d)});if(i!==null)await playCreature(p,cs[i]);
 }
 discardCreature(c);await settle(p);
}
async function maintenance(){
 G.phase='MAINTENANCE';renderAll();
 for(const m of [...G.monsters]){const p=G.players[m.owner];let keep=false;if(p.priests)keep=await ask(p.id,`Maintain ${CREATURES.find(c=>c.id===m.id).name}?`,[{value:true,label:'Discard 1 Priestess to keep it',score:2},{value:false,label:'Dismiss this Creature',score:0}]);if(!keep){removeMonster(m);continue}p.priests--;
 const c=CREATURES.find(c=>c.id===m.id),zs=G.zones[m.zone].adj.map(id=>G.zones[id]).filter(z=>monsterValid(c,z,p.id,m));const id=await ask(p.id,'Optional maintenance movement',[{value:null,label:'Keep the Creature in place',score:2},...optsAreas(zs)]);if(id!==null){m.zone=id;await activateMonster(m)}
 }
}
async function removeBuildings(p,t,n){for(let k=0;k<n;k++){const candidates=lands(p.id).filter(z=>z.bldgs.includes(t));const id=candidates.length===1?candidates[0].id:await ask(p.id,`Choose ${BN[t]} to remove`,optsAreas(candidates));if(id===null)return;const z=G.zones[id];z.bldgs.splice(z.bldgs.indexOf(t),1);if(t==='T')z.templeUsed=false}}
async function sacrifice(p,z,h,effect=h.id){
 if(h.summonedCycle>=G.cycle||p.god==='APOLLO')return false;
 if(effect==='pandora'){const id=await ask(p.id,'Pandora: copy an available Hero’s sacrifice',G.heroes.filter(x=>x.id!=='pandora').map(x=>({value:x.id,label:x.name,detail:x.sac,image:x.id})));if(!id)return false;if(id==='penthesilea'){setPrompt('Pandora may copy Penthesilea when you build a Metropolis.');return false}return sacrifice(p,z,h,id)}
 if(['ajax','jason','croesus','odysseus','helen'].includes(effect)&&!canBuildMetro(p)){setPrompt('No construction site or eligible protection for a new Metropolis.');return false}
 const bs=getPlayerBuildings(p.id),counts=Object.fromEntries(TYPES.map(t=>[t,bs.filter(b=>b===t).length]));let ok=false,metro=true;
 if(effect==='ajax')ok=lands(p.id).length>=7;
 if(effect==='jason')ok=fleetCount(p.id)===8;
 if(effect==='croesus'&&p.gp>=15){spendGold(p,15);ok=true}
 if(effect==='odysseus'){const t=await ask(p.id,'Choose three identical Buildings',TYPES.filter(t=>counts[t]>=3).map(t=>({value:t,label:'3 '+BN[t]+'s'})));if(t){await removeBuildings(p,t,3);ok=true}}
 if(effect==='helen'){const a=await ask(p.id,'Choose the first pair of Buildings',TYPES.filter(t=>counts[t]>=2).map(t=>({value:t,label:'2 '+BN[t]+'s'})));if(a){const b=await ask(p.id,'Choose a different pair',TYPES.filter(t=>t!==a&&counts[t]>=2).map(t=>({value:t,label:'2 '+BN[t]+'s'})));if(b){await removeBuildings(p,a,2);await removeBuildings(p,b,2);ok=true}}}
 if(effect==='hector'){
 const max=Math.min(Math.floor(p.priests/2),20-G.players.reduce((s,q)=>s+q.phils,0));if(max){const n=await ask(p.id,'How many pairs of Priestesses will you exchange?',Array.from({length:max},(_,i)=>({value:i+1,label:`${(i+1)*2} Priestesses → ${i+1} Philosophers`,score:i})));p.priests-=n*2;supplyCard(p,'phils',n);ok=true;metro=false}
 }
 if(effect==='perseus'&&lands(p.id).some(l=>army(l)-(l===z?1:0)>0&&!medusa(l)&&landTargets(p,l,true).length)){ok=true;metro=false}
 if(!ok){setPrompt('The conditions for this sacrifice are not met.');return false}
 z.heroes.splice(z.heroes.indexOf(h),1);logMsg(`${p.name} sacrifices ${h.name}.`);
 if(metro)await constructMetro(p);if(effect==='perseus')await move(p,'land',true);await settle(p);return true;
}
function discountSlots(p){const list=[];for(const z of lands(p.id)){z.templeUses??=z.bldgs.map(b=>b==='T'&&!!z.templeUsed);z.bldgs.forEach((b,i)=>{if(b==='T'&&!(z.templeUses?z.templeUses[i]:z.templeUsed))list.push({z,i,type:'basic'})});z.metros.forEach((_,i)=>{if(!z.metroUsed[i])list.push({z,i,type:'metro'})})}p.protected.forEach((_,i)=>{if(!p.protectedUsed[i])list.push({p,i,type:'protected'})});return list}
creatureCost=(p,c)=>Math.max(0,c.cost-discountSlots(p).length);
async function purchaseCreature(p,i){const c=G.creatures[i];if(!c||p.god==='APOLLO')return;const slots=discountSlots(p),max=Math.min(c.cost,slots.length);if(p.gp<c.cost-max)return;
 const n=max;
 slots.slice(0,n).forEach(s=>{if(s.type==='basic'){s.z.templeUses??=[];s.z.templeUses[s.i]=true}else if(s.type==='metro')s.z.metroUsed[s.i]=true;else s.p.protectedUsed[s.i]=true});spendGold(p,c.cost-n);G.creatures.splice(i,1);await playCreature(p,c);
}
async function hireHero(p,i){if(G.turnState.hiredHero||p.gp<4||!G.heroes[i])return;const id=await ask(p.id,'Place your recruited Hero',optsAreas(lands(p.id)));if(id===null)return;spendGold(p,4);G.turnState.hiredHero=true;const h=G.heroes.splice(i,1)[0];G.zones[id].heroes.push({...h,summonedCycle:G.cycle});logMsg(`${p.name} recruits ${h.name} in ${G.zones[id].name}.`)}
async function zeusPeek(p){if(G.turnState.peeked)return;G.turnState.peeked=true;const c=G.deck[0];if(!c){setPrompt('The Creature deck is empty.');return}const play=await ask(p.id,`Zeus sees ${c.name}`,[{value:false,label:'Leave it face down on top',detail:c.desc,score:0},...(p.gp>=1?[{value:true,label:'Pay 1 gold to play it',detail:'Temple discounts do not apply.',image:c.id==='minotaur'?'minotaur-piece':c.id,score:3}]:[])]);if(play){spendGold(p,1);G.deck.shift();await playCreature(p,c)}}
async function setupGame(){
 const order=[...G.turnOrder];G.phase='SETUP';
 for(const pid of order){const p=G.players[pid];G.activeBidder=pid;let firstIsland=null;for(let k=0;k<2;k++){const zs=G.zones.filter(z=>z.type==='land'&&z.owner===null&&(k===0||z.island!==firstIsland)&&z.adj.some(id=>G.zones[id].type==='sea'&&G.zones[id].owner===null));const id=await ask(pid,`Found ${p.name} · choose Land ${k+1} of 2 on different islands`,optsAreas(zs));if(id===null)continue;const z=G.zones[id];z.owner=pid;if(z.priestIcon)supplyCard(p,'priests');if(k===0)firstIsland=z.island;const sea=await ask(pid,'Place a Fleet beside your new land',optsAreas(z.adj.map(id=>G.zones[id]).filter(s=>s.type==='sea'&&s.owner===null)));if(sea!==null){G.zones[sea].owner=pid;G.zones[sea].fleets=1}}}
 for(const pid of order.reverse()){const p=G.players[pid];G.activeBidder=pid;const zs=G.zones.filter(z=>z.type==='land'&&z.owner===null&&z.adj.some(id=>G.zones[id].type==='sea'&&G.zones[id].owner===null));const id=await ask(pid,`${p.name} · claim your third Land Area`,optsAreas(zs));if(id!==null){const z=G.zones[id];z.owner=pid;if(z.priestIcon)supplyCard(p,'priests');const sea=await ask(pid,'Place your third starting Fleet',optsAreas(z.adj.map(id=>G.zones[id]).filter(s=>s.type==='sea'&&s.owner===null)));if(sea!==null){G.zones[sea].owner=pid;G.zones[sea].fleets=1}}
 for(let n=0;n<3;n++)await recruit(p,'troops');}
 logMsg('Placement complete: 5 starting gold, 3 Troops and 3 Fleets per faction. Priestesses came from claimed symbols.');await newCycle(true);
}
function rotatePantheon(){const first=G.godQueue.shift();G.godQueue.push(first);G.godRotation={cycle:G.cycle,moved:first,order:[...G.godQueue]};}
function rotateCreatureTrack(first=false){
 const before=G.creatures.map(c=>({id:c.id,name:c.name,cost:c.cost}));let removed=null;
 if(!first){const cheap=G.creatures.findIndex(c=>c.cost===2);if(cheap>=0){removed=G.creatures.splice(cheap,1)[0];discardCreature(removed)}G.creatures.sort((a,b)=>a.cost-b.cost);G.creatures.forEach((c,i)=>c.cost=i+2)}
 while(G.creatures.length<4&&G.deck.length){const c=drawCreature();c.cost=G.creatures.length+2;G.creatures.push(c)}
 G.creatureRotation={cycle:G.cycle,before,removed:removed?.name||null,after:G.creatures.map(c=>({id:c.id,name:c.name,cost:c.cost}))};
}
async function newCycle(first=false){
 if(!first){G.cycle++;rotatePantheon()}rotateCreatureTrack(first);
 while(G.heroes.length<2&&G.heroDeck.length)G.heroes.push(G.heroDeck.shift());
 G.zones.forEach(z=>{z.templeUsed=false;z.templeUses=[];z.metroUsed=[]});G.players.forEach(p=>{p.protectedUsed=[];p.god=null;p.bid=0});G.openGods=G.godQueue.slice(0,Math.min(5,G.players.length-1));G.eliminatedThisCycle=false;
 G.phase='INCOME';for(const p of G.players)await gainIncome(p);G.phase='OFFERINGS';G.biddingQueue=[...G.turnOrder];G.lastKickedFrom={};G.apolloOrder=[];G.mode=null;advanceBid();
}
function advanceBid(){
 if(!G.biddingQueue.length){later(()=>runFlow(finalizeBids),80);return}G.activeBidder=G.biddingQueue[0];renderAll();const p=active();if(!human(p.id))later(()=>aiBid(p),300);else{switchTab('auction');setPrompt('Make your offering.');}
}
placeBid=function(pid,gid,amount){
 if(G.phase!=='OFFERINGS'||G.activeBidder!==pid||G.biddingQueue[0]!==pid)return;const p=G.players[pid],prev=getGodHolder(gid);
 if(gid==='APOLLO'){if(prev)return;amount=0}else if(!G.openGods.includes(gid)||gid===G.lastKickedFrom[pid]||amount<(prev?prev.bid+1:1)||amount>maximumOffer(p)||!Number.isInteger(amount))return;
 p.god=gid;p.bid=amount;G.biddingQueue.shift();logMsg(`${p.name} offers ${amount} gold to ${GOD_DATA[gid].name}.`);if(gid==='APOLLO')G.apolloOrder=[pid];
 if(prev){prev.god=null;prev.bid=0;G.lastKickedFrom[prev.id]=gid;G.biddingQueue.unshift(prev.id)}advanceBid();
};
function aiBid(p){
 if(G.phase!=='OFFERINGS'||G.activeBidder!==p.id)return;let choices=[];
 for(const gid of G.openGods){if(gid===G.lastKickedFrom[p.id])continue;const h=getGodHolder(gid),n=h?h.bid+1:1;if(n<=p.gp+p.priests){let score=8-n;const t={ARES:'F',POSEIDON:'P',ZEUS:'T',ATHENA:'U'}[gid];if(t&&!getPlayerBuildings(p.id).includes(t))score+=3;if(gid==='ATHENA')score+=p.phils*2;if(gid==='HERA')score+=2;choices.push({gid,n,score})}}
 if(!getGodHolder('APOLLO'))choices.push({gid:'APOLLO',n:0,score:2});choices.sort((a,b)=>b.score-a.score);if(choices.length)placeBid(p.id,choices[0].gid,choices[0].n);
}
async function finalizeBids(){
 const bad=G.players.find(p=>Math.max(0,p.bid-p.priests)>p.gp);if(bad){spendGold(bad,Math.floor(bad.gp/2));G.players.forEach(p=>{p.god=null;p.bid=0});G.biddingQueue=[...G.turnOrder];G.lastKickedFrom={};advanceBid();return}
 G.players.forEach(p=>{spendGold(p,Math.max(0,p.bid-p.priests))});G.actionOrder=G.openGods.map(g=>getGodHolder(g)?.id).filter(id=>id!==undefined);if(G.apolloOrder.length)G.actionOrder.push(...G.apolloOrder);G.turnOrder=[...G.actionOrder].reverse();switchTab('map');await maintenance();G.phase='ACTIONS';G.activePlayerIdx=0;later(()=>runFlow(beginTurn),80);
}
async function beginTurn(){
 if(G.activePlayerIdx>=G.actionOrder.length){await finishCycle();return}G.phase='ACTIONS';const p=G.players[G.actionOrder[G.activePlayerIdx]];if(!lands(p.id).length){G.activePlayerIdx++;return beginTurn()}G.activeBidder=p.id;G.turnState={recruitedCount:0,boughtExtraCard:false,hiredHero:false,peeked:false,heroMoves:{}};G.mode=null;switchTab('map');await mandatory(p);await settle(p);
 if(human(p.id))setPrompt(`${GOD_DATA[p.god].name}: choose an action, or end your turn.`);else later(()=>runFlow(()=>aiTurn(p)),120);
}
async function finishCycle(){
 const end=G.eliminatedThisCycle||G.players.some(p=>countMetropolises(p.id)>=3);
 if(end){G.phase='GAME_OVER';G.activeBidder=null;let best=Math.max(...G.players.map(p=>countMetropolises(p.id))),cs=G.players.filter(p=>countMetropolises(p.id)===best),gold=Math.max(...cs.map(p=>p.gp));cs=cs.filter(p=>p.gp===gold);setPrompt(`${cs.map(p=>p.name).join(' and ')} ${cs.length>1?'share victory':'wins'} with ${best} Metropolises.`);logMsg('Final treasuries are revealed: '+G.players.map(p=>`${p.name}: ${p.gp} gold`).join(' · '));switchTab('map');renderAll();return}await newCycle();
}
finishCurrentPlayerTurn=function(){if(!myAction())return;runFlow(async()=>{G.activePlayerIdx++;await beginTurn()})};
async function aiTurn(p){
 if(p.god!=='APOLLO'){
 if(['ATHENA','ZEUS'].includes(p.god)&&p.gp>=4){spendGold(p,4);supplyCard(p,p.god==='ATHENA'?'phils':'priests');await settle(p)}
 if(['ARES','POSEIDON','HERA'].includes(p.god)){const kind={ARES:'troops',POSEIDON:'fleets',HERA:'mercs'}[p.god],cost=p.god==='ARES'?2:1;if(p.gp>=cost)await recruit(p,kind,cost)}
 if(p.god==='HERA'&&p.gp>=4&&G.heroes.length)await hireHero(p,0);
 if(p.god==='ZEUS')await zeusPeek(p);
 const ci=G.creatures.findIndex(c=>creatureCost(p,c)<=p.gp&&['satyr','graeae','griffin','cyclops','dryad','harpy'].includes(c.id));if(ci>=0)await purchaseCreature(p,ci);
 for(const z of lands(p.id))for(const h of [...z.heroes])if(h.summonedCycle<G.cycle&&['croesus','hector','odysseus','helen','jason','ajax'].includes(h.id))await sacrifice(p,z,h);
 if(p.god==='ARES'&&p.gp>=1){const can=lands(p.id).some(z=>!medusa(z)&&army(z)>=2&&landTargets(p,z).some(t=>t.owner!==p.id&&army(t)<army(z)));if(can)await move(p,'land')}
 }
 await settle(p);G.activePlayerIdx++;later(()=>runFlow(beginTurn),150);
}
function userCommand(fn){if(!myAction())return;runFlow(async()=>{await fn(G.players[humanPid()]);await settle(G.players[humanPid()])})}
playerRecruitUnit=function(){userCommand(async p=>{const costs={ARES:[2,3,4],POSEIDON:[1,2,3],HERA:[1,3,5]},kind={ARES:'troops',POSEIDON:'fleets',HERA:'mercs'}[p.god],n=G.turnState.recruitedCount;if(!costs[p.god]||n>=3)return;if(await recruit(p,kind,costs[p.god][n]))G.turnState.recruitedCount++})};
playerBuyCard=function(){userCommand(async p=>{if(p.gp<4||G.turnState.boughtExtraCard||!['ZEUS','ATHENA'].includes(p.god))return;const key=p.god==='ZEUS'?'priests':'phils';if(supplyCard(p,key)){spendGold(p,4);G.turnState.boughtExtraCard=true}})};
startMoveMode=function(type){userCommand(p=>move(p,type))};
buyCreature=function(i){userCommand(p=>purchaseCreature(p,i))};recruitHero=function(i){userCommand(p=>hireHero(p,i))};
sacrificeHero=function(zid,hid){userCommand(p=>{const z=G.zones[zid],h=z.heroes.find(h=>h.id===hid);if(z.owner===p.id&&h)return sacrifice(p,z,h)})};
function recruitAt(id){userCommand(async p=>{const n=G.turnState.recruitedCount,cost={ARES:[2,3,4],POSEIDON:[1,2,3],HERA:[1,3,5]}[p.god]?.[n],kind={ARES:'troops',POSEIDON:'fleets',HERA:'mercs'}[p.god];if(cost!==undefined&&await recruit(p,kind,cost,id))G.turnState.recruitedCount++})}
function inspectZeus(){userCommand(zeusPeek)}
resetGame=function(){
 R.epoch++;if(R.pending){R.pending.reject(new Error('Game reset'));R.pending=null}timers.forEach(clearTimeout);timers.clear();R.busy=false;R.choiceMap=false;R.inspected=null;resetMapView();B=null;$('battle-modal').classList.remove('active');$('decision').classList.remove('active');
 const zones=makeRandomMap().map(z=>({...z,adj:[...z.adj],owner:null,troops:0,mercs:0,fleets:0,heroes:[],bldgs:[],metros:[],metro:false,templeUsed:false,metroUsed:[]}));
 G={cycle:1,phase:'SETUP',players:[{id:0,name:'Lion',color:'#eab308'},{id:1,name:'Scorpion',color:'#ef4444'},{id:2,name:'Eagle',color:'#a855f7'}].map(p=>({...p,isAI:p.id!==0,gp:5,priests:0,phils:0,protected:[],protectedUsed:[],god:null,bid:0})),zones,godQueue:shuffle(['ARES','POSEIDON','ZEUS','ATHENA','HERA']),openGods:[],turnOrder:shuffle([0,1,2]),biddingQueue:[],activeBidder:0,lastKickedFrom:{},actionOrder:[],activePlayerIdx:0,turnState:{heroMoves:{}},creatures:[],heroes:[],deck:shuffle(CREATURES.map(c=>({...c}))),discard:[],heroDeck:shuffle(HEROES.map(h=>({...h}))),metroDeck:shuffle(['gold','priest','prosperity','troops','fleets'].flatMap(t=>[t,t,t])),monsters:[],logs:[],apolloOrder:[],eliminatedThisCycle:false};
 G.openGods=G.godQueue.slice(0,Math.min(5,G.players.length-1));logMsg('New randomized archipelago. White borders separate areas; only shared edges connect them. One construction site per land.');renderAll();switchTab('map');later(()=>runFlow(setupGame),100);
};
let viewZoom=1,viewX=0,viewY=0;
function zoomMap(d){viewZoom=Math.min(2.7,Math.max(1,viewZoom+d));const w=560/viewZoom,h=690/viewZoom;viewX=Math.max(0,Math.min(560-w,viewX+(560/(viewZoom-d||1)-w)/2));viewY=Math.max(0,Math.min(690-h,viewY));$('archipelago').setAttribute('viewBox',`${viewX} ${viewY} ${w} ${h}`)}
function resetMapView(){viewZoom=1;viewX=0;viewY=0;$('archipelago').setAttribute('viewBox','0 0 560 690')}
$('map-view').insertAdjacentHTML('beforeend','<div class="map-tools"><button onclick="zoomMap(.35)" aria-label="Zoom in">+</button><button onclick="zoomMap(-.35)" aria-label="Zoom out">−</button><button onclick="resetMapView()" aria-label="Fit map">⌖</button></div>');
let dragged=false,gesture=null;const pointers=new Map();
let cameraFrame=null;
function flushCamera(){cameraFrame=null;$('archipelago').setAttribute('viewBox',`${viewX} ${viewY} ${560/viewZoom} ${690/viewZoom}`);const readout=$('zoom-readout');if(readout)readout.textContent=Math.round(viewZoom*100)+'%'}
function applyView(){viewX=Math.max(0,Math.min(560-560/viewZoom,viewX));viewY=Math.max(0,Math.min(690-690/viewZoom,viewY));if(typeof requestAnimationFrame==='function'){if(cameraFrame===null)cameraFrame=requestAnimationFrame(flushCamera)}else flushCamera()}
function startGesture(){const ps=[...pointers.values()];if(!ps.length){gesture=null;return}const a=ps[0],b=ps[1]||a;gesture={x:(a.x+b.x)/2,y:(a.y+b.y)/2,dist:Math.hypot(a.x-b.x,a.y-b.y),zoom:viewZoom,vx:viewX,vy:viewY,rect:$('archipelago').getBoundingClientRect()};}
// Pointer handlers are installed once by interface-v15.js.
onZoneClick=function(id){if(dragged){dragged=false;return}R.inspected=id;if(R.pending&&R.choiceMap){const i=R.pending.options.findIndex(o=>o.zone===id);if(i>=0){answerDecision(i);return}setPrompt(R.pending.title+' · Tap a highlighted space.');return}renderInspector();renderActionButtons();const z=G.zones[id];setPrompt(`${z.name} · ${z.type==='land'?z.troops+' troops, '+z.mercs+' mercenaries':z.fleets+' fleets'} · ${z.pros} Prosperity`)};
function availableZone(id){return R.pending&&R.choiceMap&&R.pending.options.some(o=>o.zone===id)}
function coastalPath(z){if(z.type==='sea')return z.path;const p=z.polygon,pts=[];for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];for(let k=0;k<4;k++){const t=k/4,x=a[0]+(b[0]-a[0])*t,y=a[1]+(b[1]-a[1])*t,s=.86+.025*Math.sin(i*17+k*13+z.id*2);pts.push([z.x+(x-z.x)*s,z.y+(y-z.y)*s])}}return 'M'+pts.map(p=>p.join(',')).join(' L')+' Z'}
renderMapSVG=function(){
 let s=MAP_DEFS+FACTION_DEFS+`<rect width="560" height="690" rx="14" fill="url(#ocean)"/><rect width="560" height="690" fill="url(#waves)" class="ocean-waves"/><rect x="7" y="7" width="546" height="676" rx="9" fill="none" stroke="#c4d7b744"/>`;
 for(const z of G.zones)s+=`<path d="${z.path}" fill="${z.type==='land'?'#a9cfb80a':'none'}" stroke="#c8e6da44" stroke-width=".85"/>`;
 if(R.inspected!==null){const z=G.zones[R.inspected];for(const id of z.adj){const t=G.zones[id];s+=`<path d="M${z.x} ${z.y}L${t.x} ${t.y}" stroke="#f6e2a5aa" stroke-dasharray="3 4" stroke-width="1.4"/>`}}
 for(const z of G.zones.filter(z=>z.type==='land')){const path=tileCoast(z);s+=`<path d="${path}" fill="none" stroke="#9ae4d7" stroke-width="9" opacity=".4"/><path d="${path}" transform="translate(0 4)" fill="#6a5834" stroke="#493f2e" stroke-width="3"/><path d="${path}" fill="url(#terrain)" stroke="#f5e5b2" stroke-width="2.4"/><path d="${path}" fill="url(#grain)"/>`+mountain(z.x+10,z.y-34,.65)+trees(z.x-24,z.y+28)+trees(z.x+25,z.y-27);}
 for(const z of G.zones){const land=z.type==='land',col=z.owner===null?'#cbbd91':G.players[z.owner].color,x=z.x,y=z.y,m=G.monsters.find(m=>m.zone===z.id);
 s+=`<g style="color:${col}" class="map-zone ${availableZone(z.id)?'available':''} ${R.inspected===z.id?'chosen':''}" role="button" tabindex="0" aria-label="${z.name}" onclick="onZoneClick(${z.id})" onkeydown="if(event.key==='Enter'){onZoneClick(${z.id})}"><path class="zone-hit" d="${z.path}"/><text x="${land?x:Math.max(55,Math.min(505,x))}" y="${land?y-14:Math.max(19,y-(x<50||x>510?48:17))}" text-anchor="middle" class="${land?'land-name':'sea-name'}">${z.name}</text>`;
 if(land){
 s+=`<circle cx="${x-14}" cy="${y+7}" r="13" fill="#14353b" stroke="${col}" stroke-width="2"/>${z.troops+z.mercs?`<use href="#warrior-${z.owner===null?0:z.owner}" x="${x-32}" y="${y-12}" width="36" height="40"/>`:""}<circle cx="${x-3}" cy="${y+16}" r="7" fill="${col}" stroke="#f0e2b1" stroke-width=".8"/><text x="${x-3}" y="${y+19}" font-size="9" font-family="Arial" text-anchor="middle" fill="#172b30">${z.troops+z.mercs}</text>`;
 if(z.mercs)s+=`<text x="${x-14}" y="${y+33}" text-anchor="middle" font-size="7" fill="#fff1cd" stroke="#274c42" stroke-width="1" paint-order="stroke">${z.mercs} merc.</text>`;
 if(z.metros.length)s+=`<use href="#city-piece" x="${x+6}" y="${y-2}" width="31" height="29"/>`;
 else if(z.bldgs.length)s+=`<use href="#building-${z.bldgs[0]}" x="${x+9}" y="${y+1}" width="24" height="24"/><text x="${x+21}" y="${y+33}" text-anchor="middle" font-size="8" fill="#fff0bf">${z.bldgs[0]}</text>`;
 else s+=`<path d="M${x+17} ${y+24}v-23l12 4-12 4" fill="${col}" stroke="#e6d8ad" stroke-width=".9"/><rect x="${x+9}" y="${y+28}" width="17" height="4" fill="#c3c09a" opacity=".8"/>`;
 if(z.heroes.length)s+=`<circle cx="${x+36}" cy="${y+25}" r="7" fill="#dfc88a"/><text x="${x+36}" y="${y+28}" text-anchor="middle" font-size="9" fill="#473720">★</text>`;
 }else if(z.fleets)s+=`<g style="color:${col}"><use href="#fleet-${z.owner}" x="${x-21}" y="${y-12}" width="40" height="39"/><circle cx="${x+16}" cy="${y+14}" r="8" fill="#102e37" stroke="${col}" stroke-width="1.5"/><text x="${x+16}" y="${y+17}" text-anchor="middle" class="unit-number">${z.fleets}</text></g>`;
 s+=`<text x="${x}" y="${y+(land?46:38)}" text-anchor="middle" font-family="Georgia" font-size="8" fill="#f0dfa4">${z.pros?'◉ '+z.pros:''}${z.priestIcon?'  ❧':''}</text>`;
 if(m)s+=`<image href="assets/${m.id==='minotaur'?'minotaur-piece':m.id}.webp" x="${x-18}" y="${y+34}" width="35" height="35"/><circle cx="${x+18}" cy="${y+56}" r="3" fill="${G.players[m.owner].color}"/>`;
 s+='</g>';
 }
 $('archipelago').innerHTML=s;
};
renderAuctionBoard=function(){
 const p=G.players[humanPid()],my=G.phase==='OFFERINGS'&&human(G.activeBidder)&&!R.pending;
 $('gods-container').innerHTML=G.openGods.map(gid=>{const g=GOD_DATA[gid],h=getGodHolder(gid),min=h?h.bid+1:1,max=maximumOffer(p),can=my&&gid!==G.lastKickedFrom[0]&&min<=max;return `<article class="god-slot" style="--god-color:${GOD_TONES[gid]}"><img class="god-portrait" src="assets/${gid.toLowerCase()}.webp" alt="${g.name}"><div class="god-subtitle">${GOD_EPITHETS[gid]}</div><div class="god-name">${g.name}</div><div class="bid-owner" style="color:${h?h.color:'#dfcaa0'}">${h?h.name+' · '+h.bid+' gold offered':'No offering'}</div><div class="god-desc"><b>${g.free}</b><br>${g.paid}</div>${can?`<div class="bid-controls"><label class="bid-input">Offer <input id="offer-${gid}" type="number" min="${min}" max="${max}" value="${min}" aria-label="Offer to ${g.name}"></label><button class="btn primary" onclick="submitOffer('${gid}')">Place offering</button></div><div class="god-desc">${p.priests} Priestess discount · maximum offer ${max}</div>`:''}</article>`}).join('')+`<div class="auction-divider">RESTING GODS · ROTATE ONE SLOT EACH CYCLE</div><div class="sleeping-gods">${G.godQueue.slice(2).map(gid=>`<div class="sleeping-god"><img src="assets/${gid.toLowerCase()}.webp" alt="">${GOD_DATA[gid].name}<small>FACE DOWN</small></div>`).join('')}</div><article class="god-slot apollo-slot" style="--god-color:${GOD_TONES.APOLLO}"><img class="god-portrait" src="assets/apollo.webp" alt="Apollo"><div class="god-name">Apollo</div><div class="god-desc">2 gold · 1 land Prosperity · 1 sea Prosperity.<br>No Creatures or Hero actions. First to offer next cycle.</div>${getGodHolder('APOLLO')?`<div class="bid-owner">Claimed by ${getGodHolder('APOLLO').name}</div>`:my?btn('Choose Apollo · Free',"placeBid(humanPid(),'APOLLO',0)",true,true):''}</article>`;
};
function submitOffer(gid){const input=$('offer-'+gid),n=Number(input.value);if(!Number.isInteger(n)||n<Number(input.min)||n>Number(input.max)){setPrompt('Choose a whole-number offering you can afford.');return}placeBid(humanPid(),gid,n)}
renderMarket=function(){const p=G.players[humanPid()],can=myAction()&&p.god!=='APOLLO';
 $('creature-market').innerHTML=G.creatures.map((c,i)=>{const price=creatureCost(p,c);return artCard(c.id==='minotaur'?'minotaur-piece':c.id,c.name,c.desc+`<br><b>Track ${c.cost} gold</b>${c.mini?' · Persistent; upkeep: 1 Priestess/cycle.':''}`,price,btn('Summon · '+price+' gold',`buyCreature(${i})`,can&&p.gp>=price,true),!!c.mini)}).join('')||'<div class="help">The Creature track is empty.</div>';
 $('hero-market').innerHTML=G.heroes.map((h,i)=>artCard(h.id,h.name,`<b>Military</b><br>${h.mil}<br><b>Sacrifice</b><br>${h.sac}`,4,btn('Recruit · 4 gold',`recruitHero(${i})`,can&&p.god==='HERA'&&!G.turnState.hiredHero&&p.gp>=4,true))).join('')||'<div class="help">No Heroes available.</div>';
 $('player-heroes').innerHTML=lands(humanPid()).flatMap(z=>z.heroes.map(h=>artCard(h.id,h.name,`<b>${h.mil}</b><br>${h.sac}`,null,h.id==='penthesilea'?'<div class="mc-body">Offered automatically when you build a Metropolis.</div>':btn('Heroic sacrifice',`sacrificeHero(${z.id},'${h.id}')`,can&&h.summonedCycle<G.cycle,true),false,z.name))).join('')||'<div class="help" style="grid-column:span 2">Recruit a Hero through Hera.</div>';
};
renderActionButtons=function(){let s='';if(R.pending){s=R.choiceMap?'<span class=map-instruction>Tap a glowing space</span>'+R.pending.options.map((o,i)=>o.zone===undefined?btn(o.label,`answerDecision(${i})`):'').join('')+btn('List view','showDecision()'):btn('Decision in progress','showDecision()',true,true)}else if(G.phase==='GAME_OVER')s=btn('Start a new campaign','resetGame()',true,true);else if(G.phase==='OFFERINGS')s=btn('Pantheon offerings',"switchTab('auction')",true,true);else if(!myAction())s='<span class="waiting-label">'+(G.phase==='SETUP'?'Founding the factions…':'Resolving '+(active()?.name||'the cycle')+'…')+'</span>';else{
 const p=G.players[humanPid()],n=G.turnState.recruitedCount,cs={ARES:[2,3,4],POSEIDON:[1,2,3],HERA:[1,3,5]};if(R.inspected!==null&&cs[p.god]&&n<3){const z=G.zones[R.inspected],fleet=p.god==='POSEIDON',valid=fleet?z.type==='sea'&&!seasBlocked(z)&&(z.owner===null||z.owner===humanPid())&&z.adj.some(id=>G.zones[id].type==='land'&&G.zones[id].owner===0):z.type==='land'&&z.owner===humanPid();if(valid)s+=btn('Recruit here · '+cs[p.god][n]+' gold',`recruitAt(${z.id})`,p.gp>=cs[p.god][n],true)}if(cs[p.god])s+=btn(n<3?`Recruit ${p.god==='POSEIDON'?'Fleet':p.god==='HERA'?'Mercenary':'Troop'} · ${cs[p.god][n]}`:'Recruitment limit reached','playerRecruitUnit()',n<3&&p.gp>=cs[p.god][n]);
 if(p.god==='ARES')s+=btn('March · 1 gold',"startMoveMode('land')",p.gp>=1);if(p.god==='POSEIDON')s+=btn('Sail · 1 gold',"startMoveMode('sea')",p.gp>=1);
 if(['ATHENA','ZEUS'].includes(p.god))s+=btn(p.god==='ATHENA'?'Philosopher · 4 gold':'Priestess · 4 gold','playerBuyCard()',!G.turnState.boughtExtraCard&&p.gp>=4);
 if(p.god==='ZEUS')s+=btn('Secret Creature draw','inspectZeus()',!G.turnState.peeked);
 if(p.god!=='ARES'&&p.god!=='APOLLO'&&lands(humanPid()).some(z=>z.heroes.length))s+=btn('Heroic move · 1, 2, 3…',"startMoveMode('land')",p.gp>=1);
 if(p.god!=='APOLLO')s+=btn('Myths & Heroes',"switchTab('market')");s+=btn('End turn','finishCurrentPlayerTurn()',true,true);
 }$('action-btns').innerHTML=s;
};
renderInspector=function(){if(!G.zones)return;const z=R.inspected===null?null:G.zones[R.inspected],p=G.players[humanPid()];$('inspector').innerHTML=z?`<div class="eyebrow">Territory intelligence</div><h2>${z.name}</h2><p>${z.owner===null?'Unclaimed':G.players[z.owner].name+' controls this area'}</p><div class="intel-stats"><div><strong>${z.type==='land'?z.troops+z.mercs:z.fleets}</strong><small>${z.type==='land'?'TROOPS + MERCENARIES':'FLEETS'}</small></div><div><strong>${z.pros}</strong><small>PROSPERITY</small></div></div>${z.type==='land'?`<p>${z.troops} Troops · ${z.mercs} Mercenaries</p><p>Construction: ${z.metros.length?'Metropolis ('+z.metros.join(', ')+')':z.bldgs.map(b=>BN[b]).join(', ')||'Empty site'}</p><p>Heroes: ${z.heroes.map(h=>h.name).join(', ')||'None'}</p>`:''}${minis(z).map(m=>`<div class="creature-presence"><img src="assets/${m.id==='minotaur'?'minotaur-piece':m.id}.webp"><p><b>${CREATURES.find(c=>c.id===m.id).name}</b><br>${CREATURES.find(c=>c.id===m.id).desc}<br>Controlled by ${G.players[m.owner].name}</p></div>`).join('')}<div class="intel-section">ADJACENT AREAS</div><p>${z.adj.map(id=>G.zones[id].name).join(' · ')}</p>`:`<div class="eyebrow">Your campaign</div><h2>Build your legend</h2><div class="inspector-art"></div><div class="intel-stats"><div><strong>${countMetropolises(humanPid())} / 3</strong><small>METROPOLISES</small></div><div><strong>${p.gp}</strong><small>YOUR PRIVATE GOLD</small></div></div><p>Gold stays behind each faction’s screen. Offerings and units are public.</p><div class="intel-section">YOUR RESERVE</div><p>${8-basicCount(humanPid())} Troops · ${8-fleetCount(humanPid())} Fleets<br>${16-mercCount()} shared Mercenaries available<br>${discountSlots(p).length} unused Temple discounts</p><div class="intel-section">LATEST EVENTS</div>${G.logs.slice(0,3).map(l=>`<div class="intel-event">${l}</div>`).join('')}`};
renderAll=function(){
 if(!G.players?.[0]?.protected)return;$('cycle-label').textContent='Cycle '+G.cycle;$('phase-label').textContent={SETUP:'Placement',INCOME:'Income',OFFERINGS:'Offerings',MAINTENANCE:'Upkeep',ACTIONS:'God actions',GAME_OVER:'Victory'}[G.phase];
 $('factions-hud').innerHTML=G.players.map(p=>{const gold=(p.controller===0||p.controller===undefined&&p.id===0)||G.phase==='GAME_OVER'?p.gp:'Hidden',bs=getPlayerBuildings(p.id);return `<div class="faction-card ${G.activeBidder===p.id?'active-turn':''}" style="--faction:${p.color}"><div class="f-header"><span><svg class="faction-emblem" viewBox="0 0 40 40"><use href="#crest-${p.id}"/></svg>${p.name} <small>${(p.controller===0||p.controller===undefined&&p.id===0)?'YOU':'AI'}</small></span><span class="metro-score">${p.god?`<img class="god-mini" src="assets/${p.god.toLowerCase()}.webp" alt="${GOD_DATA[p.god].name}">`:''}${icon('temple')}${countMetropolises(p.id)}/3</span></div><div class="f-stats"><span class="treasury ${p.id?'secret':''}" title="${p.id?'Behind their screen':'Your gold'}">${icon('coin','gold-icon')}${gold}</span><span title="Priestesses">${icon('leaf')}${p.priests}</span><span title="Philosophers">${icon('scroll')}${p.phils}</span></div><div class="f-bldgs">${TYPES.map(t=>`<span class="b-badge">${t} ${bs.filter(b=>b===t).length}</span>`).join('')}${p.protected.length?'<span class="b-badge">Protected '+p.protected.length+'</span>':''}</div></div>`}).join('');
 renderMapSVG();renderAuctionBoard();renderMarket();renderActionButtons();renderInspector();$('log-list').innerHTML=G.logs.map(l=>`<div class="log-entry">${l}</div>`).join('');
};
$('log-view').querySelector('.help').innerHTML='<b>Three-player rules · custom archipelago</b><br>Gold is secret; offers, cards and units are public. The map uses a six randomized macro tiles with connected territories and separate islands with one construction site per Land Area, not scans of the official tiles.<br>Setup: 5 gold, 3 Troops, 3 Fleets. Starting Priestesses come from claimed symbols. Goal: most Metropolises when the game ends; gold breaks a tie, then victory is shared.<br><b>Rules choices needing clarification:</b> the manual does not explicitly resolve every simultaneous Hero interaction. Pandora’s conversion resolves before Hector’s pre-battle strike; Helen’s fixed die remains 2 if Croesus rerolls it. Protected Metropolises provide the non-geographic Temple discount.';
$('welcome').querySelector('small').innerHTML='Three players · Hidden gold · Full Creature and Hero roster<br>Custom archipelago · Manual-based rules';
$('welcome').querySelector('p').innerHTML='Make secret plans. Win the gods’ favor.<br>Found an empire across the Aegean.';
$('auction-view').querySelector('.help').innerHTML='Each god—including Apollo—accepts one faction. Offer any affordable whole amount. The last god you were outbid on is temporarily unavailable to you. Offerings are public; treasuries stay hidden.';
resetMapView();resetGame();
