// Stable board rendering and a compact, touch-first campaign interface.
APP.labels=false;
APP.darkTheme??=false;
APP.condensed??=false;
APP.watchCPU??=true;
setupConfig.bidding??='exponential';
const UI_ICONS={
 compass:'<circle cx="12" cy="12" r="10"/><path d="M12 1v3M12 20v3M1 12h3M20 12h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2M15.5 5.5 13 13l-7.5 5.5L10 10Z"/><circle cx="12" cy="12" r="1.5"/>',
 globe:'<circle cx="12" cy="12" r="10"/><ellipse cx="12" cy="12" rx="4.5" ry="10"/><path d="M2 12h20M4 6h16M4 18h16"/>',
 map:'<path d="m2 5 6-3 8 3 6-3v17l-6 3-8-3-6 3ZM8 2v17M16 5v17"/>',
 gods:'<path d="m14 1-9 13h7l-2 9 9-14h-7Z"/>',
 creatures:'<path d="M5 7 2 2l8 4h4l8-4-3 5 2 6-4 8H7l-4-8Z M6 11l4 2m8-2-4 2M9 18l3-2 3 2"/>',
 heroes:'<path d="M5 14V9a7 7 0 0 1 14 0v5l-3 2v6h-4v-9H5ZM6 8h12M8 2l1-1h8l3 5M5 14l3 8"/>',
 follow:'<rect x="2" y="5" width="14" height="14" rx="2"/><path d="m16 9 6-4v14l-6-4M6 12h6m-3-3v6"/>',
 home:'<path d="M2 9 12 2l10 7M4 10v12h16V10M9 22v-8h6v8M2 12H0"/>',
 settings:'<path d="m9 2-1 3-3 1-2 3 2 3-2 3 2 3 3 1 1 3h6l1-3 3-1 2-3-2-3 2-3-2-3-3-1-1-3Z"/><circle cx="12" cy="12" r="3"/>'
};
function uiIcon(name){return `<svg viewBox="0 0 24 24" class="nav-icon" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${UI_ICONS[name]||UI_ICONS.map}</svg>`}
// Match the incoming SVG against live nodes: unchanged artwork never detaches or reloads.
const boardMarkup=new Map();let boardIdentity=null;
PERF.nodePatches=0;PERF.nodeReuses=0;
function patchSVGNode(live,fresh){
 if(live.nodeType!==fresh.nodeType||live.nodeName!==fresh.nodeName){live.replaceWith(fresh);PERF.nodePatches++;return fresh}
 if(live.nodeType===3){if(live.nodeValue!==fresh.nodeValue)live.nodeValue=fresh.nodeValue;return live}
 for(const a of Array.from(live.attributes||[]))if(!fresh.hasAttribute(a.name))live.removeAttribute(a.name);
 for(const a of Array.from(fresh.attributes||[]))if(live.getAttribute(a.name)!==a.value)live.setAttribute(a.name,a.value);
 const olds=Array.from(live.childNodes||[]),news=Array.from(fresh.childNodes||[]);
 for(let i=0;i<news.length;i++){if(olds[i])patchSVGNode(olds[i],news[i]);else live.appendChild(news[i])}
 for(let i=news.length;i<olds.length;i++)olds[i].remove();
 PERF.nodePatches++;return live;
}
function reconcileBoard(markup){
 const root=typeof cameraScene==='function'?cameraScene():$('archipelago');
 if(!document.createElementNS||!root.children){root.innerHTML=markup;return}
 if(boardIdentity!==G.zones){root.innerHTML=markup;boardIdentity=G.zones;boardMarkup.clear();return}
 const fresh=document.createElementNS('http://www.w3.org/2000/svg','svg');fresh.innerHTML=markup;
 // Dynamic decorations are owned by their rendering layer, not the static board.
 root.querySelectorAll('.staged-outline,.route-preview').forEach(n=>n.remove());
 const oldNodes=Array.from(root.children),newNodes=Array.from(fresh.children);
 for(let i=0;i<newNodes.length;i++){
  const n=newNodes[i],key=n.id||'static-'+i,source=n.outerHTML,old=oldNodes[i];
  if(old&&old.nodeName===n.nodeName&&(!n.id||old.id===n.id)){
   if(boardMarkup.get(key)===source){PERF.nodeReuses++;continue}
   patchSVGNode(old,n);
  }else if(old)old.replaceWith(n);else root.appendChild(n);
  boardMarkup.set(key,source);
 }
 for(let i=newNodes.length;i<oldNodes.length;i++)oldNodes[i].remove();
}
// Camera frames only write a viewBox. No map generation, layout reads or settings writes.
flushCamera=function(){cameraFrame=null;const value=`${viewX} ${viewY} ${560/viewZoom} ${690/viewZoom}`;if(mapEl.getAttribute('viewBox')!==value)mapEl.setAttribute('viewBox',value)};
let followCamera=true,lastFollowZone=null;
function releaseCamera(){if(!watching)return;followCamera=false;cameraTweenToken++;syncFollowControl()}
function syncFollowControl(){const el=$('follow-camera');if(el)el.hidden=!watching||followCamera}
function resumeFollowCamera(){followCamera=true;syncFollowControl();const z=G.zones[lastFollowZone];if(z)animateCamera({zoom:1.9,x:z.x-280/1.9,y:z.y-345/1.9},350)}
mapEl.addEventListener('wheel',releaseCamera,{capture:true,passive:true});
mapEl.addEventListener('pointermove',()=>{if(dragged&&pointers.size)releaseCamera()},{capture:false});
mapEl.addEventListener('keydown',e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Home','+','-','='].includes(e.key))releaseCamera()});
const followAwareCamera=animateCamera;animateCamera=function(target,ms){if(watching&&!followCamera)return Promise.resolve();return followAwareCamera(target,ms)};
observation=async function(text,zone=null){if(R.auto)return;const epoch=R.epoch;lastFollowZone=zone;syncFollowControl();if(followCamera)switchTab('map');$('ai-caption').textContent=text;$('ai-caption').hidden=false;setPrompt(text);if(zone!==null&&G.zones[zone]&&followCamera){const z=G.zones[zone];await animateCamera({zoom:1.9,x:z.x-280/1.9,y:z.y-345/1.9},450)}renderAll();await new Promise(resolve=>setTimeout(resolve,Math.max(700,Number(APP.aiDelay)||1400)));if(epoch!==R.epoch)throw Error('Campaign changed')};
const streamlinedTurn=beginTurn;beginTurn=async function(){const pid=G.actionOrder[G.activePlayerIdx];if(pid!==undefined&&human(pid)){followCamera=true;syncFollowControl()}return streamlinedTurn()};
// Screen controls stay outside the map canvas, including in fullscreen.
document.querySelector('.map-tools').innerHTML=`<button onclick="releaseCamera();resetMapView()" aria-label="Reset map view" title="Reset map view">${uiIcon('compass')}</button><button id="full-map-control" onclick="toggleFullMap()" aria-label="Fullscreen map" title="Fullscreen map">${uiIcon('globe')}</button><button id="follow-camera" onclick="resumeFollowCamera()" aria-label="Resume cinematic camera" title="Resume cinematic camera" hidden>${uiIcon('follow')}</button>`;
document.querySelector('.nav-tabs').innerHTML=['map','gods','creatures','heroes'].map((k,i)=>`<button class="nav-tab" onclick="${i<2?`switchTab('${i?'auction':'map'}')`:`openMarket('${k}')`}">${uiIcon(k)}<span>${['Map','Gods','Creatures','Heroes'][i]}</span></button>`).join('');
document.querySelector('.cycle-bar').innerHTML=`<span id="cycle-label"></span><span class="phase-pill" id="phase-label"></span><span id="personal-gold" aria-label="Your gold"></span><div class="cycle-meta"><button class="top-control" onclick="showAppPanel('settings')" aria-label="Settings">${uiIcon('settings')}</button><button class="top-control" onclick="returnToTitle()" aria-label="Return to title screen">${uiIcon('home')}</button></div>`;
function returnToTitle(){document.body.classList.add('title-active');closeAppPanel();if(fullMap)toggleFullMap();checkpointGame();$('welcome').hidden=false}
// Preserve the in-memory campaign (including pending decisions) when visiting the title.
const setupEntry=enterGame;enterGame=function(){document.body.classList.remove('title-active');if(G.config&&G.phase!=='GAME_OVER'){$('welcome').hidden=true;renderAll()}else setupEntry()};
function syncFullscreenButton(){const el=$('full-map-control');if(el){el.innerHTML=uiIcon('globe');el.setAttribute('aria-pressed',String(fullMap));el.setAttribute('aria-label',fullMap?'Exit fullscreen map':'Fullscreen map')}}
toggleFullMap=function(){fullMap=!fullMap;cinematicMap=false;document.body.classList.remove('cinematic-map');document.body.classList.toggle('full-map',fullMap);if(fullMap){switchTab('map');document.documentElement?.requestFullscreen?.().catch(()=>{})}else if(document.fullscreenElement)document.exitFullscreen?.().catch(()=>{});syncFullscreenButton();applyView()};
document.addEventListener?.('fullscreenchange',syncFullscreenButton);
switchTab=function(tab){if(!['map','auction','market','log'].includes(tab))return;displayedTab=tab;cancelMapGesture();closeSpacePopover();document.body.dataset.tab=tab;document.body.classList.toggle('auction-active',tab==='auction');for(const name of ['auction','market','log'])$(name+'-view').classList.toggle('active',name===tab);document.querySelectorAll('.nav-tab').forEach((el,i)=>el.classList.toggle('active',i===({map:0,auction:1,market:marketTab==='heroes'?3:2}[tab])));if(tab==='auction')renderAuctionBoard();if(tab==='market')renderMarket();if(tab==='log')filterChronicle($('chronicle-filter')?.value||'');livingBoard()};
// No per-piece color filters on the camera path. Original shaded artwork stays intact.
const outlinedImage=paintedImage;paintedImage=function(name,...args){const s=outlinedImage(name,...args);return name.startsWith('building-')?s.replace('<image ',`<image style="--building-outline:${BUILD_COLORS[name.at(-1)]}" `):s};
const sparseProsperity=prosperityStrip;prosperityStrip=function(z,x,y){return z.type==='sea'&&!z.pros?'':sparseProsperity(z,x,y)};
const fullPieces=renderIndividualPieces;renderIndividualPieces=function(z,x,y){
 if(!APP.condensed)return fullPieces(z,x,y);
 const sea=z.type==='sea',units=[];
 if(sea?z.fleets:z.troops)units.push({kind:sea?'fleet':'troop',n:sea?z.fleets:z.troops,src:factionAsset(z.owner,sea?'fleet':'warrior')});
 if(z.mercs)units.push({kind:'mercenary',n:z.mercs,src:factionAsset(z.owner,'warrior')});
 for(const h of z.heroes||[])units.push({kind:'hero',n:1,src:'assets/figures/'+h.id+'.webp',name:h.name});
 for(const m of minis(z))units.push({kind:'creature',n:1,src:'assets/figures/'+m.id+'.webp',pid:m.owner});
 const positions=piecePositions(z,units.length,x,y),op=ownerPosition(z);
 let s=!sea&&!z.troops&&z.owner!==null?`<image class="ownership-token" href="${factionAsset(z.owner,'owner')}" x="${op.x-10}" y="${op.y-10}" width="20" height="20"/>`:'';
 return s+units.map((u,i)=>{const p=positions[i];return `<g class="individual-piece ${u.kind}-piece" data-piece="${u.kind}" data-piece-index="${i}" data-faction="${u.pid??z.owner}"><image class="${u.kind==='mercenary'?'mercenary-sprite':''}" href="${u.src}" x="${p.x-p.w/2}" y="${p.y-p.h/2}" width="${p.w}" height="${p.h}"/><text class="unit-count" x="${p.x}" y="${p.y+p.h/2+6}" text-anchor="middle">${u.n}</text></g>`}).join('');
};
function powerText(u){return u.mil?`<p><b>Military</b> ${u.mil}</p><p><b>Sacrifice</b> ${u.sac}</p>`:`<p>${u.desc}</p>${u.mini?'<small>Upkeep: 1 Priestess each cycle.</small>':''}`}
renderMarket=function(){const p=G.players[humanPid()],can=myAction()&&p.god!=='APOLLO',panel=$('market-view').querySelector('.panel-inner');panel.classList.add('market-fit');
 const card=(u,action,ok,price)=>`<article class="power-card"><img decoding="async" src="${typeof unitCardPath==='function'?unitCardPath(u.id):'assets/cards/'+(u.id==='minotaur'?'minotaur-piece':u.id)+'.webp'}" alt="${u.name}"><div class="power-card-text"><h4>${u.name}</h4>${powerText(u)}</div>${btn(price,action,ok,true)}</article>`;
 const html=marketTab==='creatures'?`<div class="power-market creature-powers">${[2,3,4,5].map(cost=>{const i=G.creatures.findIndex(c=>c.cost===cost),u=G.creatures[i];return `<section><div class="market-price">${cost} gold slot</div>${u?card(u,`buyCreature(${i})`,can&&(u.reservedBy===undefined||u.reservedBy===p.id)&&p.gp>=creatureCost(p,u),(u.reservedBy!==undefined?'Reserved · ':'Summon · ')+creatureCost(p,u)+' gold'):'<div class="market-empty">Empty slot</div>'}</section>`}).join('')}</div>`:`<h3>Heroes · Hera</h3><div class="power-market hero-powers">${G.heroes.map((u,i)=>card(u,`recruitHero(${i})`,can&&p.god==='HERA'&&!G.turnState.hiredHero&&p.gp>=4,'Recruit · 4')).join('')||'<p>No available Heroes.</p>'}</div><div class="owned-hero-strip">${lands(p.id).flatMap(z=>z.heroes.map(h=>`<button onclick="showOwnedHero(${z.id},'${h.id}')"><img src="assets/figures/${h.id}.webp" alt="">${h.name}</button>`)).join('')}</div>`;
 if(panel._marketMarkup!==html){panel.innerHTML=html;panel._marketMarkup=html;}
};
showUnitInfo=function(id){const u=HEROES.find(h=>h.id===id)||CREATURES.find(c=>c.id===id);if(!u)return;showAppPanel('unit');$('app-panel-title').textContent=u.name;$('app-panel-content').innerHTML=`<article class="map-power-card"><img src="assets/${id==='minotaur'?'minotaur-piece':id}.webp" alt="${u.name}"><div><h2>${u.name}</h2>${powerText(u)}</div></article>`};
showPieceLegend=function(){showAppPanel('legend');$('app-panel-title').textContent='Piece legend';$('app-panel-content').innerHTML=`<div class="piece-legend">${G.players.map(p=>`<article><img src="${factionAsset(p.id,'owner')}" class="legend-owner" alt="${p.name}"><h4>${p.name}</h4><figure><img src="${factionAsset(p.id,'warrior')}" alt=""><figcaption>Troop</figcaption></figure><figure><img src="${factionAsset(p.id,'fleet')}" alt=""><figcaption>Fleet</figcaption></figure></article>`).join('')}</div><p>${APP.condensed?'Numbered view: one figure per unit type; the number is its quantity. Heroes and Creatures remain individual.':'Figure view: each miniature represents one unit.'}</p><div class="legend-types"><figure><img class="mercenary-sprite" src="${factionAsset(humanPid(),'warrior')}" alt=""><figcaption>Mercenary · pale figure</figcaption></figure>${['M','T','P','F','U'].map(t=>`<figure><img src="${PAINT}building-${t}.webp" style="--building-outline:${BUILD_COLORS[t]}" class="building-sprite" alt=""><figcaption>${t==='M'?'Metropolis':BN[t]}</figcaption></figure>`).join('')}</div><p>Faction tokens mark held land without a Troop. Heroes and Creatures use their own miniatures; tap them for powers.</p><p>${tabletopIcon('horn')} Offering / prosperity · ${tabletopIcon('priest')} Priestess spot · diamond: building site · rivers divide land; sea foam and light seam lines divide water.</p>`};
// Brief map inspection never resolves or discards Hera/Sphynx choices.
function inspectDecisionMap(){if(!R.pending)return;$('decision').classList.remove('active');switchTab('map');setPrompt('Review the map, then return to your choice.');renderActionButtons()}
const mapAwareAsk=ask;ask=function(pid,title,options,extra=''){const pending=mapAwareAsk(pid,title,options,extra);if(human(pid)&&R.pending&&/Hera: choose|Sphynx: play|Chimera|Zeus:|Peek/i.test(title)){$('decision-map').hidden=false;$('decision-map').textContent='Look at map';$('decision-map').setAttribute('onclick','inspectDecisionMap()')}else if(R.pending){$('decision-map').textContent='Choose on the map';$('decision-map').setAttribute('onclick','chooseOnMap()')}return pending};
const cleanActions=renderActionButtons;renderActionButtons=function(){cleanActions();const el=$('action-btns');el.innerHTML=el.innerHTML.replace(/<button\b[^>]*onclick="(?:openForceFan|explainSpaceAction|focusZone|showForceSheet)[^"]*"[^>]*>[\s\S]*?<\/button>/g,'').replace(/<button\b[^>]*onclick="openMarket\('creatures'\)"[^>]*>[\s\S]*?<\/button>/g,'');if(R.pending&&!R.choiceMap)el.innerHTML=btn('Return to choice','showDecision()',true,true);};
function setUIOption(key,value){APP[key]=value;APP.labels=false;saveSettings();document.body.classList.toggle('dark-theme',APP.darkTheme);if(key==='condensed'){mapSignature=null;renderMapSVG()}}
const streamlinedSettings=showAppPanel;showAppPanel=function(tab='settings'){streamlinedSettings(tab);$('app-panel-title').textContent=tab==='settings'?'Settings':'Campaign tools';if(tab==='settings')$('app-panel-content').insertAdjacentHTML('afterbegin',`<h3>Display & battles</h3>${[['darkTheme','Dark theme'],['condensed','Numbered unit view'],['watchCPU','Watch computer battles']].map(([k,label])=>`<label class="setting-row">${label}<input type="checkbox" ${APP[k]?'checked':''} onchange="setUIOption('${k}',this.checked)"></label>`).join('')}`)};
// All factions expose only public counters. Your treasury remains available once, above.
function renderCompactHUD(){const html=G.players.map(p=>`<div class="faction-card compact-faction ${p.id===G.activeBidder?'active-turn':''}" style="--faction:${p.color}" aria-label="${p.name}${p.controller===0?' — you':''}"><img class="player-token" src="${factionAsset(p.id,'owner')}" alt="${p.name}"><div class="public-counters"><span title="Metropolises">${tabletopIcon('T',14)}${countMetropolises(p.id)}</span><span title="Priestesses">${tabletopIcon('priest',14)}${p.priests}</span><span title="Philosophers">${tabletopIcon('U',14)}${p.phils}</span></div></div>`).join('');if($('factions-hud').innerHTML!==html)$('factions-hud').innerHTML=html;document.querySelector('.top-hud').style?.setProperty('--players',G.players.length);$('personal-gold').innerHTML=`${tabletopIcon('coin',16)} ${G.players[humanPid()].gp}`}
// Replace the stack of unconditional panel renders with one visible-panel pass.
renderAll=function(){if(!G.players?.[0]?.protected)return;$('cycle-label').textContent='Cycle '+G.cycle;$('phase-label').textContent={SETUP:'Placement',INCOME:'Income',OFFERINGS:'Offerings',MAINTENANCE:'Upkeep',ACTIONS:'God actions',GAME_OVER:'Finished'}[G.phase];renderCompactHUD();renderMapSVG();if(displayedTab==='auction')renderAuctionBoard();if(displayedTab==='market')renderMarket();renderActionButtons();if(displayedTab==='log')filterChronicle($('chronicle-filter')?.value||'');if($('turn-checklist'))$('turn-checklist').textContent='';syncFollowControl();livingBoard();checkpointGame();renderEndState()};
// Income numbers float from the receiving faction without changing game timing.
const incomeAnimation=gainIncome;gainIncome=async function(p){const n=income(p.id),out=await incomeAnimation(p);if(!R.auto&&document.createElement){const el=document.createElement('div');el.className='income-float';el.textContent='+'+n;el.style.setProperty('--seat',p.id);el.style.setProperty('--players',G.players.length);el.setAttribute('aria-label',p.name+' gains '+n+' gold');document.body.appendChild(el);if(FX.reduced)setTimeout(()=>el.remove(),1400);else launchPresentation(el,[{opacity:0,transform:'translateY(15px)'},{opacity:1,transform:'translateY(0)',offset:.2},{opacity:1,offset:.7},{opacity:0,transform:'translateY(-30px)'}],1900)}return out};
function humanWon(){if(G.teams){const rows=G.teams.map((t,i)=>({team:i,gold:t.gold,n:G.players.filter(p=>p.team===i).reduce((a,p)=>a+countMetropolises(p.id),0)})),max=Math.max(...rows.map(t=>t.n)),gold=Math.max(...rows.filter(t=>t.n===max).map(t=>t.gold));return rows.some(t=>t.n===max&&t.gold===gold&&G.players.some(p=>p.controller===0&&p.team===t.team))}const max=Math.max(...G.players.map(p=>countMetropolises(p.id))),gold=Math.max(...G.players.filter(p=>countMetropolises(p.id)===max).map(p=>p.gp));return G.players.some(p=>(p.controller===0||p.controller===undefined&&p.id===0)&&countMetropolises(p.id)===max&&p.gp===gold)}
let endedBoard=null;
function renderEndState(){if(G.phase!=='GAME_OVER'||R.auto||endedBoard===G.zones)return;endedBoard=G.zones;const win=humanWon();if(!document.createElement)return;const el=document.createElement('section');el.id='end-celebration';el.className='end-celebration '+(win?'victory':'defeat');el.innerHTML=`<div class="end-banner"><h1>${win?'VICTORY':'DEFEAT'}</h1><p>${win?'The Aegean celebrates your triumph.':'Your rivals have claimed the Aegean.'}</p>${btn('View final map',"document.getElementById('end-celebration').remove()")}${btn('New campaign',"document.getElementById('end-celebration').remove();openSetup()",true,true)}</div>`+(win?Array.from({length:36},(_,i)=>`<i class="confetti" style="--i:${i};--color:${['#e7bf50','#f5ede0','#49b9ba','#b370d1'][i%4]}"></i>`).join('')+Array.from({length:7},(_,i)=>`<i class="balloon" style="--i:${i};--color:${['#e7bf50','#ad6cd0','#45bfc0'][i%3]}"></i>`).join(''):'');document.body.appendChild(el)}
function cpuBattle(){return B&&!human(B.attId)&&!human(B.defId)}
const watchBattle=showBattle;showBattle=function(msg){if(cpuBattle()&&!APP.watchCPU){$('battle-modal').classList.remove('active');return}watchBattle(msg)};
const watchRound=animateBattleRound;animateBattleRound=async function(roll){if(cpuBattle()&&!APP.watchCPU){B.lastRoll={...roll};return}return watchRound(roll)};
const watchOutcome=animateBattleOutcome;animateBattleOutcome=async function(won){if(cpuBattle()&&!APP.watchCPU)return;return watchOutcome(won)};
// CPU decisions remain automatic, and never switch the camera behind an open battle.
const battleObservation=observation;observation=async function(text,zone){if(cpuBattle()){if(APP.watchCPU){$('battle-cinematic-status').textContent=text;await cinemaPause(700)}return}return battleObservation(text,zone)};
// A unique synthesized voice for every creature; nodes disconnect after playing.
const CREATURE_VOICES={charon:[85,170,'triangle',.8,3],chimera:[130,45,'sawtooth',.9,5],cyclops:[62,34,'square',.65,2],dryad:[700,1000,'sine',.8,4],giant:[45,25,'triangle',1,2],griffin:[780,210,'sawtooth',.7,3],harpy:[1400,380,'triangle',.55,5],graeae:[310,370,'sine',1,3],pegasus:[420,920,'triangle',.9,4],satyr:[390,580,'square',.55,5],sphynx:[190,280,'sine',1.1,4],sylph:[1100,1700,'sine',.7,2],cerberus:[95,55,'sawtooth',.7,3],hydra:[150,80,'sawtooth',1.2,6],kraken:[38,75,'triangle',1.3,4],medusa:[1800,600,'sawtooth',.75,2],minotaur:[75,110,'square',.65,3],polyphemus:[55,30,'triangle',1.1,1]};
function playCreatureVoice(id){if(R.auto||!APP.sound||!CREATURE_VOICES[id]||!globalThis.AudioContext&&!globalThis.webkitAudioContext)return;try{foleyContext??=new(globalThis.AudioContext||globalThis.webkitAudioContext)();foleyContext.resume?.();const [from,to,type,duration,pulses]=CREATURE_VOICES[id],now=foleyContext.currentTime,mix=foleyContext.createGain();mix.gain.value=soundGain('Battle')*.22;mix.connect(foleyContext.destination);for(let i=0;i<pulses;i++){const o=foleyContext.createOscillator(),g=foleyContext.createGain(),start=now+i*duration/pulses,len=duration/pulses*.9;o.type=type;o.frequency.setValueAtTime(from*(1+i*.07),start);o.frequency.exponentialRampToValueAtTime(to,start+len);g.gain.setValueAtTime(.001,start);g.gain.exponentialRampToValueAtTime(.55,start+.02);g.gain.exponentialRampToValueAtTime(.001,start+len);o.connect(g);g.connect(mix);o.start(start);o.stop(start+len+.02);o.onended=()=>{o.disconnect();g.disconnect();if(i===pulses-1)mix.disconnect()}}}catch{}}
const creatureWithVoice=playCreature;playCreature=async function(p,c){playCreatureVoice(c.id);return creatureWithVoice(p,c)};
document.body.classList.toggle('dark-theme',APP.darkTheme);
mapSignature=null;renderAll();syncFullscreenButton();
// Printed offering track (manual p4); fine bidding is the optional whole-gold variant.
const OFFER_TRACK=[0,1,2,3,5,7,10,15,20,25];
function exponentialBidding(){return (G.config?.bidding||'exponential')==='exponential'}
function legalOffers(p,gid){const holder=getGodHolder(gid),min=holder?holder.bid+1:1,max=maximumOffer(p);if(exponentialBidding())return OFFER_TRACK.filter(n=>n>=min&&n<=max);const length=Math.max(0,max-min+1);return {0:length?min:undefined,length,includes:n=>Number.isInteger(n)&&n>=min&&n<=max,indexOf:n=>Number.isInteger(n)&&n>=min&&n<=max?n-min:-1,at:i=>{const j=i<0?length+i:i;return j>=0&&j<length?min+j:undefined}}}
const configuredSetupHTML=setupHTML;setupHTML=function(){return configuredSetupHTML().replace('<div class="setup-factions">',`<label class="setting-row">Bidding<select onchange="setupConfig.bidding=this.value"><option value="exponential" ${setupConfig.bidding!=='fine'?'selected':''}>Exponential · printed track</option><option value="fine" ${setupConfig.bidding==='fine'?'selected':''}>Fine · 1 gold steps</option></select></label><div class="setup-factions">`)};
placeBid=function(pid,gid,amount){if(G.phase!=='OFFERINGS'||G.activeBidder!==pid||G.biddingQueue[0]!==pid)return;const p=G.players[pid],prev=getGodHolder(gid);if(gid==='APOLLO'){if(prev)return;amount=0}else if(!G.openGods.includes(gid)||gid===G.lastKickedFrom[pid]||!legalOffers(p,gid).includes(amount))return;p.god=gid;p.bid=amount;G.biddingQueue.shift();delete G.lastKickedFrom[pid];logMsg(`${p.name} offers ${amount} gold to ${GOD_DATA[gid].name}.`);if(gid==='APOLLO'){G.apolloOrder??=[];if(!G.apolloOrder.includes(pid))G.apolloOrder.push(pid)}if(prev&&gid!=='APOLLO'){prev.god=null;prev.bid=0;G.lastKickedFrom[prev.id]=gid;G.biddingQueue.unshift(prev.id)}advanceBid()};
aiBid=function(p){if(G.phase!=='OFFERINGS'||G.activeBidder!==p.id)return;const level=p.difficulty||'medium',reserve=level==='hard'?p.phils>=3?4:2:1,choices=G.openGods.filter(g=>g!==G.lastKickedFrom[p.id]).map(g=>({g,n:legalOffers(p,g)[0]})).filter(c=>c.n!==undefined).map(c=>({...c,score:nextGodValue(p,c.g)-Math.max(0,c.n-p.priests)*1.7-(Math.max(0,c.n-p.priests)>p.gp-reserve?9:0)}));if(!getGodHolder('APOLLO'))choices.push({g:'APOLLO',n:0,score:p.gp<4?12:3});if(!choices.length){setPrompt(p.name+' cannot afford an available god. Apollo is occupied.');return}choices.sort((a,b)=>b.score-a.score);const c=level==='easy'?choices[Math.floor(Math.random()*choices.length)]:choices[0];placeBid(p.id,c.g,c.n)};
changeOffer=function(gid,delta){const el=$('offer-'+gid),values=legalOffers(G.players[humanPid()],gid),i=Math.max(0,values.indexOf(Number(el.value)));el.value=values.at(Math.max(0,Math.min(values.length-1,i+delta)));updateOfferCost(gid)};
updateOfferCost=function(gid){const n=Number($('offer-'+gid).value);$('net-'+gid).textContent=legalOffers(G.players[humanPid()],gid).includes(n)?`Pay ${Math.max(0,n-G.players[humanPid()].priests)}`:'Choose a track value'};
submitOffer=function(gid){const n=Number($('offer-'+gid).value);if(!legalOffers(G.players[humanPid()],gid).includes(n)){setPrompt('Choose an affordable offering on the track.');return}placeBid(humanPid(),gid,n)};
let auctionMarkup='';
renderAuctionBoard=function(){const p=G.players[humanPid()],my=G.phase==='OFFERINGS'&&human(G.activeBidder)&&!R.pending;const s=`<div class="spacious-gods" style="--gods:${G.openGods.length}">${G.openGods.map((gid,i)=>{const g=GOD_DATA[gid],h=getGodHolder(gid),values=legalOffers(p,gid),can=my&&gid!==G.lastKickedFrom[p.id]&&values.length;return `<article class="track-god" style="--god-color:${GOD_TONES[gid]}"><span class="god-position">${i+1}</span><button class="track-portrait" onclick="godPowerSheet('${gid}')"><img src="assets/${gid.toLowerCase()}.webp" alt="${g.name}"></button><div class="track-content"><h3>${g.name}</h3><p class="god-benefits">${g.free}</p><div class="track-owner">${h?`<img src="${factionAsset(h.id,'owner')}" alt="${h.name}"> ${h.bid}`:'Unclaimed'}</div>${can?`<div class="offer-stepper"><button onclick="changeOffer('${gid}',-1)" aria-label="Lower offering">−</button><input id="offer-${gid}" type="number" inputmode="numeric" min="${values[0]}" max="${values.at(-1)}" value="${values[0]}" ${exponentialBidding()?'readonly':''} aria-label="Offering to ${g.name}" oninput="updateOfferCost('${gid}')"><button onclick="changeOffer('${gid}',1)" aria-label="Raise offering">+</button><button class="btn primary" onclick="submitOffer('${gid}')">Offer</button><small id="net-${gid}">Pay ${Math.max(0,values[0]-p.priests)}</small></div>`:''}</div></article>`}).join('')}</div><div class="compact-apollo"><button class="apollo-choose" onclick="placeBid(humanPid(),'APOLLO',0)" ${my&&!getGodHolder('APOLLO')?'':'disabled'}><img src="assets/apollo.webp" alt="">Apollo · ${getGodHolder('APOLLO')?getGodHolder('APOLLO').name:'Free'}</button><button class="apollo-info" onclick="godPowerSheet('APOLLO')" aria-label="Apollo powers">ⓘ</button></div>`;if(s!==auctionMarkup){$('gods-container').innerHTML=s;auctionMarkup=s}};
// Preserve bidding-mode metadata when exporting/importing campaigns.
const modeSchema=validateImportedCampaign;validateImportedCampaign=function(v){const s=modeSchema(v);if(s.state.config?.bidding&&!['fine','exponential'].includes(s.state.config.bidding))throw Error('Invalid bidding mode');return s};
renderAll();
const optionalBattleCamera=battle;battle=async function(p,from,to,f,type){if(!APP.watchCPU&&!human(p.id)&&!human(to.owner))return framedBattle(p,from,to,f,type);return optionalBattleCamera(p,from,to,f,type)};
const unnamedSelection=onZoneClick;onZoneClick=function(id){const pending=!!R.pending;unnamedSelection(id);if(!pending&&!R.pending&&!dragged){const z=G.zones[id];setPrompt(z.type==='land'?`${z.troops} Troops · ${z.mercs} Mercenaries · ${z.heroes.length} Heroes · ${z.pros} Prosperity`:`${z.fleets} Fleets · ${z.pros} Prosperity`)}};
// Defer model-driven DOM patches during a live gesture; flush the latest state on release.
let deferredMap=false;
const stableGestureMap=renderMapSVG;renderMapSVG=function(){if(pointers.size&&dragged){deferredMap=true;return}deferredMap=false;return stableGestureMap()};
mapEl.addEventListener('pointerdown',()=>livingBoard());
for(const type of ['pointerup','pointercancel','lostpointercapture'])mapEl.addEventListener(type,()=>{if(!pointers.size){if(deferredMap)renderMapSVG();livingBoard()}});
