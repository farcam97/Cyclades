// v16: explicit actor identity, uncluttered board layers, and inline battle decisions.
APP.performanceMode??=false;APP.skipUnwinnable??=true;FACTIONS[3].color='#f18b32';
const V16='assets/v16/';
function actor16(){return G.phase==='ACTIONS'?G.actionOrder?.[G.activePlayerIdx]??G.activeBidder:G.activeBidder}
function syncColors16(){for(const p of G.players||[])if(p.faction===3)p.color=FACTIONS[3].color;const p=G.players[actor16()];document.body.style?.setProperty('--turn-color',p?.color||'#d9c78e');document.body.style?.setProperty('--selection-color',p?.color||'#d9c78e');document.body.classList.toggle('performance-mode',!!APP.performanceMode);document.querySelectorAll?.('.faction-card').forEach(el=>{const q=G.players[Number(el.dataset.playerId)];if(q)el.style.setProperty('--faction',q.color)});}
const faction16=factionAsset;factionAsset=function(pid,kind){return (G.players[pid]?.faction??pid)===3?(kind==='owner'?V16+'factions/3.webp':V16+'pieces/'+kind+'-3.webp'):faction16(pid,kind)};
const setup16=setupHTML;setupHTML=function(){return setup16().replaceAll('assets/v15/factions/3.webp',V16+'factions/3.webp')};
const card16=unitCardPath;unitCardPath=id=>MAELSTROM_IDS.has(id)?V16+'cards/'+id+'.webp':card16(id);
const render16=renderAll;renderAll=function(){syncColors16();render16();syncColors16();mountBattleChoice16()};
const settings16=renderSettingsCategory;renderSettingsCategory=function(cat=settingsCategory){settings16(cat);if(cat==='display')$('app-panel-content').querySelector('.category-content')?.insertAdjacentHTML('beforeend',check14('performanceMode','Performance mode'));if(cat==='animation')$('app-panel-content').querySelector('.category-content')?.insertAdjacentHTML('beforeend',check14('skipUnwinnable','Skip mathematically unwinnable battles'))};
const save16=saveSettings;saveSettings=function(){save16();syncColors16();if(APP.performanceMode)for(const a of FX.active)a.cancel()};
const sprite16=spriteCue15;spriteCue15=function(...args){if(APP.performanceMode)return;return sprite16(...args)};
const character16=showCharacterEffect15;showCharacterEffect15=function(...args){if(APP.performanceMode)return;return character16(...args)};
const cameraAnimation16=animateCamera;animateCamera=function(t,ms){if(APP.performanceMode){viewZoom=t.zoom;viewX=t.x;viewY=t.y;applyView();return Promise.resolve()}return cameraAnimation16(t,ms)};
// Numeric faces retain the acting faction's dice colors.
dieFace=value=>`<svg viewBox="0 0 64 64" role="img" aria-label="Die ${value}"><rect x="3" y="3" width="58" height="58" rx="10" fill="var(--die-color,#cda347)" stroke="#fff0c6" stroke-width="2"/><text x="32" y="45" text-anchor="middle" fill="#fff8dc" stroke="#182f3d" stroke-width="1" paint-order="stroke" font-family="Georgia,serif" font-weight="bold" font-size="40">${Number(value)||0}</text></svg>`;
// Do not open the general campaign panel for character powers.
showCreaturePresence=function(zone){const m=minis(G.zones[zone])[0];if(m){closeSpacePopover();showUnitInfo(m.id)}};
const unitInfo16=showUnitInfo;showUnitInfo=function(id){closeAppPanel();unitInfo16(id);const pic=document.getElementById('unit-card-popover')?.querySelector('img');if(pic)pic.src=unitCardPath(id)};
function enabledUnit16(u){const cfg=G.config||setupConfig,key=u.mil?'excludedHeroes':'excludedCreatures';return (!u.expansion||!!cfg.maelstrom)&&!(cfg[key]||[]).includes(u.id)}
const reference16=searchReference;searchReference=function(q=''){if(!['heroes','creatures'].includes(referenceCategory))return reference16(q);const entries=(referenceCategory==='heroes'?HEROES:CREATURES).filter(u=>[u.name,u.desc,u.mil,u.sac].join(' ').toLowerCase().includes(q.toLowerCase())).slice().sort((a,b)=>a.name.replace(/^The /,'').localeCompare(b.name.replace(/^The /,'')));$('reference-results').innerHTML=entries.map(u=>`<article class="reference-entry ${enabledUnit16(u)?'':'excluded-unit'}" tabindex="0" role="button" onclick="showUnitInfo('${u.id}')" onkeydown="if(event.key==='Enter')showUnitInfo('${u.id}')"><img loading="lazy" decoding="async" src="${unitPiecePath(u.id)}" alt=""><div><h3>${u.name}</h3>${powerText(u)}${enabledUnit16(u)?'':'<small>Not included in this game</small>'}</div></article>`).join('')||'<p>No matching entries.</p>'};
// Circular painted controls, with an integrated readable plaque underneath.
const buttons16=actionButton;actionButton=function(label,fn,enabled=true){const art=actionArt15(label,fn);if(!art)return buttons16(label,fn,enabled);const name=art==='end-turn'?'End turn':label;return `<button class="btn medallion-action ${enabled?'':'unavailable'}" ${enabled?`onclick="${fn}"`:`aria-disabled="true" onclick="explainAction15('${encodeURIComponent(fn)}','${encodeURIComponent(label)}')"`}><span class="action-disc ${art==='end-turn'?'hourglass-disc':''}"><img src="assets/v15/actions/${art}.${art==='end-turn'?'png':'webp'}" alt=""></span><span class="action-plaque">${name}</span></button>`};
// Pointer capture begins at pointerdown, before a child piece can lose the stream.
mapEl.removeEventListener?.('pointerdown',pointerDown15);mapEl.removeEventListener?.('pointermove',pointerMove15);for(const t of ['pointerup','pointercancel','lostpointercapture'])mapEl.removeEventListener?.(t,pointerEnd15);
let tapTarget16=null;
function down16(e){if(e.pointerType==='mouse'&&e.button!==0)return;if(!pointers.size)tapTarget16=e.target;pointerDown15(e);try{mapEl.setPointerCapture(e.pointerId)}catch{}}
function end16(e){const tap=!dragged&&pointers.size===1&&e.type!=='pointercancel',target=tapTarget16;pointerEnd15(e);if(tap&&target&&e.type!=='lostpointercapture'){suppressMapClickUntil=Date.now()+350;const piece=target.closest?.('[data-unit]'),zone=target.closest?.('[data-zone]');if(piece&&!R.pending)inspectMapUnit16(piece.dataset.unit,Number(zone?.dataset.zone));else if(zone){suppressMapClickUntil=0;onZoneClick(Number(zone.dataset.zone));suppressMapClickUntil=Date.now()+350;}}if(!pointers.size)tapTarget16=null}
mapEl.addEventListener('pointerdown',down16);mapEl.addEventListener('pointermove',pointerMove15,{passive:false});mapEl.addEventListener('pointerup',end16);mapEl.addEventListener('pointercancel',end16);mapEl.addEventListener('click',e=>{if(Date.now()<suppressMapClickUntil){e.preventDefault();e.stopImmediatePropagation?.()}},true);
startMoveMode=function(type){const z=G.zones[R.inspected];preferredSource=z&&z.type===type&&z.owner===G.activeBidder?z.id:null;userCommand(p=>move(p,type))};
const force16=selectForce;selectForce=async function(p,z,h){if(z.type==='sea'&&z.fleets===1)return {troops:1,mercs:0,heroes:[],minotaur:null};return force16(p,z,h)};
// Effects attach to the payer/recipient's real HUD position, including reordered seats.
function hudCue16(pid,text,cls,icon=''){if(R.auto||skipCPUPresentation||!document.createElement)return;const card=document.querySelector(`[data-player-id="${pid}"]`),r=card?.getBoundingClientRect();if(!r)return;const e=document.createElement('div');e.className='hud-cue '+cls;e.innerHTML=icon+`<strong>${text}</strong>`;e.style.cssText=`left:${r.left+r.width/2}px;top:${r.top+r.height*.65}px;--actor:${G.players[pid].color}`;document.body.appendChild(e);setTimeout(()=>e.remove(),1500)}
const spend16=spendGold;spendGold=function(p,n){spend16(p,n);if(n>0&&(APP.incomeAll||human(p.id)))hudCue16(p.id,'−'+n,'gold-spent')};
function cardGain16(p,key,n){if(!n||R.auto||G.phase==='SETUP')return;hudCue16(p.id,'+'+n+' '+(key==='priests'?'Priestess':'Philosopher'),key==='priests'?'holy-cue':'wisdom-cue',tabletopIcon(key==='priests'?'priest':'philosopher',30));if(!skipCPUPresentation)playFoley(key==='priests'?'priestess-holy':'philosopher-insight','UI')}
const supply16=supplyCard;supplyCard=function(p,key,n=1){const got=supply16(p,key,n);cardGain16(p,key,got);return got};
const hire16=hireHero;hireHero=async function(p,i){const h=G.heroes[i],before=lands(p.id).flatMap(z=>z.heroes).length;await hire16(p,i);if(h&&lands(p.id).flatMap(z=>z.heroes).length>before)logMsg(`${p.name} recruits ${h.name}.`)};
const build16=build;build=async function(p,t,...args){const before=G.logs[0];await build16(p,t,...args);const added=G.logs.slice(0,before?G.logs.indexOf(before):G.logs.length),made=added.some(l=>t&&l.includes(`${p.name} builds a ${BN[t]}`)),metro=added.some(l=>l.includes(`${p.name} builds a Metropolis`));if((made||metro)&&!human(p.id))await observation(`${p.name} constructs a ${metro?'Metropolis':BN[t].toLowerCase()}.`,R.inspected,p.id)};
let lastCreatureCaption16='';const narrate16=observation;observation=async function(text,zone=null,pid=actor16()){if(/ takes .+['’]s turn/.test(text))return;const clean=String(text).replace(/^\[C\d+\]\s*/,'');if(clean.includes(' summons ')){if(clean===lastCreatureCaption16)return;lastCreatureCaption16=clean}else lastCreatureCaption16='';return narrate16(clean,zone,pid)};
// Opening the map precedes the turn emblem, not the first lengthy CPU action.
const turn16=beginTurn;beginTurn=async function(){$('ai-caption').hidden=true;if(G.actionOrder?.[G.activePlayerIdx]!==undefined)G.activeBidder=G.actionOrder[G.activePlayerIdx];switchTab('map');syncColors16();renderCompactHUD();return turn16()};
let fastBattle16=false;
function provenBattleWinner16(b){if(!b||G.monsters.length||b.att.heroes.length||b.def.heroes.length||b.att.minotaur||b.def.minotaur)return null;const a=battleStrength(b.att,b.attId,false),d=battleStrength(b.def,b.defId,true);if(a>d+3)return 'att';if(d>a+3)return 'def';return null}
function mountBattleChoice16(){if(!B||!R.pending||R.choiceMap)return;const p=R.pending;if(p.options.some(o=>o.zone!==undefined))return;$('decision').classList.remove('active');$('decision').setAttribute('aria-hidden','true');$('battle-modal').classList.add('active');$('battle-actions').innerHTML=`<h4>${p.title}</h4>`+p.options.map((o,i)=>`<button class="btn" onclick="answerDecision(${i})">${o.image?`<img width="38" src="${decisionImage(o.image)}" alt="">`:''}${o.label}</button>`).join('')}
const showBattle16=showBattle;showBattle=function(msg){if(APP.skipUnwinnable&&msg==='Both armies prepare to roll.'&&provenBattleWinner16(B)){fastBattle16=true;$('battle-modal').classList.remove('active')}if(fastBattle16)return;showBattle16(msg);mountBattleChoice16()};
const pause16=cinemaPause;cinemaPause=ms=>fastBattle16?Promise.resolve():pause16(APP.performanceMode?Math.min(ms,300):ms);
const round16=animateBattleRound;animateBattleRound=async function(roll){if(fastBattle16){B.lastRoll={...roll};return}return round16(roll)};
const outcome16=animateBattleOutcome;animateBattleOutcome=async function(won){if(fastBattle16)return;return outcome16(won)};
const battle16=battle;battle=async function(...args){const previous=G.lastBattle;let completed=false;try{const result=await battle16(...args);completed=true;return result}finally{fastBattle16=false;if(completed&&G.lastBattle&&G.lastBattle!==previous&&!R.auto&&!skipCPUPresentation){const pid=G.lastBattle.winner,p=G.players[pid];hudWinner16(p);await cinemaPause(1300)} }};
function hudWinner16(p){if(!document.createElement)return;const e=document.createElement('div');e.className='battle-winner';e.style.setProperty('--actor',p?.color||'#eee');e.innerHTML=(p?`<img src="${factionAsset(p.id,'owner')}" alt="">`:'')+`<strong>${p?p.name+' wins':'Both forces destroyed'}</strong>`;document.body.appendChild(e);setTimeout(()=>e.remove(),1800)}
function battleMask16(z){return (z.bldgs||[]).reduce((n,t)=>n|({F:1,P:2,T:4,U:8}[t]||0),z.metros?.length?16:0)}
const field16=battlefieldHTML;battlefieldHTML=function(b){return field16(b).replace(/background-image:url\('[^']+'\)/,`background-image:url('${b.type==='sea'?'assets/v15/battles/ocean.webp':V16+'battles/land-'+battleMask16(G.zones[b.toId])+'.webp'}')`)};
const showDecision16=showDecision;showDecision=function(){if(B&&R.pending&&!R.pending.options.some(o=>o.zone!==undefined)){R.choiceMap=false;mountBattleChoice16();return}return showDecision16()};
const ask16=ask;ask=async function(pid,title,options,extra=''){
 if(B&&/^Battle round /.test(title)&&APP.skipUnwinnable&&provenBattleWinner16(B)){fastBattle16=true;$('battle-modal').classList.remove('active');return 'roll'}
 if(fastBattle16){if(options.length===1)return options[0].value;if(human(pid)){fastBattle16=false;showBattle('Choose your battle action.')}}
 if(human(pid)&&preferredSource!==null&&/^Choose the Sea Area to sail from$/.test(title)){const z=preferredSource;preferredSource=null;if(options.some(o=>o.value===z)){routeSource=z;return z}}
 if(/building|replacement/i.test(title))options=options.map(o=>{const t=TYPES.find(t=>o.label===BN[t]||o.label.startsWith(BN[t]+' '));return t?{...o,image:'painted/building-'+t}:o});
 const pending=ask16(pid,title,options,extra);await Promise.resolve();mountBattleChoice16();if(R.pending&&/replace|replacement/i.test(title)){$('decision-map').hidden=false;$('decision-map').textContent='View map';$('decision-map').setAttribute('onclick','inspectDecisionMap()')}
 return pending;
};
// Deterministic placement is cached per territory state; camera gestures never recompute it.
const layoutCache16=new WeakMap();
function layout16(z){const count=(APP.condensed?(z.troops?1:0)+(z.mercs?1:0)+(z.fleets?1:0):(z.troops||0)+(z.mercs||0)+(z.fleets||0))+(z.heroes?.length||0)+minis(z).length;
 const key=[count,z.pros,z.bldgs?.join(','),z.metros?.length,APP.condensed].join('|'),old=layoutCache16.get(z);if(old?.key===key)return old;
 const xs=z.polygon.map(p=>p[0]),ys=z.polygon.map(p=>p[1]),bounds={left:Math.min(...xs),right:Math.max(...xs),top:Math.min(...ys),bottom:Math.max(...ys)},inside=(x,y)=>tileContainsV14(z,x,y),candidates=[];
 for(let y=bounds.top+3;y<bounds.bottom;y+=5)for(let x=bounds.left+3;x<bounds.right;x+=5)if(inside(x,y))candidates.push({x,y});if(!candidates.length)candidates.push({x:z.x,y:z.y});
 const buildings=(z.buildingSites||[]).slice(0,(z.bldgs?.length||0)+(z.metros?.length||0)).map((p,i)=>({...p,y:p.y-7,r:i<(z.bldgs?.length||0)?15:19}));
 const n=Math.max(0,z.pros||0),tokenSize=12,gap=13,rowWidth=Math.max(0,n*gap-1);
 let row={x:z.x-rowWidth/2,y:bounds.bottom-13},best=-Infinity;
 for(const c of candidates){const left=c.x-rowWidth/2,right=c.x+rowWidth/2;let fit=0;for(let i=0;i<Math.max(1,n);i++)if(inside(left+i*gap,c.y)&&inside(left+i*gap,c.y+6))fit++;const clearance=Math.min(40,...buildings.map(b=>Math.hypot(c.x-b.x,c.y-b.y)-b.r));const score=fit*100+clearance*2+(c.y-bounds.top)*.2-Math.abs(c.x-z.x)*.2;if(score>best){best=score;row={x:left,y:c.y-6}}}
 const used=buildings.map(b=>({...b})),points=[];
 if(n)for(let i=0;i<n;i++)used.push({x:row.x+i*gap+6,y:row.y+6,r:10});
 for(let i=0;i<count+1;i++){let winner=null,score=-Infinity;for(const c of candidates){const clearance=used.length?Math.min(...used.map(p=>Math.hypot(c.x-p.x,(c.y-p.y)*.85)-p.r)):30;const inset=[[-10,-12],[10,-12],[-10,12],[10,12]].filter(([x,y])=>inside(c.x+x,c.y+y)).length;const v=clearance*4+inset*6-Math.hypot(c.x-z.x,c.y-z.y)*.025;if(v>score){score=v;winner=c}}points.push({...winner});used.push({...winner,r:20})}
 const result={key,row,tokenSize,gap,points:points.slice(0,count),owner:points[count],bounds};layoutCache16.set(z,result);return result;
}
tileBuildingsV14=function(z){return [...z.bldgs,...z.metros.map(()=> 'M')].map((t,i)=>{const p=z.buildingSites[i],size=t==='M'?30:24;return p?`<g class="map-building" style="--building-outline:${({M:'#fff',T:'#ad68e3',P:'#31c8bd',F:'#ef704d',U:'#d9dce1'})[t]}">${paintedImage('building-'+t,p.x-size/2,p.y-size*.7,size,size,'building-sprite')}</g>`:''}).join('')};
function offerings16(z){const l=layout16(z);let s='';const scale=(G.zones[0].tileLayoutV14[z.tile]?.w||280)/400;for(const h of z.printedHorns||[]){const n=30*scale;s+=`<rect x="${h.x-n/2}" y="${h.y-n/2}" width="${n}" height="${n}" rx="4" fill="#eddbab" pointer-events="none"/>`}
 for(let i=0;i<(z.pros||0);i++)s+=`<image class="offering-token" href="assets/v15/offering.webp" x="${l.row.x+i*l.gap}" y="${l.row.y}" width="${l.tokenSize}" height="${l.tokenSize}" pointer-events="none"/>`;return s}
renderIndividualPieces=function(z){const sea=z.type==='sea',units=[],add=(kind,n,src)=>{if(!n)return;if(APP.condensed)units.push({kind,n,src});else for(let i=0;i<n;i++)units.push({kind,n:1,src})};
 add('mercenary',z.mercs,PAINT+'mercenary.webp');for(const h of z.heroes||[])units.push({kind:'hero',id:h.id,src:unitPiecePath(h.id)});for(const m of minis(z)){const pair=G.monsters.filter(v=>v.id===m.id&&v.owner===m.owner),charybdis=m.id==='charybdis-scylla'&&(m.aspect==='charybdis'||!m.aspect&&pair.indexOf(m)===0);units.push({kind:'creature',id:m.id,pid:m.owner,src:charybdis?V16+'charybdis.webp':unitPiecePath(m.id)})}
 add(sea?'fleet':'troop',sea?z.fleets:z.troops,factionAsset(z.owner,sea?'fleet':'warrior'));
 const l=layout16(z),op=l.owner;let s=!sea&&!z.troops&&z.owner!==null?`<image class="tracker" href="${factionAsset(z.owner,'owner')}" x="${op.x-11}" y="${op.y-11}" width="22" height="22"/>`:'';
 return s+units.map((v,i)=>{const p=l.points[i],w=v.kind==='hero'?32:v.kind==='creature'?36:26,h=sea&&v.kind==='fleet'?25:w*1.2,pid=v.pid??z.owner,color=G.players[pid]?.color||'#eee',special=!['troop','fleet'].includes(v.kind);return `<g class="individual-piece ${v.kind}-piece ${v.id||''}-piece" data-faction="${pid}" ${v.id?`data-unit="${v.id}" aria-label="${htmlEscape((HEROES.find(u=>u.id===v.id)||CREATURES.find(u=>u.id===v.id))?.name||v.id)} powers" role="button" tabindex="0" onclick="if(!R.pending&&!dragged){event.stopPropagation();inspectMapUnit16('${v.id}',${z.id})}" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();inspectMapUnit16('${v.id}',${z.id})}"`:''}>${special?`<ellipse class="piece-base" cx="${p.x}" cy="${p.y+h*.4}" rx="${w*.36}" ry="3" fill="${color}" stroke="#fff" opacity="${v.kind==='creature'?1:.75}"/>`:''}<image href="${v.src}" x="${p.x-w/2}" y="${p.y-h/2}" width="${w}" height="${h}" preserveAspectRatio="xMidYMid meet"/>${APP.condensed&&v.n?`<text class="unit-count" text-anchor="middle" x="${p.x}" y="${p.y+h/2+5}">${v.n}</text>`:''}</g>`}).join('')};
function inspectMapUnit16(id,zone){if(G.zones[zone]?.heroes?.some(h=>h.id===id))showOwnedHero(zone,id);else showUnitInfo(id)}
// All structures/resources/borders precede the unit layer, including neighboring territories.
const oldBoard16=renderMapSVG;renderMapSVG=function(){const tiles=G.zones?.[0]?.tileLayoutV14;if(!tiles)return oldBoard16();if(pointers.size){deferredMap=true;return}deferredMap=false;const frame=boardFrame();let s=MAP_DEFS+FACTION_DEFS+`<rect width="${frame.width}" height="${frame.height}" fill="#087998"/>`;
 s+=tiles.map(t=>`<image class="uploaded-tile-art" href="assets/tiles-v14/tile-${t.number}.webp" x="${t.x}" y="${t.y}" width="${t.w}" height="${t.h}" preserveAspectRatio="none" pointer-events="none"/>`).join('');
 for(const z of G.zones){const valid=availableZone(z.id),col=G.players[z.owner]?.color||'#d9d2b3';s+=`<g id="region-${z.id}" data-zone="${z.id}" role="button" tabindex="0" aria-label="${htmlEscape(z.name)}, ${z.type}, ${htmlEscape(G.players[z.owner]?.name||'unclaimed')}${valid?', available':''}" onkeydown="if(event.target===this&&(event.key==='Enter'||event.key===' ')){event.preventDefault();event.stopPropagation();onZoneClick(${z.id})}" class="paint-zone ${z.type==='sea'?'sea-space':'land-space'} ${valid?'legal-space':''} ${R.inspected===z.id?'inspected-space':''}" style="--owner-color:${col}" onclick="onZoneClick(${z.id})"><path class="${z.type==='sea'?'sea-frontier':'land-frontier'}" d="${z.path}" fill="none"/><path class="paint-hit" d="${z.path}" fill-rule="evenodd" fill-opacity=".12"/>${offerings16(z)}${z.type==='land'?tileBuildingsV14(z):''}</g>`}
 if(APP.tileEdges)s+=tiles.map(t=>`<rect x="${t.x}" y="${t.y}" width="${t.w}" height="${t.h}" fill="none" stroke="#bce9e4" stroke-opacity=".25" pointer-events="none"/>`).join('');
 for(const z of G.zones)s+=`<g id="zone-${z.id}" data-zone="${z.id}" class="map-units" onclick="onZoneClick(${z.id})">${renderIndividualPieces(z)}</g>`;
 const staged=currentStage();if(staged&&G.zones[staged.zone])s+=`<path class="staged-outline" d="${G.zones[staged.zone].path}" pointer-events="none"/>`;
 if(R.pending&&routeSource!==null&&routeDestination!==null&&G.zones[routeSource]&&G.zones[routeDestination]){const path=previewRoute(routeSource,routeDestination);s+=`<g class="route-preview" pointer-events="none"><path d="${path.map((id,i)=>`${i?'L':'M'}${G.zones[id].x},${G.zones[id].y}`).join(' ')}"/></g>`}
 s+='<g id="map-fx"></g>';reconcileBoard(s);applyView();livingBoard();document.body.classList.toggle('owner-borders',APP.ownerBorders);
};
// Capture selected values before effects mutate their targets. Narration describes results.
let creatureContext16=null;
const creatureAsk16=ask;ask=async function(pid,title,options,extra=''){const ctx=creatureContext16,prepared=options.map(o=>{const v=o.value,zone=o.zone??(v&&typeof v==='object'?(v.z??v.zone??v.id):undefined),z=G.zones[zone];return {...o,owner:z?.owner,building:z?.bldgs?.[v?.i],targetMonster:v?.m!==undefined?CREATURES.find(c=>c.id===G.monsters[v.m]?.id)?.name:null}});const value=await creatureAsk16(pid,title,options,extra);if(ctx){const o=prepared.find(o=>JSON.stringify(o.value)===JSON.stringify(value));ctx.choices.push({title,value,...o})}return value};
presentCreatureTarget15=async function(zone){const ctx=creaturePresentation15;if(!ctx||R.auto||skipCPUPresentation)return;ctx.shown=true;lastFollowZone=zone;if(G.zones[zone]&&followCamera){switchTab('map');const z=G.zones[zone];await animateCamera({zoom:2,x:z.x-140,y:z.y-172.5},350)}showCharacterEffect15(ctx.c.id,zone,ctx.p.id);await cinemaPause(500)};
function creatureText16(ctx){const {p,c,choices:q,before,child}=ctx,choice=(r)=>q.find(v=>r.test(v.title)),name=id=>G.players[id]?.name||'another faction',label=r=>choice(r)?.label,own=r=>name(choice(r)?.owner),prefix=`${p.name} summons ${c.name.replace(/^The /,'the ')} `,lostShips=before.zones.reduce((n,z,i)=>n+Math.max(0,z.fleets-(G.zones[i]?.fleets||0)),0);
 if(q.length&&q.every(x=>x.value===null))return prefix+'but has no eligible target.';
 switch(c.id){
 case 'charon':return prefix+`to swap ${label(/your Hero to exchange/)||'their Hero'} for ${label(/Hero from the track/)||'another Hero'}.`;
 case 'chimera':return `${p.name} summons the Chimera${child?' and uses '+child.c.name+' to '+creatureAction16(child):''}. The creature deck is now reshuffled.`;
 case 'cyclops':return prefix+`to exchange their ${BN[choice(/Building to exchange/)?.building]||'building'} for a ${label(/replacement/)||'different building'}.`;
 case 'dryad':return prefix+`and steals a Priestess from ${name(choice(/player affected/)?.value)}.`;
 case 'satyr':return prefix+`and steals a Philosopher from ${name(choice(/player affected/)?.value)}.`;
 case 'giant':return prefix+`and steals Mercenaries from ${own(/Giant: take/)}.`;
 case 'griffin':return prefix+`to steal half of ${name(choice(/player affected/)?.value)}’s gold.`;
 case 'harpy':return prefix+`to remove ${own(/Troop to destroy/)}’s ${choice(/troop type/)?.value==='mercs'?'Mercenary':'troop'}.`;
 case 'graeae':return prefix+'and collects income again.';
 case 'pegasus':return prefix+'and moves their troops.';
 case 'sphynx':return prefix+`and plays ${child?.c.name||label(/Sphynx: play/)||'a creature'}.`;
 case 'sylph':return prefix+'and swaps the ships in two sea spaces.';
 case 'cerberus':case 'chiron':case 'medusa':return prefix+'on a land space.';
 case 'hydra':return prefix+`on a ${G.zones[choice(/^Place /)?.value]?.type==='sea'?'sea':'land'} space.`;
 case 'kraken':case 'nereid':case 'typhon':return prefix+'on a sea space.';
 case 'minotaur':case 'polyphemus':case 'charybdis-scylla':return prefix.trim()+'.';
 case 'calydonian-boar':return prefix+`and moves ${name(before.zones[choice(/^Place /)?.value]?.owner)}’s units.`;
 case 'echidna':return prefix+`and steals ${label(/Echidna: choose/)||'a creature'}${q.some(x=>/Relocate/.test(x.title)&&x.value!==null)?', moving it to a different space':''}.`;
 case 'hippaletryon':return prefix+`and exchanges pairs of Mercenaries for ${q.filter(x=>/Exchange two Mercenaries/.test(x.title)&&x.value!==null).map(x=>x.label).join(', ')||'a reward'}.`;
 case 'hippocampus':return prefix+`and exchanges ${lostShips} ships for ${lostShips} Mercenaries.`;
 case 'empusa':return prefix+'and repeats '+GOD_DATA[p.god].name+'’s free actions: '+GOD_DATA[p.god].free.replace(/\.$/,'')+'.';
 case 'erinyes':return prefix+'and moves a prosperity token.';
 case 'geryon':return prefix+'on a land space.';
 case 'manticore':return prefix+`and destroys ${choice(/Manticore: destroy/)?.targetMonster||label(/Manticore: destroy/)||'a target'}.`;
 case 'triton':return prefix+`and steals ${own(/Triton: steal/)}’s ${label(/Triton: steal/)||'building'}.`;
 default:return prefix.trim()+'.';
 }}
function creatureAction16(ctx){const t=creatureText16(ctx),i=t.indexOf(' and '),j=t.indexOf(' to ');let s=i>=0?t.slice(i+5):j>=0?t.slice(j+4):'place '+ctx.c.name;s=s.replace(/\.$/,'').replace(/^steals /,'steal ').replace(/^moves /,'move ').replace(/^exchanges /,'exchange ').replace(/^destroys /,'destroy ').replace(/^collects /,'collect ').replace(/^plays /,'play ').replace(/^swaps /,'swap ');return s}
const play16=playCreature;playCreature=async function(p,c){if(!c)return;const parent=creatureContext16,ctx={p,c,choices:[],before:{zones:G.zones.map(z=>({owner:z.owner,fleets:z.fleets||0})),priests:p.priests,phils:p.phils}};creatureContext16=ctx;try{await play16(p,c);if(parent)parent.child=ctx;const text=creatureText16(ctx);logMsg(text);if(!parent)await observation(text,ctx.choices.find(x=>x.zone!==undefined)?.zone??R.inspected,p.id)}finally{creatureContext16=parent}};
showChangeLog=function(){showAppPanel('changes');$('app-panel-title').textContent='Change log · 16.0';$('app-panel-content').innerHTML='<p>Faction-correct turn colors and god announcements; numeric dice; direct battle controls and winner emblems; troop-first map layering, consistent horizontal offerings and smaller buildings; reliable one-finger dragging; direct ship movement; named recruitment and construction; detailed creature narration; performance mode; orange Snake; scenic Maelstrom cards and distinct Charybdis; building-aware battle art.</p><p>Unwinnable battle skipping uses a conservative mathematical proof. Special effects and meaningful player choices retain normal resolution.</p>'};
const drawBoard16=renderMapSVG;let boardKey16=null,boardIdentity16=null;
renderMapSVG=function(){if(pointers.size){deferredMap=true;return}const key=mapPresentationKey();if(boardIdentity16===G.zones&&key===boardKey16){PERF.mapHits++;applyView();return}drawBoard16();boardIdentity16=G.zones;boardKey16=key;PERF.mapBuilds++};
const marketRender16=renderMarket;let marketBoard16=null,marketKey16=null;
renderMarket=function(){const p=G.players[humanPid()];if(!p)return;const key=JSON.stringify([marketTab,G.creatures,G.heroes,lands(p.id).map(z=>z.heroes),p.id,p.gp,p.god,G.turnState,G.phase,G.activeBidder,R.busy,discountSlots(p),G.monsters]);if(marketBoard16===G.zones&&key===marketKey16)return;marketRender16();marketBoard16=G.zones;marketKey16=key};
syncColors16();renderAll();
