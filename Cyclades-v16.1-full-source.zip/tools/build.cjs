const fs=require('node:fs');const path=require('node:path');const esbuild=require('esbuild');const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),web=path.join(root,'web'),out=path.join(root,'dist');
fs.rmSync(out,{recursive:true,force:true});fs.cpSync(web,out,{recursive:true});
let html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script src="([^"?]+)[^"]*"><\/script>/g)].map(m=>m[1]);
const styles=[...html.matchAll(/<link rel="stylesheet" href="([^"?]+)[^"]*">/g)].map(m=>m[1]);
// Preserve classic-script boundaries: later function declarations must not be
// hoisted into earlier initialization phases. Minify each script independently.
for(const name of scripts){const code=esbuild.transformSync(fs.readFileSync(path.join(web,name),'utf8'),{minify:true,target:'chrome90',legalComments:'inline'}).code;fs.writeFileSync(path.join(out,name),code)}
const css=esbuild.transformSync(styles.map(s=>fs.readFileSync(path.join(web,s),'utf8')).join('\n'),{loader:'css',minify:true,target:'chrome90'}).code;
const digest=s=>crypto.createHash('sha256').update(s).digest('hex').slice(0,12);
const cssName=`cyclades.${digest(css)}.css`;
html=html.replace(/<link rel="stylesheet" href="[^"?]+[^"]*">/g,'').replace('</head>',`<link rel="stylesheet" href="${cssName}"></head>`);
fs.writeFileSync(path.join(out,cssName),css);fs.writeFileSync(path.join(out,'index.html'),html);
for(const f of styles)fs.unlinkSync(path.join(out,f));
fs.writeFileSync(path.join(out,'build-manifest.json'),JSON.stringify({version:'16.1.0',scripts:scripts.length,styles:styles.length,css:cssName},null,2)+'\n');
console.log(`Built ${scripts.length} scripts and ${styles.length} styles with one combined stylesheet; classic-script boundaries and artwork retained.`);
