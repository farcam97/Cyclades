const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').join(__dirname,'../dist'),nodes=new Map(),q=new Map();let tid=0;
function el(id){if(nodes.has(id))return nodes.get(id);let n={innerHTML:'',textContent:'',hidden:false,dataset:{},value:'0',checked:true,min:0,max:8,classList:{add(){},remove(){},toggle(){}},insertAdjacentHTML(w,s){this.innerHTML+=s},querySelector(s){return el(id+' '+s)},querySelectorAll(){return []},style:{setProperty(){}},listeners:{},addEventListener(k,f){(this.listeners[k]??=[]).push(f)},setAttribute(k,v){this[k]=v},getAttribute(k){return this[k]},getBoundingClientRect(){return {left:0,top:0,width:560,height:690}},remove(){},focus(){}};nodes.set(id,n);return n}
const storage=new Map();const c=vm.createContext({document:{body:el('body'),getElementById:el,querySelector:el,querySelectorAll:()=>[0,1,2,3].map(i=>el('nav'+i))},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},sessionStorage:{getItem(){return 'seen'},setItem(){}},setTimeout(f){q.set(++tid,f);return tid},clearTimeout(i){q.delete(i)},console});const r=s=>vm.runInContext(s,c);
for(const name of ['game.js','visuals.js','archipelago.js','tiles.js','coasts.js','macromap.js','rules.js','painted.js','animations.js','pieces-v6.js','experience.js','tiles-v14.js','motion-v5.js','tabletop-v6.js','motion-v6.js','cinema-v7.js','performance.js','usability.js','immersion.js','campaign-tools.js','campaign-v11.js','streamlined-v12.js','polish-v13.js','maelstrom-v14.js','faq-v14.js','interface-v14.js','interface-v15.js','interface-v16.js'])r(fs.readFileSync(root+'/'+name,'utf8'));
r('R.auto=true');
async function drainUntil(test,max=3000){for(let i=0;i<max;i++){await new Promise(setImmediate);if(r(test))return i;if(!q.size)throw Error('Stalled '+r('JSON.stringify({phase:G.phase,cycle:G.cycle,busy:R.busy,pending:R.pending?.title,active:G.activeBidder,queue:G.biddingQueue})'));const [id,fn]=q.entries().next().value;q.delete(id);fn()}throw Error('Timeout '+r('G.cycle'))}




(async()=>{
r('setupConfig.count=3;setupConfig.spectator=true;APP.maelstrom=true;startConfiguredGame();R.auto=true');await drainUntil("G.phase==='OFFERINGS'&&!R.busy");q.clear();r('timers.forEach(clearTimeout);timers.clear()');
// Every region in all layouts, densely populated: safe center points and stable scale.
for(const shape of ['tall','wide'])for(const count of [2,3,4,5,6]){
 r(`globalThis.campaignMapShape='${shape}';globalThis.campaignTileCount=requiredTiles(${count});G.zones=makeRandomMap();G.monsters=[];G.zones.forEach(z=>{z.troops=z.type==='land'?8:0;z.mercs=z.type==='land'?4:0;z.fleets=z.type==='sea'?8:0;z.heroes=[];z.bldgs=z.type==='land'?TYPES.slice(0,z.capacity):[];z.metros=[];z.pros=3;z.owner=0});renderMapSVG()`);
 assert(r('G.zones.every(z=>layout16(z).points.every(p=>tileContainsV14(z,p.x,p.y)))'));
 assert(r('G.zones.every(z=>layout16(z)===layout16(z))'));
 const markup=el('archipelago').innerHTML;assert(markup.lastIndexOf('class="map-building"')<markup.indexOf('class="map-units"'));assert(!markup.includes('undefined'));
}
console.log('PASS all-region dense layout, unit layers and placement cache');
assert(r('dieFace(3).includes(">3</text>")'));assert(!r('dieFace(3)').includes('<circle'));assert(r('actionButton("End turn","finishCurrentPlayerTurn()").includes("action-plaque")'));
r("R.auto=false;G.players[0].controller=0;G.activeBidder=0;G.phase='ACTIONS';globalThis.sea=G.zones.find(z=>z.type==='sea');sea.owner=0;sea.fleets=1;preferredSource=sea.id");
assert.equal(await r('ask(0,"Choose the Sea Area to sail from",optsAreas([sea]))'),r('sea.id'));
assert.equal((await r('selectForce(G.players[0],sea)')).troops,1);assert.equal(r('R.pending'),null);
console.log('PASS direct selected sea source and single-ship force');
r("G.monsters=[];globalThis.dest=G.zones.find(z=>z.type==='land');dest.bldgs=[];dest.metros=[];B={type:'land',attId:0,defId:1,toId:dest.id,att:{troops:6,mercs:0,heroes:[],minotaur:null},def:{troops:1,mercs:0,heroes:[],minotaur:null},round:1};");assert.equal(r('provenBattleWinner16(B)'),'att');
r('B.att.troops=4');assert.equal(r('provenBattleWinner16(B)'),null);r("B.att.troops=8;B.def.heroes=[{id:'helen'}]");assert.equal(r('provenBattleWinner16(B)'),null);
r("B.def.heroes=[];G.monsters=[{id:'geryon',zone:dest.id,owner:1}]");assert.equal(r('provenBattleWinner16(B)'),null);r('G.monsters=[];APP.skipUnwinnable=false');
const pending=r('ask(0,"Battle round 1",[{value:"roll",label:"Roll battle dice"}])');for(let i=0;i<10;i++)await new Promise(setImmediate);assert(el('battle-actions').innerHTML.includes('Roll battle dice'));r('answerDecision(0)');assert.equal(await pending,'roll');r('B=null');
console.log('PASS strict unwinnable proof rejects ties, heroes, creature effects; inline battle decisions');
r("globalThis.base={p:G.players[0],before:{zones:G.zones,priests:0,phils:0},choices:[{title:'Choose the player affected',value:1}]}");
assert(r("creatureText16({...base,c:CREATURES.find(c=>c.id==='dryad')})").includes('Priestess'));assert(r("creatureText16({...base,c:CREATURES.find(c=>c.id==='satyr')})").includes('Philosopher'));
for(let mask=0;mask<32;mask++){r(`dest.bldgs=TYPES.filter((t,i)=>${mask}&(1<<i));dest.metros=${mask}&16?['gold']:[]`);assert.equal(r('battleMask16(dest)'),mask)}
console.log('PASS creature narration terminology and all 32 battle backgrounds mapping');
})().catch(e=>{console.error(e);process.exitCode=1});
