# Cyclades

Development sources recovered from the user-supplied Cyclades v16 APK. The selected GitHub repository was empty. Original artwork, rules, and gameplay options are retained. The original Android wrapper and regression tests have also been imported from the user’s smaller source archive.

Requires Node.js 22+ and Chromium. No runtime dependencies, credentials, or backend are required.

```sh
npm ci
npm run check
npm start
```

The development server binds to loopback port 4173. Run `npm test` for browser regression checks. Set `CHROMIUM_PATH` if Chromium is installed somewhere other than `/usr/bin/chromium`.

```sh
npm run build
CYCLADES_WEB_ROOT=dist CYCLADES_PORT=4174 npm start
# In another terminal:
CYCLADES_TEST_URL=http://127.0.0.1:4174 npm test
```

The production files in `dist/` are bundled by `android/build.sh`. Its classic script execution order must be preserved. The build intentionally keeps separate script boundaries because concatenation hoists later declarations into earlier initialization.

See [changes and outstanding work](docs/IMPROVEMENTS.md). No license for the recovered game or artwork is inferred or granted here.

## Android preview

`bash tools/build-preview.sh` installs the pinned Android 35 packages with archive verification, builds the web assets, and produces `artifacts/Cyclades-v16.1-preview.apk`. Java 21 and `keytool` are required. The preview uses the separate package `com.aegean.cyclades.preview` and a local test signing key kept outside this repository. It installs alongside the original app; export a campaign from the original and import it into Preview to continue playing.

For an original-package release, run `android/build.sh` with `ANDROID_SDK_ROOT` and your signing configuration through the documented environment variables. Do not use the preview identity/password for a production release. Private signing material is never included in the source archives.

`node tools/run-original-tests.cjs` also runs selected source-provided suites and records individual outcomes under `artifacts/original-tests/`. It currently returns nonzero for an inherited capture-bonus rules assertion and an obsolete performance test harness; these failures have not been disabled.
